#!/usr/bin/env python3
with open('src/adapters/dense_transformer_runtime.cpp', 'r') as f:
    lines = f.readlines()

for i, line in enumerate(lines):
    if 'pipeline_layers.reserve(config_.layers);' in line:
        print(f"reserve at line {i+1}")
    if 'pipeline_layers.push_back(std::move(lp));' in line:
        print(f"push_back at line {i+1}")
    if 'all_layers_qualify = false;' in line and i > 1200 and i < 1220:
        print(f"all_layers_qualify=false in else at line {i+1}")
    if 'if(all_layers_qualify && pipeline_layers.size() == config_.layers)' in line:
        print(f"if condition at line {i+1}")
    if 'Also log when not all layers qualify' in line:
        print(f"Also log at line {i+1}")
    if 'if(all_layers_qualify) {' in line and 'Pipeline succeeded' in ''.join(lines[max(0,i+1):min(len(lines),i+3)]):
        print(f"second if at line {i+1}")
    if line.strip() == '} else {' and 'Whole layer in one device submission' in ''.join(lines[max(0,i+1):min(len(lines),i+3)]):
        print(f"else before for at line {i+1}")
    if 'for(std::uint32_t l=0;l<config_.layers;++l){' in line and 'const std::string p="blk."' in ''.join(lines[max(0,i+1):min(len(lines),i+3)]):
        print(f"for loop at line {i+1}")