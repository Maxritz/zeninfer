// Parity harness for the D3D12 RoPE path (task 5 of docs/d3d12_full_backend_todo.md).
//
// Compares zen::d3d12::rope_apply against the CPU reference rotation the runtime uses:
// within a head, element i pairs with i + pairs, and the pair rotates as
//   (a*cos - b*sin, a*sin + b*cos)
// with the cos/sin table indexed by i alone.
//
// Tolerance, not exactness: dxc contracts a*c - b*s into an fma at -O3, which rounds
// differently from the two separate float multiplies here. The CPU path tolerates that
// (it is the same class of difference the matvec kernels already produce), but an
// exact-match assertion would fail for a reason that is not a bug. Indexing or binding
// errors move values by far more than this bound.

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdio>
#include <random>
#include <vector>

#include "zen/d3d12_backend.h"

namespace {

// 1e-6 absolute is well below the ~1e-7 fma/separate-multiply difference and far above
// any measurement noise, so only real bugs trip it.
constexpr double kTolerance = 1.0e-5;

void cpu_rope(const std::vector<float>& x, const std::vector<float>& cos,
              const std::vector<float>& sin, std::vector<float>& out, std::size_t heads,
              std::size_t head_dim, std::size_t pairs) {
    for (std::size_t h = 0; h < heads; ++h) {
        const std::size_t base = h * head_dim;
        for (std::size_t i = 0; i < pairs; ++i) {
            const float a = x[base + i];
            const float b = x[base + i + pairs];
            out[base + i] = a * cos[i] - b * sin[i];
            out[base + i + pairs] = a * sin[i] + b * cos[i];
        }
        // Dimensions past rotary_dim are passed through untouched; leaving them zero
        // here would make the harness expect a rotation the kernel must not perform.
        for (std::size_t i = pairs * 2; i < head_dim; ++i) {
            out[base + i] = x[base + i];
        }
    }
}

bool check(std::size_t heads, std::size_t head_dim, std::size_t pairs, std::uint32_t seed) {
    std::mt19937 rng(seed);
    std::uniform_real_distribution<float> dist(-1.0f, 1.0f);

    std::vector<float> x(heads * head_dim), cos(pairs), sin(pairs);
    for (float& v : x) {
        v = dist(rng);
    }
    // A real table is cos/sin of an angle, so keep each pair on the unit circle.
    for (std::size_t i = 0; i < pairs; ++i) {
        const float angle = dist(rng) * 3.14159265f;
        cos[i] = std::cos(angle);
        sin[i] = std::sin(angle);
    }

    std::vector<float> out(heads * head_dim, 0.0f), ref(heads * head_dim, 0.0f);
    cpu_rope(x, cos, sin, ref, heads, head_dim, pairs);

    if (!zen::d3d12::rope_apply(x.data(), cos.data(), sin.data(), out.data(), heads, head_dim,
                                pairs)) {
        std::printf("FAIL: rope_apply returned false (heads=%zu head_dim=%zu pairs=%zu)\n", heads,
                    head_dim, pairs);
        return false;
    }

    double max_abs = 0.0;
    std::size_t worst = 0;
    for (std::size_t i = 0; i < out.size(); ++i) {
        const double e = std::fabs(double(out[i]) - double(ref[i]));
        if (e > max_abs) {
            max_abs = e;
            worst = i;
        }
    }
    const bool pass = max_abs <= kTolerance;
    std::printf("rope heads=%-3zu head_dim=%-4zu pairs=%-3zu max_abs_err=%.3e %s\n", heads,
                head_dim, pairs, max_abs, pass ? "ok" : "MISMATCH");
    if (!pass) {
        std::printf("    worst i=%zu gpu=%.9g ref=%.9g\n", worst, double(out[worst]),
                    double(ref[worst]));
    }
    return pass;
}

}  // namespace

int main() {
    if (!zen::d3d12::enabled()) {
        std::printf("SKIP: no D3D12.1 backend\n");
        return 77;
    }

    bool ok = true;
    // Llama-3.2-1B shape: 32 heads, 64-wide heads, full rotary.
    ok = check(32, 64, 32, 20261106u) && ok;
    // 8 KV heads, the GQA shape the k tensor uses.
    ok = check(8, 64, 32, 20261107u) && ok;
    // Partial rotary: dimensions past rotary_dim must pass through unchanged.
    ok = check(32, 128, 32, 20261108u) && ok;
    // Total pair count not a multiple of the 256-thread group, exercising the guard.
    ok = check(3, 64, 17, 20261109u) && ok;

    if (!ok) {
        return 1;
    }
    std::printf("PASS\n");
    return 0;
}
