// ZenInfer Direct3D 12.1 compute backend probe.
// Reports what the Direct3D 12 stack on this machine can actually do.

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>

#include <d3d12.h>
#include <dxgi1_6.h>
#include <wrl/client.h>

#include <cstdio>

using Microsoft::WRL::ComPtr;

namespace {

const char* level_name(D3D_FEATURE_LEVEL level) {
    switch (level) {
        case D3D_FEATURE_LEVEL_12_2: return "12_2 (Ultimate)";
        case D3D_FEATURE_LEVEL_12_1: return "12_1";
        case D3D_FEATURE_LEVEL_12_0: return "12_0";
        case D3D_FEATURE_LEVEL_11_1: return "11_1";
        case D3D_FEATURE_LEVEL_11_0: return "11_0";
        case D3D_FEATURE_LEVEL_10_1: return "10_1";
        case D3D_FEATURE_LEVEL_10_0: return "10_0";
        default: return "unknown";
    }
}

bool device_creates(IDXGIAdapter1* adapter, D3D_FEATURE_LEVEL level) {
    ComPtr<ID3D12Device> device;
    return SUCCEEDED(D3D12CreateDevice(adapter, level, IID_PPV_ARGS(&device))) && device;
}

void print_width(const char* label, UINT64 bytes) {
    std::printf("    %-22s %.2f GB\n", label,
                static_cast<double>(bytes) / (1024.0 * 1024.0 * 1024.0));
}

const char* work_graph_tier_name(int tier) {
    switch (tier) {
        case 0: return "Not supported";
        case 10: return "1.0";
        case 11: return "1.1";
        default: return "Unknown";
    }
}

const char* execute_indirect_tier_name(int tier) {
    switch (tier) {
        case 0: return "Not supported";
        case 10: return "1.0";
        case 11: return "1.1";
        default: return "Unknown";
    }
}

}  // namespace

int main() {
    ComPtr<IDXGIFactory6> factory;
    if (FAILED(CreateDXGIFactory1(IID_PPV_ARGS(&factory)))) {
        std::printf("FAIL: CreateDXGIFactory1 failed\n");
        return 1;
    }

    int adapters = 0;
    D3D_FEATURE_LEVEL best_level = static_cast<D3D_FEATURE_LEVEL>(0);
    for (UINT index = 0;; ++index) {
        ComPtr<IDXGIAdapter1> adapter;
        if (factory->EnumAdapters1(index, adapter.GetAddressOf()) == DXGI_ERROR_NOT_FOUND) {
            break;
        }
        DXGI_ADAPTER_DESC1 desc{};
        if (FAILED(adapter->GetDesc1(&desc))) {
            continue;
        }
        if (desc.Flags & DXGI_ADAPTER_FLAG_SOFTWARE) {
            std::printf("[%u] %ls  (skipped: software adapter)\n", index, desc.Description);
            continue;
        }

        ++adapters;
        std::printf("[%u] %ls\n", index, desc.Description);

        const D3D_FEATURE_LEVEL levels[] = {D3D_FEATURE_LEVEL_12_2, D3D_FEATURE_LEVEL_12_1,
                                            D3D_FEATURE_LEVEL_12_0};
        D3D_FEATURE_LEVEL highest = static_cast<D3D_FEATURE_LEVEL>(0);
        for (D3D_FEATURE_LEVEL level : levels) {
            if (device_creates(adapter.Get(), level)) {
                highest = level;
                break;
            }
        }
        if (highest > best_level) {
            best_level = highest;
        }
        std::printf("    %-22s %s\n", "feature level", level_name(highest));

        print_width("dedicated VRAM", desc.DedicatedVideoMemory);
        print_width("shared memory", desc.SharedSystemMemory);

        ComPtr<ID3D12Device> device;
        if (highest != static_cast<D3D_FEATURE_LEVEL>(0) &&
            SUCCEEDED(D3D12CreateDevice(adapter.Get(), highest, IID_PPV_ARGS(&device)))) {
            D3D12_FEATURE_DATA_D3D12_OPTIONS options{};
            if (SUCCEEDED(device->CheckFeatureSupport(D3D12_FEATURE_D3D12_OPTIONS, &options,
                                                      sizeof(options)))) {
                std::printf("    %-22s %s\n", "resource binding",
                            options.ResourceBindingTier >= D3D12_RESOURCE_BINDING_TIER_3
                                ? "tier 3 (full)"
                                : "below tier 3");
            }
            D3D12_FEATURE_DATA_ARCHITECTURE architecture{};
            if (SUCCEEDED(device->CheckFeatureSupport(D3D12_FEATURE_ARCHITECTURE, &architecture,
                                                      sizeof(architecture)))) {
                std::printf("    %-22s %s\n", "UMA",
                            architecture.UMA ? "yes (shared memory)" : "no (discrete)");
            }
            D3D12_FEATURE_DATA_SHADER_MODEL shader_model{};
            shader_model.HighestShaderModel = D3D_SHADER_MODEL_6_8;
            if (SUCCEEDED(device->CheckFeatureSupport(D3D12_FEATURE_SHADER_MODEL, &shader_model,
                                                      sizeof(shader_model)))) {
                std::printf("    %-22s 6.%u\n", "shader model",
                            static_cast<unsigned>(shader_model.HighestShaderModel & 0xF));
            }
            
            // OPTIONS12 - Enhanced Barriers
            D3D12_FEATURE_DATA_D3D12_OPTIONS12 opts12{};
            if (SUCCEEDED(device->CheckFeatureSupport(D3D12_FEATURE_D3D12_OPTIONS12, &opts12,
                                                      sizeof(opts12)))) {
                std::printf("    %-22s %s\n", "enhanced barriers",
                            opts12.EnhancedBarriersSupported ? "YES" : "no");
            }
            
            // OPTIONS16 - GPU Upload Heap
            D3D12_FEATURE_DATA_D3D12_OPTIONS16 opts16{};
            if (SUCCEEDED(device->CheckFeatureSupport(D3D12_FEATURE_D3D12_OPTIONS16, &opts16,
                                                      sizeof(opts16)))) {
                std::printf("    %-22s %s\n", "GPU upload heap",
                            opts16.GPUUploadHeapSupported ? "YES" : "no");
            }
            
            // OPTIONS21 - Work Graphs & ExecuteIndirect
            D3D12_FEATURE_DATA_D3D12_OPTIONS21 opts21{};
            if (SUCCEEDED(device->CheckFeatureSupport(D3D12_FEATURE_D3D12_OPTIONS21, &opts21,
                                                      sizeof(opts21)))) {
                std::printf("    %-22s %s\n", "work graphs",
                            work_graph_tier_name(static_cast<int>(opts21.WorkGraphsTier)));
                std::printf("    %-22s %s\n", "execute indirect",
                            execute_indirect_tier_name(static_cast<int>(opts21.ExecuteIndirectTier)));
            }
            
            // OPTIONS22 - Shader Execution Reordering (may not be in all SDKs)
#if defined(D3D12_FEATURE_D3D12_OPTIONS22) && defined(D3D12_FEATURE_DATA_D3D12_OPTIONS22)
            D3D12_FEATURE_DATA_D3D12_OPTIONS22 opts22{};
            if (SUCCEEDED(device->CheckFeatureSupport(D3D12_FEATURE_D3D12_OPTIONS22, &opts22,
                                                      sizeof(opts22)))) {
                std::printf("    %-22s %s\n", "shader exec reorder",
                            opts22.ShaderExecutionReorderingActuallyReorders ? "YES" : "no");
                std::printf("    %-22s %u\n", "max 1D dispatch",
                            opts22.Max1DDispatchSize);
            }
#else
            std::printf("    %-22s %s\n", "shader exec reorder", "N/A (SDK)");
            std::printf("    %-22s %s\n", "max 1D dispatch", "N/A (SDK)");
#endif
            
            // OPTIONS19 - Compute Only Custom Heap
            D3D12_FEATURE_DATA_D3D12_OPTIONS19 opts19{};
            if (SUCCEEDED(device->CheckFeatureSupport(D3D12_FEATURE_D3D12_OPTIONS19, &opts19,
                                                      sizeof(opts19)))) {
                std::printf("    %-22s %s\n", "compute-only heap",
                            opts19.ComputeOnlyCustomHeapSupported ? "YES" : "no");
            }
        }
        std::printf("\n");
    }

    if (!adapters) {
        std::printf("FAIL: no hardware DXGI adapters found\n");
        return 1;
    }

    std::printf("best available feature level: %s\n", level_name(best_level));
    if (best_level < D3D_FEATURE_LEVEL_12_1) {
        std::printf("FAIL: Direct3D 12.1 is not available on this machine\n");
        return 1;
    }
    std::printf("PASS: Direct3D 12.1 compute is available\n");
    return 0;
}
