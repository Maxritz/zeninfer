@echo off
"C:\Program Files (x86)\Windows Kits\10\bin\10.0.28000.0\x64\dxc.exe" -help 2>&1 | findstr /i work
pause