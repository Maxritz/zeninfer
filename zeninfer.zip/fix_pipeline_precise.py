#!/usr/bin/env python3
"""
Precise line-by-line fix for pipeline hybrid.
"""

with open('src/adapters/dense_transformer_runtime.cpp', 'r') as f:
    lines = f.readlines()

# We need to make the following changes:
# 1. After line with "pipeline_layers.reserve(config_.layers);" add layer_qualifies
# 2. After "pipeline_layers.push_back(std::move(lp));" add layer_qualifies[l] = true
# 3. In the else branch, add layer_qualifies[l] = false
# 4. Change the if condition from "if(all_layers_qualify && pipeline_layers.size() == config_.layers)" to "if(!pipeline_layers.empty())"
# 5. Remove the all_layers_qualify = false in the pipeline fail block
# 6. Remove the "Also log when not all layers qualify" block
# 7. Change the second if/else to just a for loop with continue

# Let's find the line numbers first
for i, line in enumerate(lines):
    if 'pipeline_layers.reserve(config_.layers);' in line:
        print(f"Line {i+1}: reserve - {line.strip()}")
    if 'pipeline_layers.push_back(std::move(lp));' in line:
        print(f"Line {i+1}: push_back - {line.strip()}")
    if 'all_layers_qualify = false;' in line and 'else' in lines[max(0,i-1)]:
        print(f"Line {i+1}: all_layers_qualify=false in else - {line.strip()}")
    if 'if(all_layers_qualify && pipeline_layers.size() == config_.layers)' in line:
        print(f"Line {i+1}: if condition - {line.strip()}")
    if 'all_layers_qualify = false;' in line and 'Pipeline failed' in lines[min(len(lines)-1, i+2)]:
        print(f"Line {i+1}: pipeline fail - {line.strip()}")
    if 'Also log when not all layers qualify' in line:
        print(f"Line {i+1}: also log - {line.strip()}")
    if 'if(all_layers_qualify) {' in line and 'Pipeline succeeded' in lines[min(len(lines)-1, i+1)]:
        print(f"Line {i+1}: second if - {line.strip()}")
    if line.strip() == '} else {' and 'Whole layer in one device submission' in lines[min(len(lines)-1, i+1)]:
        print(f"Line {i+1}: else before for - {line.strip()}")