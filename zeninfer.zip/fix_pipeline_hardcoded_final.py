#!/usr/bin/env python3
"""
Surgical fix with hardcoded line numbers from current file.
"""

with open('src/adapters/dense_transformer_runtime.cpp', 'r') as f:
    lines = f.readlines()

# Hardcoded line numbers (0-indexed) from current file:
# 1187: reserve
# 1210: push_back
# 1212: else branch with all_layers_qualify = false
# 1217: if condition
# 1241: Also log (7 lines)
# 1249: second if (if(all_layers_qualify) {)
# 1251: } else {
# 1252: for loop
# 1414: } (closes for)
# 1415: } (closes else)
# 1416: } (closes if)

# 1. Insert layer_qualifies after reserve
lines.insert(1188, '    std::vector<bool> layer_qualifies(config_.layers, false);\n')

# 2. Add layer_qualifies[l] = true after push_back
lines.insert(1211, '            layer_qualifies[l] = true;\n')

# 3. Add layer_qualifies[l] = false in else branch
lines[1212] = '            all_layers_qualify = false;\n            layer_qualifies[l] = false;\n'

# 4. Change if condition
lines[1217] = '    // Run pipeline for any qualifying layers (not requiring all)\n    if(!pipeline_layers.empty()) {\n'

# 5. Remove all_layers_qualify = false in pipeline fail block
for i in range(1218, len(lines)):
    if 'all_layers_qualify = false;' in lines[i] and 'Pipeline failed' in ''.join(lines[max(0,i-5):i+3]):
        lines[i] = '            // all_layers_qualify no longer used for pipeline gating\n'
        print('Removed all_layers_qualify=false at line', i+1)
        break

# 6. Remove "Also log" block (7 lines starting at line 1241)
also_log_start = None
for i, line in enumerate(lines):
    if 'Also log when not all layers qualify' in line:
        also_log_start = i
        break

if also_log_start is not None:
    for _ in range(7):
        lines.pop(also_log_start)
    print('Removed "Also log" block at line', also_log_start+1)

# 7. Replace second_if (1249) to else_end (1415) with new for loop
# Hardcoded positions after above edits:
second_if = 1248  # 0-indexed
else_pos = 1250   # 0-indexed (the "} else {" line)
for_loop = 1251   # 0-indexed
else_end = 1413   # 0-indexed (the "}" that closes else)

print(f'Second if at {second_if+1}, else at {else_pos+1}, for at {for_loop+1}, else_end at {else_end+1}')

# Verify these positions
print(f'second_if line: {lines[second_if].strip()}')
print(f'else_pos line: {lines[else_pos].strip()}')
print(f'for_loop line: {lines[for_loop].strip()}')
print(f'else_end line: {lines[else_end].strip()}')

body_lines = lines[for_loop+1:else_end]

new_section = [
    '    // Per-layer path for non-qualifying layers\n',
    '    for(std::uint32_t l=0;l<config_.layers;++l){\n',
    '        if (layer_qualifies[l]) continue; // Skip layers already processed by pipeline\n',
] + body_lines

# Replace from second_if to else_end
new_lines = lines[:second_if] + new_section + lines[else_end+1:]

# Remove ONE extra closing brace
final_content = ''.join(new_lines)

# Remove one extra } before generate function
idx = final_content.find('\nbool DenseTransformerRuntime::generate(')
if idx > 0:
    brace = 0
    for i in range(idx-1, max(0, idx-50), -1):
        if final_content[i] == '}':
            final_content = final_content[:i] + final_content[i+1:]
            print(f'Removed extra }} at position {i}')
            break

with open('src/adapters/dense_transformer_runtime.cpp', 'w') as f:
    f.write(final_content)

# Verify
open_braces = 0
for i, ch in enumerate(final_content):
    if ch == '{': open_braces += 1
    elif ch == '}':
        open_braces -= 1
        if open_braces < 0:
            print('ERROR: Extra } at position', i)
            break
print('Final open braces:', open_braces)
print('Done!')