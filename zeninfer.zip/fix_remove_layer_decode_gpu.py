with open(r'H:\llamadx\update\zeninfer\src\backends\d3d12\d3d12_backend.cpp', 'r') as f:
    lines = f.readlines()

# Find and remove the layer_decode_gpu function
new_lines = []
i = 0
in_function = False
brace_count = 0

while i < len(lines):
    line = lines[i]
    
    # Check if we're at the start of layer_decode_gpu function
    if 'bool layer_decode_gpu(State& s, const std::uint8_t* q_w, const std::uint8_t* k_w,' in line:
        in_function = True
        # Also skip the comment lines before it
        # Remove the last few lines from new_lines if they're the comment block
        while new_lines and new_lines[-1].strip().startswith('//'):
            new_lines.pop()
        i += 1
        continue
    
    if in_function:
        # Track braces to find end of function
        brace_count += line.count('{')
        brace_count -= line.count('}')
        
        if brace_count <= 0 and 'return false;' in line:
            # End of function found
            in_function = False
            i += 1
            # Also skip any blank lines after
            while i < len(lines) and lines[i].strip() == '':
                i += 1
            continue
        i += 1
        continue
    
    new_lines.append(line)
    i += 1

with open(r'H:\llamadx\update\zeninfer\src\backends\d3d12\d3d12_backend.cpp', 'w') as f:
    f.writelines(new_lines)

print("Done")