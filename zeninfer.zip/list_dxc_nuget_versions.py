import urllib.request
import json
import gzip

# Get all versions of Microsoft.Direct3D.DXC from NuGet
url = "https://api.nuget.org/v3/registration5-gz-semver2/microsoft.direct3d.dxc/index.json"
req = urllib.request.Request(url)
req.add_header('Accept-Encoding', 'gzip')
try:
    with urllib.request.urlopen(req) as response:
        content = response.read()
        if response.headers.get('Content-Encoding') == 'gzip':
            content = gzip.decompress(content)
        data = json.loads(content.decode('utf-8'))
        versions = []
        for page in data.get('items', []):
            for item in page.get('items', []):
                version = item.get('catalogEntry', {}).get('version')
                if version:
                    versions.append(version)
        versions = list(set(versions))
        versions.sort(key=lambda x: tuple(map(int, x.replace('-preview', '').split('.')[:3])), reverse=True)
        print(f"Found {len(versions)} versions of Microsoft.Direct3D.DXC:")
        for v in versions:
            print(f"  {v}")
except Exception as e:
    print(f"Failed to fetch versions: {e}")