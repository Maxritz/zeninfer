with open('include/zen/dense_transformer_runtime.h', 'r') as f:
    lines = f.readlines()

# Remove duplicate lines (keep first occurrence)
seen = set()
new_lines = []
for line in lines:
    stripped = line.strip()
    # Check for duplicate method declarations
    if 'bool ' in line and 'const noexcept;' in line:
        # Extract method name
        import re
        match = re.search(r'bool\s+(\w+)\s*\(', line)
        if match:
            method = match.group(1)
            key = (method, line.strip())
            if key in seen:
                print(f'Skipping duplicate: {line.strip()}')
                continue
    new_lines.append(line)

with open('include/zen/dense_transformer_runtime.h', 'w') as f:
    f.writelines(lines)

print('Done!')