with open('src/adapters/dense_transformer_runtime.cpp.bak', 'r') as f:
    content = f.read()

# Add missing namespace closing brace
if not content.rstrip().endswith('} // namespace zen::runtime'):
    content = content.rstrip() + '\n} // namespace zen::runtime\n'

with open('src/adapters/dense_transformer_runtime.cpp.bak', 'w') as f:
    f.write(content)

print('Fixed backup - added namespace closing brace!')