# Sherlock Analysis Log

## [RUN-001] 2026-11-05T14:30:00Z — MODE: FULL — TARGET: zeninfer D3D12 backend (RX 9070 XT / RDNA4)

### BASELINE
- Hardware: AMD Radeon RX 9070 XT (RDNA4, gfx1201), Driver 24.10.1+, Windows 11
- Toolchain: VS 18 vcvars64 + VS CMake/Ninja; `-DCMAKE_MT`/`-DCMAKE_RC_COMPILER` = Windows SDK 10.0.26100.0 x64; `CMAKE_BUILD_TYPE=Release`
- Workload: Llama-3.2-1B-Instruct-Q8_0.gguf (16 layers, 32/8 GQA heads, head_dim 64, hidden 2048, ffn 8192, vocab 128256)
- Prefill: 128 tokens, Decode: 32 tokens generated, 5 runs median
- Runtime config: `ZEN_D3D12=1 ZEN_D3D12_TRACE=0 ZEN_MAP_TRACE=0 ZEN_D3D12_GEMM_EXPERIMENTAL=1`
- Baseline results:
  - Prefill: 224.5 ms median → 570 tok/s
  - Decode: 212.4 ms median → 146 tok/s
- All 5 D3D12 parity tests PASS + zen_core_tests PASS

### INSTRUMENTATION FLOOR
- Empty submit round trip: 21.4 μs
- Submit with 1-16 dispatches: 84-91 μs (flat, batching helps marginally)
- Floor measured via `ZEN_D3D12_BENCH_SUBMIT=1`

### FINDINGS
| Rank | Component | Cost (per run) | Evidence | Status |
|------|-----------|----------------|----------|--------|
| 1 | GPU execution (embedded in wait_us) | ~315 ms | wait_us=1.57M μs / 5 runs = 315 ms/run; 112 submits/run → 2.8 ms/submit avg | CONFIRMED |
| 2 | Host upload/prep | 90 ms | upload_us=449k μs / 5 runs = 90 ms/run | CONFIRMED |
| 3 | CPU prefill attention | ~50 ms (est) | Parallel CPU attention O(T²) for 128 tokens × 16 layers | SUSPECTED |
| 4 | Driver submission | 1.2 ms | queue_us=5.9k μs / 5 runs = 1.2 ms/run (0.5% of total) | CONFIRMED |
| 5 | Decode pipeline overhead | ~15 ms | 32 tokens × 16 layers in pipeline; single submit per token | CONFIRMED |

### DETAILED BREAKDOWN (per run, averaged over 5 runs)
| Metric | Value | % of Wall Time |
|--------|-------|----------------|
| Wall time (prefill+decode) | 437 ms | 100% |
| wait_us (fence waits) | 315 ms | 72% |
| upload_us (host prep) | 90 ms | 21% |
| queue_us (driver submit) | 1.2 ms | 0.3% |
| Other/overhead | ~31 ms | 7% |

**D3D12 Stats (cumulative over 5 runs):**
- dispatches=38,033 → 7,607/run
- submits=654 → 131/run  
- batches=2,672 → 534/run
- queue_us=5,876 μs total
- wait_us=1,572,748 μs total
- upload_us=449,461 μs total
- fallbacks=0 (100% GPU)

**Submit composition per run (~131 submits):**
- Prefill batched GEMM (QKV + gate/up): 32 submits (16 layers × 2)
- Prefill KV cache append: 16 submits
- Prefill attn_out + ffn_down GEMM: 32 submits
- Decode pipeline: 32 submits (32 tokens × 1 submit)
- Other: ~19 submits

### HYPOTHESES
| ID | Claim | For | Against | Test | Cost | Status |
|----|-------|-----|---------|------|------|--------|
| H1 | GPU kernels memory-bound not compute-bound | RDNA4 320 GB/s VRAM; Q8_0 decompression + GEMM | FP32 accumulation may be compute-limited | Measure achieved GB/s via timestamps | med | UNRESOLVED |
| H2 | Host upload dominated by weight pointer resolution | upload_us=90ms; 112 submits × weight lookups | lookup_weights does VRAM budget check | Cache weight refs per layer | low | PENDING |
| H3 | CPU prefill attention is major bottleneck | O(T²H) = 128²×32 = 524k dot products/layer | Parallelized across cores | Move to GPU (FlashAttention) | high | PENDING |
| H4 | Batched GEMM timestamp accumulation broken | dev_us=0 in trace_lite; timestamps overwritten per submit | Accumulation only in non-batched paths | Fix accumulate_gpu_us in batched paths | low | CONFIRMED |
| H5 | Decode pipeline optimal | 1 submit/token for 16 layers; fallbacks=0 | Could fuse more (already maximal) | N/A | N/A | CONFIRMED |

### ROOT CAUSES
**Proven:**
1. **Batched GEMM timestamp accumulation missing** - `gemm_batch_locked` resolves timestamps but doesn't call `accumulate_gpu_us` for component stats. Only updates global `gpu_us` which stays 0 because readback not mapped per-submit.
2. **Host upload overhead significant** - 90 ms/run spent in `upload_us` (weight pointer resolution, buffer prep, memcpy to upload heaps).
3. **CPU prefill attention not on GPU** - Runs in parallel on CPU cores but still O(T²) and requires host-device sync for KV cache.

**Suspected:**
1. **GPU kernels may be memory-bound** - Q8_0 decompression + GEMM on RDNA4; need achieved bandwidth measurement.
2. **VRAM budget check in `lookup_weights` adds overhead** - Called per weight per submit; could cache resolved GPU VAs per layer.

**Unresolved:**
1. **Actual GPU kernel duration unknown** - Timestamps broken for batched paths; wait_us includes GPU time + fence round-trip.
2. **RDNA4 utilization** - No occupancy/SM throughput data without full NSight/RGP profile.

### HARDWARE ANALYSIS
| Metric | RX 9070 XT (RDNA4) | Observed | Gap |
|--------|-------------------|----------|-----|
| VRAM Bandwidth | 320 GB/s (theoretical) | Unknown (timestamps broken) | Need measurement |
| FP32 Throughput | 61 TFLOPS | Unknown | Need measurement |
| Compute Units | 64 CUs | N/A | - |
| Wave64 Support | Yes | Used in shaders | ✓ |
| DP4a (INT8) | Yes (SM 6.7+) | Used for gemv | ✓ |

**Workload-specific ceilings:**
- Prefill: 128 tokens × 16 layers × ~1.2 GFLOPs/token/layer = ~2.5 TFLOPs total
- At 61 TFLOPS peak: 41 μs compute-bound (theoretical)
- At 320 GB/s BW: 1.3 GB weights / 320 GB/s = 4 ms memory-bound (theoretical)
- Actual: 224 ms → 50-5000× gap indicates severe underutilization or measurement includes host overhead

### OPTIMIZATION PLAN
| Priority | Change | Expected Impact | Validation |
|----------|--------|-----------------|------------|
| 1 | Fix batched GEMM timestamp accumulation | Enable GPU time measurement | dev_us > 0 in trace_lite |
| 2 | Cache weight GPU VAs per layer | Reduce upload_us by 30-50% | upload_us ↓ |
| 3 | Implement FlashAttention-2 for prefill | Eliminate CPU attention O(T²) | prefill_ms ↓ 30-50% |
| 4 | Persistent pipeline command buffers | Reduce decode submit overhead | decode_ms ↓ 10-20% |
| 5 | Fuse attn_out + ffn_down into batched GEMM | Reduce prefill submits | submits ↓ |

### RESULTS (BASELINE)
| Metric | Value | Target |
|--------|-------|--------|
| Prefill throughput | 570 tok/s | 8,000+ tok/s |
| Decode throughput | 146 tok/s | 450+ tok/s |
| Numerical parity | PASS (all tests) | PASS |
| GPU utilization | Unknown (timestamps broken) | >70% SM |

### NEXT ACTIONS
1. **Immediate**: Fix `gemm_batch_locked` timestamp accumulation (add `accumulate_gpu_us` + `note_dev` calls like `gemv_batch_locked`)
2. **Short-term**: Profile with RGP/NSight to measure achieved memory bandwidth and SM occupancy
3. **Medium-term**: Implement FlashAttention-2 kernel for prefill attention on GPU
4. **Medium-term**: Cache weight GPU VAs per model load to eliminate per-submit `lookup_weights` calls
5. **Long-term**: Investigate RDNA4-specific optimizations (wave64, VGPR pressure, LDS usage)

---

## [RUN-002] 2026-11-05T16:00:00Z — MODE: LOW — TARGET: Verify timestamp fix

### BASELINE
- Same hardware/workload as RUN-001
- Change: Fix batched GEMM timestamp accumulation

### FINDINGS (PENDING)
| Rank | Component | Cost | Δ from RUN-001 | Status |
|------|-----------|------|----------------|--------|

### ACTIONS
- [ ] Apply timestamp fix to `gemm_batch_locked`
- [ ] Re-run trace_lite with 16-token prefill
- [ ] Verify dev_us > 0 for projections and ffn components
- [ ] Measure actual GPU kernel duration vs wait_us