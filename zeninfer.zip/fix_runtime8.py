with open('src/adapters/dense_transformer_runtime.cpp', 'r') as f:
    content = f.read()

# Find the current messy state and clean it up
# Find the scope_rope section
idx = content.find('zen::diag::Scope scope_rope("transformer.prefill.rope",zen::diag::Phase::compute);')
print('Found at:', idx)

# Print context around it
print(content[idx:idx+2000])