with open('include/zen/dense_transformer_runtime.h', 'r') as f:
    lines = f.readlines()

seen_methods = set()
new_lines = []
for line in lines:
    # Check if this line contains a method declaration
    import re
    match = re.search(r'\bbool\s+(\w+)\s*\(', line)
    if match:
        method_name = match.group(1)
        if method_name in seen_methods:
            print(f'Skipping duplicate: {method_name}')
            continue
        seen_methods.add(method_name)
    new_lines.append(line)

with open('include/zen/dense_transformer_runtime.h', 'w') as f:
    f.writelines(lines)

print('Removed duplicates!')