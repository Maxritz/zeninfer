// First check which layers qualify for the pipeline path
    struct LayerParams {
        const std::uint8_t* q_w, *k_w, *v_w, *o_w, *gate_w, *up_w, *down_w;
        const float* attn_norm_w; const float* ffn_norm_w;
        std::vector<float> cos, sin;
        std::size_t pairs, layer, pos, first_pos;
    };
    std::vector<LayerParams> pipeline_layers;
    pipeline_layers.reserve(config_.layers);
    std::vector<bool> layer_qualifies(config_.layers, false);

    for(std::uint32_t l=0;l<config_.layers;++l){
        const std::string p="blk."+std::to_string(l)+".";
        const auto* lq=tensor(p+"attn_q.weight");const auto* lk=tensor(p+"attn_k.weight");
        const auto* lv=tensor(p+"attn_v.weight");const auto* lo=tensor(p+"attn_output.weight");
        const auto* lg=tensor(p+"ffn_gate.weight");const auto* lu=tensor(p+"ffn_up.weight");
        const auto* ldw=tensor(p+"ffn_down.weight");
        const auto* ln=tensor(p+"attn_norm.weight");const auto* lfn=tensor(p+"ffn_norm.weight");
        if(!config_.use_alibi&&!config_.bitnet_variant&&lq&&lk&&lv&&lo&&lg&&lu&&ldw&&ln&&lfn
           &&lq->raw&&lk->raw&&lv->raw&&lo->raw&&lg->raw&&lu->raw&&ldw->raw
           &&!tensor(p+"attn_q.bias")&&!tensor(p+"attn_k.bias")&&!tensor(p+"attn_v.bias")
           &&!tensor(p+"attn_q_norm.weight")
           &&device_attention_available(config_.layers,kc[l].size()/KW,KH,D,config_.rms_epsilon)){
            // Qualifies for pipeline
            LayerParams lp;
            lp.q_w = lq->raw; lp.k_w = lk->raw; lp.v_w = lv->raw; lp.o_w = lo->raw;
            lp.gate_w = lg->raw; lp.up_w = lu->raw; lp.down_w = ldw->raw;
            lp.attn_norm_w = ln->values.data(); lp.ffn_norm_w = lfn->values.data();
            lp.layer = l; lp.pos = pos;
            lp.first_pos = config_.sliding_window&&pos+1>config_.sliding_window?pos+1-config_.sliding_window:0;
            rope_table(config_.rope_dim,pos,config_.rope_base,config_.rope_scaling_type,config_.rope_scaling_factor,config_.rope_original_context,config_.rope_low_freq_factor,config_.rope_high_freq_factor,config_.rope_yarn_beta_fast,config_.rope_yarn_beta_slow,lp.cos,lp.sin);
            lp.pairs = lp.cos.size();
            pipeline_layers.push_back(std::move(lp));
            layer_qualifies[l] = true;
        } else {
            layer_qualifies[l] = false;
        }
    }

    // Run pipeline for contiguous segments of qualifying layers
    bool any_pipeline_ok = false;
    std::size_t pipeline_start = 0;
    while (pipeline_start < config_.layers) {
        // Find next qualifying layer
        while (pipeline_start < config_.layers && !layer_qualifies[pipeline_start]) {
            ++pipeline_start;
        }
        if (pipeline_start >= config_.layers) break;
        
        // Find end of contiguous qualifying segment
        std::size_t pipeline_end = pipeline_start;
        while (pipeline_end < config_.layers && layer_qualifies[pipeline_end]) {
            ++pipeline_end;
        }
        
        // Run pipeline for layers [pipeline_start, pipeline_end)
        std::size_t segment_size = pipeline_end - pipeline_start;
        zen::d3d12::LayerDecodeParams d3d_layers[64];
        for(std::size_t i=0;i<segment_size;++i){
            auto& lp = pipeline_layers[pipeline_start + i];
            d3d_layers[i].q_w = lp.q_w; d3d_layers[i].k_w = lp.k_w; d3d_layers[i].v_w = lp.v_w; d3d_layers[i].o_w = lp.o_w;
            d3d_layers[i].gate_w = lp.gate_w; d3d_layers[i].up_w = lp.up_w; d3d_layers[i].down_w = lp.down_w;
            d3d_layers[i].attn_norm_w = lp.attn_norm_w; d3d_layers[i].ffn_norm_w = lp.ffn_norm_w;
            d3d_layers[i].cos = lp.cos.data(); d3d_layers[i].sin = lp.sin.data();
            d3d_layers[i].pairs = lp.pairs; d3d_layers[i].layer = lp.layer; d3d_layers[i].pos = lp.pos; d3d_layers[i].first_pos = lp.first_pos;
        }
        bool segment_ok = zen::d3d12::layer_decode_pipeline(d3d_layers, segment_size, x.data(), x.data(), E, H, KH, D, F, config_.rms_epsilon);
        if (segment_ok) {
            any_pipeline_ok = true;
            if (const char* trace = std::getenv("ZEN_D3D12_TRACE"); trace && trace[0] == '1') {
                std::printf("[d3d12] pipeline: SUCCESS segment layers [%zu, %zu) for token pos=%zu\n", pipeline_start, pipeline_end, pos);
            }
        } else {
            if (const char* trace = std::getenv("ZEN_D3D12_TRACE"); trace && trace[0] == '1') {
                std::printf("[d3d12] pipeline: FALLBACK segment layers [%zu, %zu) for token pos=%zu\n", pipeline_start, pipeline_end, pos);
            }
            // If pipeline fails for a segment, mark those layers as non-qualifying
            for (std::size_t l = pipeline_start; l < pipeline_end; ++l) {
                layer_qualifies[l] = false;
            }
        }
        
        pipeline_start = pipeline_end;
    }

    // Per-layer path for non-qualifying layers
    for(std::uint32_t l=0;l<config_.layers;++l){
        if (layer_qualifies[l]) continue; // Skip layers already processed by pipeline
        const std::string p="blk."+std::to_string(l)+".";