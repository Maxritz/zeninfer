with open('include/zen/dense_transformer_runtime.h', 'r') as f:
    content = f.read()

idx = content.find('};')
while idx >= 0:
    print(f'Found }; at index {idx}')
    print(repr(content[max(0,idx-20):idx+10]))
    idx = content.find('};', idx+1)