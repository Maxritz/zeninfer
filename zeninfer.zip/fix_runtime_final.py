with open('src/adapters/dense_transformer_runtime.cpp', 'r') as f:
    content = f.read()

# Find the original rope scope section (before my modifications)
idx = content.find('zen::diag::Scope scope_rope("transformer.prefill.rope",zen::diag::Phase::compute);', 75648)
print('Start:', idx)

# Find the end - the attention scope
end_idx = content.find('{zen::diag::Scope scope_attn("transformer.prefill.attention",zen::diag::Phase::compute);', idx)
print('End:', end_idx)

# Extract the original clean section
original = content[idx:end_idx]
print('Length:', len(original))
print('Original (first 500):')
print(original[:500])
print('---')
print('Original (last 500):')
print(original[-500:])