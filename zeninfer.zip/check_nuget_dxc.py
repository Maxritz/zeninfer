import urllib.request
import gzip
import json

req = urllib.request.Request("https://api.nuget.org/v3/registration5-gz-semver2/microsoft.directx.dxc/index.json")
req.add_header('Accept-Encoding', 'gzip')
with urllib.request.urlopen(req) as response:
    content = response.read()
    if response.headers.get('Content-Encoding') == 'gzip':
        content = gzip.decompress(content)
    data = json.loads(content.decode('utf-8'))
    
    versions = []
    for page in data.get('items', []):
        for item in page.get('items', []):
            version = item.get('catalogEntry', {}).get('version')
            if version:
                versions.append(version)
    
    versions = list(set(versions))
    versions.sort(key=lambda x: tuple(map(int, x.split('.')[:3])), reverse=True)
    print(f"Found {len(versions)} versions")
    for v in versions[:20]:
        print(v)