with open('src/adapters/dense_transformer_runtime.cpp', 'r') as f:
    lines = f.readlines()

# 1. Remove variable declarations inside the scope_rope block (lines 1043-1050, 1-indexed)
# 0-indexed: 1042-1049
del lines[1042:1050]

# 2. Insert variable declarations BEFORE the scope_rope line (line 1041, 0-indexed 1040)
var_decls = [
    '        // Collect all K/V pointers for batched KV cache append\n',
    '        std::vector<std::size_t> kv_layers;\n',
    '        std::vector<std::size_t> kv_positions;\n',
    '        std::vector<const float*> kv_ks;\n',
    '        std::vector<const float*> kv_vs;\n',
    '        kv_layers.reserve(T);\n',
    '        kv_positions.reserve(T);\n',
    '        kv_ks.reserve(T);\n',
    '        kv_vs.reserve(T);\n',
    '\n',
]

# Re-read lines after deletion
with open('src/adapters/dense_transformer_runtime.cpp', 'r') as f:
    lines = f.readlines()

# Insert at line 1041 (0-indexed 1040)
for i, decl in enumerate(var_decls):
    lines.insert(1040 + i, decl)

# Fix 2: Fix printf format string
for i, line in enumerate(lines):
    if 'std::printf("[d3d12] batched kv append' in line and 'num_tokens=%zu\n"' in line:
        lines[i] = lines[i].replace('num_tokens=%zu\n"', 'num_tokens=%zu\\n"')
        print(f'Fixed printf at line {i+1}')
        break

# Fix 3: Remove duplicate scope_attn declaration
for i, line in enumerate(lines):
    if line.strip().count('zen::diag::Scope scope_attn("transformer.prefill.attention"') == 2:
        lines[i] = '        {zen::diag::Scope scope_attn("transformer.prefill.attention",zen::diag::Phase::compute);\n'
        print(f'Fixed duplicate scope_attn at line {i+1}')
        break

with open('src/adapters/dense_transformer_runtime.cpp', 'w') as f:
    f.writelines(lines)

print('Fixes applied!')