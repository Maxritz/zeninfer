#!/usr/bin/env python3
"""
Ultra-precise surgical fix using exact line numbers from backup.
"""

with open('src/adapters/dense_transformer_runtime.cpp.bak', 'r') as f:
    lines = f.readlines()

# Exact 0-indexed line numbers from backup:
# reserve: 1187
# push_back: 1210
# all_layers_qualify=false in else: 1212
# if condition: 1217
# all_layers_qualify=false in pipeline: (need to find)
# Also log: 1241
# second if: 1249
# else before for: (need to find)
# for loop start: (need to find)

# Find the remaining line numbers
for i, line in enumerate(lines):
    if 'all_layers_qualify = false;' in line and 'Pipeline failed' in lines[i+2]:
        print(f"all_layers_qualify=false in pipeline at line {i+1} (0-indexed: {i})")
    if line.strip() == '} else {' and 'Whole layer in one device submission' in lines[i+1]:
        print(f"else before for at line {i+1} (0-indexed: {i})")
    if 'for(std::uint32_t l=0;l<config_.layers;++l){' in line and 'const std::string p="blk."' in lines[i+1]:
        print(f"for loop at line {i+1} (0-indexed: {i})")

# Find the end of the else block (matching brace)
# The else block starts at the "else before for" line
# We need to find its matching closing brace
else_start = -1
for i, line in enumerate(lines):
    if line.strip() == '} else {' and 'Whole layer in one device submission' in lines[i+1]:
        else_start = i
        break

if else_start >= 0:
    brace = 0
    for i in range(else_start, len(lines)):
        for ch in lines[i]:
            if ch == '{': brace += 1
            elif ch == '}': brace -= 1
        if brace == 0:
            print(f"else block ends at line {i+1} (0-indexed: {i})")
            break

# Find all_layers_qualify=false in pipeline block
for i, line in enumerate(lines):
    if 'all_layers_qualify = false;' in line and i > 1220 and i < 1250:
        print(f"all_layers_qualify=false in pipeline at line {i+1} (0-indexed: {i})")
        print(f"  Context: {lines[i-1].strip()} | {line.strip()} | {lines[i+1].strip()}")