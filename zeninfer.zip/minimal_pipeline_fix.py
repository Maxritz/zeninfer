with open('src/adapters/dense_transformer_runtime.cpp', 'r') as f:
    lines = f.readlines()

# Make minimal changes:
# 1. Add layer_qualifies vector after pipeline_layers declaration (around line 1188)
# 2. Set layer_qualifies[l] = true/false in the qualification loop (around line 1211/1213)
# 3. Change the pipeline condition (around line 1218)
# 4. Add pipeline execution logic for qualifying layers
# 5. Skip qualifying layers in per-layer loop (around line 1254)

# 1. Add layer_qualifies after pipeline_layers.reserve
for i, line in enumerate(lines):
    if 'pipeline_layers.reserve(config_.layers);' in line:
        lines.insert(i+1, '    std::vector<bool> layer_qualifies(config_.layers, false);\n')
        print(f"Added layer_qualifies at line {i+2}")
        break

# 2. Set layer_qualifies in the qualification loop
for i, line in enumerate(lines):
    if 'pipeline_layers.push_back(std::move(lp));' in line:
        # Add after this line
        lines.insert(i+1, '            layer_qualifies[l] = true;\n')
        print(f"Added layer_qualifies[l]=true at line {i+2}")
        break

for i, line in enumerate(lines):
    if 'all_layers_qualify = false;' in line and 'else' in lines[i-1]:
        # This is in the else block of qualification
        lines[i] = '            all_layers_qualify = false;\n            layer_qualifies[l] = false;\n'
        print(f"Added layer_qualifies[l]=false at line {i+1}")
        break

# 3. Change pipeline condition from "if(all_layers_qualify && pipeline_layers.size() == config_.layers)"
for i, line in enumerate(lines):
    if 'if(all_layers_qualify && pipeline_layers.size() == config_.layers)' in line:
        lines[i] = '    // Run pipeline for any qualifying layers (not requiring all)\n    if(!pipeline_layers.empty()) {\n'
        print(f"Changed pipeline condition at line {i+1}")
        break

# 4. After pipeline execution, add the per-layer skip logic
# Find "if(all_layers_qualify) {" and replace with logic that skips qualifying layers
for i, line in enumerate(lines):
    if line.strip() == 'if(all_layers_qualify) {' and 'Pipeline succeeded' in lines[i+1]:
        lines[i] = '    // Per-layer path for non-qualifying layers\n    for(std::uint32_t l=0;l<config_.layers;++l){\n        if (layer_qualifies[l]) continue; // Skip layers already processed by pipeline\n'
        # Remove the next line "// Pipeline succeeded, skip per-layer path"
        if 'Pipeline succeeded' in lines[i+1]:
            lines[i+1] = ''
        print(f"Modified per-layer loop at line {i+1}")
        break

# Also need to close the new pipeline if block - find the matching }
# The original had: if(all_layers_qualify) { ... } else { for(...) { ... } }
# Now we have: if(!pipeline_layers.empty()) { ... } for(...) { ... }
# The for loop is now outside, so we need to make sure braces match

# Find the end of the pipeline block (where "} else {" was)
for i, line in enumerate(lines):
    if '// Pipeline succeeded, skip per-layer path' in line:
        # This comment is now removed, but we need to find where the old if block ended
        pass

# Actually, the simplest fix: the old structure was:
# if(all_layers_qualify) { pipeline } else { for(layers) { ... } }
# New structure should be:
# if(!pipeline_layers.empty()) { pipeline }
# for(layers) { if(layer_qualifies[l]) continue; ... }
# So we just need to remove the "else" and the extra closing brace

# Find "} else {" after pipeline block
for i, line in enumerate(lines):
    if line.strip() == '} else {' and i > 1200:
        lines[i] = '}\n'
        print(f"Changed }} else {{ to }} at line {i+1}")
        break

# Also need to remove the extra closing brace at the end of the else block
# The old structure had two closing braces: one for else, one for if
# Now we only need one for the if

# Find the line with "// Pipeline succeeded, skip per-layer path" area
# Actually, let's just verify the brace balance after our changes

with open('src/adapters/dense_transformer_runtime.cpp', 'w') as f:
    f.writelines(lines)

print("Changes applied!")

# Verify brace balance
open_braces = 0
for i, line in enumerate(lines):
    for ch in line:
        if ch == '{':
            open_braces += 1
        elif ch == '}':
            open_braces -= 1
            if open_braces < 0:
                print(f"ERROR: Extra }} at line {i+1}")
                break
print(f"Final open braces: {open_braces}")