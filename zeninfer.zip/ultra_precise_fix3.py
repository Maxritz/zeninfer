#!/usr/bin/env python3
"""
Ultra-precise surgical fix using exact line numbers from backup - FINAL.
"""

with open('src/adapters/dense_transformer_runtime.cpp.bak', 'r') as f:
    lines = f.readlines()

# 0-indexed line numbers (verified):
reserve_line = 1187
push_back_line = 1210
else_qualify_line = 1212
if_condition_line = 1217
pipeline_fail_line = 1235
also_log_start = 1241
second_if_line = 1249
else_before_for_line = 1251  # "} else {" at line 1252
for_loop_line = 1252         # "for(...)" at line 1253
else_start = 1251            # "} else {" at line 1252

# Find else block end
brace = 0
else_end = -1
for i in range(else_start, len(lines)):
    for ch in lines[i]:
        if ch == '{': brace += 1
        elif ch == '}': brace -= 1
    if brace == 0:
        else_end = i
        break

print(f"Else block: {else_start+1} to {else_end+1}")

# Verify all lines
print(f"Reserve: {reserve_line+1} -> {lines[reserve_line].strip()}")
print(f"Push_back: {push_back_line+1} -> {lines[push_back_line].strip()}")
print(f"Else qualify: {else_qualify_line+1} -> {lines[else_qualify_line].strip()}")
print(f"If condition: {if_condition_line+1} -> {lines[if_condition_line].strip()}")
print(f"Pipeline fail: {pipeline_fail_line+1} -> {lines[pipeline_fail_line].strip()}")
print(f"Also log start: {also_log_start+1} -> {lines[also_log_start].strip()}")
print(f"Second if: {second_if_line+1} -> {lines[second_if_line].strip()}")
print(f"Else before for: {else_before_for_line+1} -> {lines[else_before_for_line].strip()}")
print(f"For loop: {for_loop_line+1} -> {lines[for_loop_line].strip()}")
print(f"Else block: {else_start+1} to {else_end+1}")

# Now make the edits
new_lines = lines.copy()

# 1. Insert layer_qualifies after reserve (line 1187)
new_lines.insert(reserve_line + 1, '    std::vector<bool> layer_qualifies(config_.layers, false);\n')
print("1. Inserted layer_qualifies")

# 2. Add layer_qualifies[l] = true after push_back (line 1210 -> now 1211 due to insert)
new_lines.insert(push_back_line + 2, '            layer_qualifies[l] = true;\n')
print("2. Added layer_qualifies[l]=true")

# 3. Add layer_qualifies[l] = false in else branch (line 1212 -> now 1213)
new_lines[else_qualify_line] = '            all_layers_qualify = false;\n            layer_qualifies[l] = false;\n'
print("3. Added layer_qualifies[l]=false in else")

# 4. Replace if condition (line 1217 -> now 1218)
new_lines[if_condition_line + 1] = '    // Run pipeline for any qualifying layers (not requiring all)\n    if(!pipeline_layers.empty()) {\n'
print("4. Changed if condition")

# 5. Replace pipeline fail all_layers_qualify=false (line 1235 -> now 1236)
new_lines[pipeline_fail_line + 1] = '            // all_layers_qualify no longer used for pipeline gating\n'
print("5. Removed all_layers_qualify=false in pipeline fail")

# 6. Remove "Also log" block (7 lines starting at also_log_start)
# Adjust for previous inserts (2 inserts before this point)
also_log_start_adj = also_log_start + 2
for _ in range(7):
    new_lines.pop(also_log_start_adj)
print("6. Removed 'Also log' block")

# 7. Replace second_if to else_end with new for loop
# Adjust for previous changes: +2 inserts, -7 pops = -5
shift = 2 - 7
second_if_adj = second_if_line + shift
else_before_for_adj = else_before_for_line + shift
for_loop_adj = for_loop_line + shift
else_start_adj = else_start + shift
else_end_adj = else_end + shift

# Find actual positions in new_lines (verify)
print(f"Second if at new line {second_if_adj+1}: {new_lines[second_if_adj].strip()}")
print(f"Else before for at new line {else_before_for_adj+1}: {new_lines[else_before_for_adj].strip()}")
print(f"For loop at new line {for_loop_adj+1}: {new_lines[for_loop_adj].strip()}")
print(f"Else block in new_lines: {else_start_adj+1} to {else_end_adj+1}: {new_lines[else_end_adj].strip()}")

# Build new section
body_lines = new_lines[for_loop_adj+1:else_end_adj]

new_section = [
    '    // Per-layer path for non-qualifying layers\n',
    '    for(std::uint32_t l=0;l<config_.layers;++l){\n',
    '        if (layer_qualifies[l]) continue; // Skip layers already processed by pipeline\n',
] + body_lines

# Replace from second_if_adj to else_end_adj
final_lines = new_lines[:second_if_adj] + new_section + new_lines[else_end_adj+1:]

# Remove ONE extra closing brace (we removed if/else but kept for loop, so net -1 closing brace)
# Find the extra } at the end of the section
brace = 0
extra_brace = -1
for i in range(len(final_lines)-1, -1, -1):
    for ch in final_lines[i]:
        if ch == '}': brace += 1
        elif ch == '{': brace -= 1
    if brace == 0:
        extra_brace = i
        break

if extra_brace >= 0:
    final_lines.pop(extra_brace)
    print(f"Removed extra }} at line {extra_brace+1}")

# Verify brace balance
open_braces = 0
for i, line in enumerate(final_lines):
    for ch in line:
        if ch == '{': open_braces += 1
        elif ch == '}': 
            open_braces -= 1
            if open_braces < 0:
                print(f"ERROR: Extra }} at line {i+1}: {final_lines[i].strip()[:80]}")
                break
print(f"Final open braces: {open_braces}")

with open('src/adapters/dense_transformer_runtime.cpp', 'w') as f:
    f.writelines(final_lines)

print("Done!")