import urllib.request
import zipfile
import shutil
import subprocess
import tempfile
import os

# Try to download Agility SDK 1.8.2411 directly from Microsoft download center
# The Agility SDK is at: https://www.nuget.org/packages/Microsoft.Direct3D.D3D12/1.8.2411

AGILITY_VERSION = "1.8.2411"
url = f"https://www.nuget.org/api/v2/package/Microsoft.Direct3D.D3D12/{AGILITY_VERSION}"

with tempfile.TemporaryDirectory() as tmpdir:
    nupkg_path = os.path.join(tmpdir, f"agility_{AGILITY_VERSION}.nupkg")
    
    try:
        print(f"Downloading Agility SDK 1.8.2411 from NuGet...")
        urllib.request.urlretrieve(f"https://www.nuget.org/api/v2/package/Microsoft.Direct3D.D3D12/{AGILITY_VERSION}", 
                                   os.path.join(tmpdir, f"agility_{AGILITY_VERSION}.nupkg"))
    except urllib.error.HTTPError as e:
        if e.code == 404:
            print(f"Version 1.8.2411 not found on NuGet")
        else:
            raise
    
    # If that fails, try the preview version
    for version in ["1.8.2411.5", "1.8.2411.7", "1.8.2411.9", "1.8.2411.11", "1.8.2411.13"]:
        print(f"Trying {version}...")
        try:
            url = f"https://www.nuget.org/api/v2/package/Microsoft.Direct3D.D3D12/{version}"
            urllib.request.urlretrieve(url, os.path.join(tempfile.gettempdir(), f"agility_{version}.nupkg"))
            print(f"Downloaded {version}")
            
            # Extract and test
            with tempfile.TemporaryDirectory() as tmpdir:
                nupkg_path = os.path.join(tmpdir, f"agility_{version}.nupkg")
                urllib.request.urlretrieve(f"https://www.nuget.org/api/v2/package/Microsoft.Direct3D.D3D12/{version}", nupkg_path)
                
                extract_dir = os.path.join(tempfile.gettempdir(), f"agility_{version}")
                if os.path.exists(extract_dir):
                    shutil.rmtree(extract_dir)
                os.makedirs(extract_dir)
                
                with zipfile.ZipFile(nupkg_path, 'r') as zf:
                    zf.extractall(extract_dir)
                
                # Find dxc.exe
                dxc_path = None
                for root, dirs, files in os.walk(extract_dir):
                    for f in files:
                        if f == "dxc.exe":
                            dxc_path = os.path.join(root, f)
                            break
                    if dxc_path:
                        break
                
                if dxc_path:
                    # Install
                    install_dir = r"H:\llamadx\dxc_agility"
                    if os.path.exists(install_dir):
                        shutil.rmtree(install_dir)
                    os.makedirs(install_dir, exist_ok=True)
                    
                    # Copy build/native folder
                    native_dir = os.path.dirname(os.path.dirname(dxc_path))
                    for root, dirs, files in os.walk(native_dir):
                        for f in files:
                            src = os.path.join(root, f)
                            rel = os.path.relpath(src, extract_dir)
                            dst = os.path.join(install_dir, rel)
                            os.makedirs(os.path.dirname(dst), exist_ok=True)
                            shutil.copy2(src, dst)
                    
                    # Test
                    dxc_exe = os.path.join(install_dir, "bin", "x64", "dxc.exe")
                    if not os.path.exists(dxc_exe):
                        for root, dirs, files in os.walk(install_dir):
                            if "dxc.exe" in files:
                                dxc_exe = os.path.join(root, "dxc.exe")
                                break
                    
                    if os.path.exists(dxc_exe):
                        result = subprocess.run([dxc_exe, "--version"], capture_output=True, text=True)
                        print(f"Version: {result.stdout.strip()}")
                        
                        result = subprocess.run([dxc_exe, "-help"], capture_output=True, text=True)
                        if "enable-work-graph" in result.stdout:
                            print("SUCCESS: -enable-work-graph flag found!")
                            exit(0)
                        else:
                            print("WARNING: -enable-work-graph flag NOT found")
        except Exception as e:
            print(f"  Failed: {e}")
            continue
    
    print("All attempts failed")