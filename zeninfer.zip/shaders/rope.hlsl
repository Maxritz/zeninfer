// ZenInfer D3D12 backend: rotary position embedding over q or k.
//
// The cos/sin table is built on the HOST and uploaded, deliberately. The angle for
// dimension i is pos * base^(-2i/rotary_dim) with four scaling variants (linear,
// yarn, llama3, dynamic), and the CPU path evaluates that with std::pow/cos/sin in
// double-promoted arithmetic. Recomputing it on the device with powf/cosf/sinf would
// produce last-bit differences against the reference and could flip sampled ids on a
// knife-edge logit, so the kernel only applies a table it was handed. It therefore
// performs the rotation and nothing else: two multiplies and two adds per pair.
//
// Dimension layout matches the CPU `rope` exactly: element i pairs with i + half,
// and the pair rotates as (a*cos - b*sin, a*sin + b*cos).

cbuffer RopeParams : register(b0)
{
    uint heads;       // attention heads in this tensor (H for q, KH for k)
    uint head_dim;    // stride between heads, in floats
    uint pairs;       // rotary_dim / 2, i.e. pairs per head. NOT named `half`: that
                      // is a reserved HLSL type and shadowing it breaks the file.
    uint pad0;
};

ByteAddressBuffer         xraw : register(t0);   // source tensor
StructuredBuffer<float>   cosv : register(t1);   // [half]
StructuredBuffer<float>   sinv : register(t2);   // [half]
RWStructuredBuffer<float> outv : register(u0);   // destination tensor

// One thread per output element, covering the whole head rather than only the rotated
// pairs: dimensions at or past rotary_dim (2 * pairs) are copied through unchanged.
// The previous version launched heads*pairs threads and left those dimensions unwritten,
// so a partial-rotary model read back whatever the destination buffer already held.
//
// Element j of a head takes its angle index from min(j, j - pairs): j < pairs is the
// first half of a pair, pairs <= j < 2*pairs the second half, and both index i.
[numthreads(256, 1, 1)]
void Rope(uint3 gid : SV_GroupID, uint tid : SV_GroupThreadID)
{
    const uint idx = gid.x * 256u + tid;
    const uint total = heads * head_dim;
    if (idx >= total)
    {
        return;
    }

    const uint h = idx / head_dim;
    const uint j = idx - h * head_dim;
    const uint base = h * head_dim;

    if (j >= pairs * 2u)
    {
        outv[idx] = asfloat(xraw.Load(idx * 4u));
        return;
    }

    const uint i = (j < pairs) ? j : (j - pairs);
    const float a = asfloat(xraw.Load((base + i) * 4u));
    const float b = asfloat(xraw.Load((base + i + pairs) * 4u));
    const float c = cosv[i];
    const float s = sinv[i];

    outv[idx] = (j < pairs) ? (a * c - b * s) : (a * s + b * c);
}
