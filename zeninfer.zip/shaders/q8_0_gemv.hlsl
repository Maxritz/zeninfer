// ZenInfer D3D12 backend: Q8_0 matrix-vector product (decode path) with DP4a support.
// DP4a (Dot Product 4 Accumulate) performs 4x int8 dot product + int32 accumulate
// in a single instruction. Requires Shader Model 6.7 (cs_6_7) or later.
// Available in Agility SDK 1.722+ (DXC 1.8.2411+).
//
// Layout: 256 threads per group, 8 rows per group, one warp (32 lanes) per row.
// Each thread processes 8 int8 elements per DP4a instruction (2 DP4a per block).
//
// Fallback: fp32 path (cs_6_0) when DP4a not supported.

cbuffer GemvParams : register(b0)
{
    uint rows;
    uint blocks_per_row;
    uint rows_per_group;
    uint reserved;
};

cbuffer ActivationQuantParams : register(b1)
{
    float act_scale;        // activation quantization scale (per-tensor)
    float act_scale_inv;    // 1.0f / act_scale
    uint  pad0;
    uint  pad1;
};

ByteAddressBuffer         qbuf : register(t0);   // packed int8 weights (4 bytes per 4 elements)
StructuredBuffer<float>   sbuf : register(t1);   // one fp32 scale per block
ByteAddressBuffer         xraw : register(t2);   // fp32 input vector (for fallback)
RWStructuredBuffer<float> yvec : register(u0);  // fp32 output vector
// NOTE: yvec was register(u1) in a future scheme that also adds
// RWByteAddressBuffer xqbuf + ActivationQuantParams(b1) for the DP4a
// activation-quantization path. That scheme needs host wiring (root-signature
// extension + GPU activation buffer + per-token activation scale) that is not
// implemented yet, so the module now matches the restored 5-param host signature:
// CBV b0, SRV t0-t2, UAV u0 = output. The DP4a path below stays compiled out
// (-D DP4A_SUPPORTED was removed from the CSO rule) until that wiring lands as
// the env-gated HW-MMA workstream; re-adding it then needs its own register plan
// (e.g. xqbuf at u1 with an extended root signature) since yvec owns u0 now.

#define STAGE_LIMIT_BLOCKS 128u   // cols <= 4096 fits in the 16 KB staging tile
#define XSTAGE_FLOATS      4096u
#define LANES              32u    // one warp per row

groupshared float xs[XSTAGE_FLOATS];
groupshared int   red[256];   // int32 accumulators for DP4a path

// Quantize fp32 to int8 with saturation
int quantize_fp32_to_int8(float v, float scale)
{
    int i = int(v * scale + 0.5f);
    return min(max(i, -128), 127);
}

// Fallback fp32 path (cs_6_0 compatible)
[numthreads(256, 1, 1)]
void GemvQ8_0_FP32(uint3 gid : SV_GroupID, uint tid : SV_GroupThreadID)
{
    const uint local_row = tid / LANES;
    const uint lane      = tid % LANES;
    const uint row       = gid.x * rows_per_group + local_row;

    const bool stage = blocks_per_row <= STAGE_LIMIT_BLOCKS;
    if (stage)
    {
        const uint total = blocks_per_row * 32u;
        for (uint i = tid * 4u; i < total; i += 1024u)
        {
            const float4 v = asfloat(xraw.Load<float4>(i * 4u));
            xs[i] = v.x;
            xs[i + 1u] = v.y;
            xs[i + 2u] = v.z;
            xs[i + 3u] = v.w;
        }
        GroupMemoryBarrierWithGroupSync();
    }

    float acc = 0.0f;
    if (row < rows)
    {
        const uint qbase = row * blocks_per_row * 32u;
        const uint sbase = row * blocks_per_row;

        for (uint b = lane; b < blocks_per_row; b += LANES)
        {
            const float scale = sbuf[sbase + b];
            const uint  xoff  = b * 32u;
            const uint  qoff  = qbase + b * 32u;

            const uint4 v0 = qbuf.Load<uint4>(qoff);
            const uint4 v1 = qbuf.Load<uint4>(qoff + 16u);

            uint w[8] = { v0.x, v0.y, v0.z, v0.w, v1.x, v1.y, v1.z, v1.w };
            float part = 0.0f;
            [unroll]
            for (uint k = 0; k < 8u; ++k)
            {
                const uint   xo = xoff + k * 4u;
                const float4 xv = stage
                    ? float4(xs[xo], xs[xo + 1u], xs[xo + 2u], xs[xo + 3u])
                    : asfloat(xraw.Load<float4>(xo * 4u));

                part += ((float)(w[k] & 0xFF) - 256.0f * (float)((w[k] >> 7) & 1u)) * xv.x
                      + ((float)((w[k] >> 8) & 0xFF) - 256.0f * (float)(((w[k] >> 8) >> 7) & 1u)) * xv.y
                      + ((float)((w[k] >> 16) & 0xFF) - 256.0f * (float)(((w[k] >> 16) >> 7) & 1u)) * xv.z
                      + ((float)((w[k] >> 24) & 0xFF) - 256.0f * (float)(((w[k] >> 24) >> 7) & 1u)) * xv.w;
            }
            acc += scale * part;
        }
    }

    red[tid] = int(acc * 1000000.0f); // Hack: store float as int for reduction
    GroupMemoryBarrierWithGroupSync();
    if (lane == 0u && row < rows)
    {
        float total = 0.0f;
        [unroll]
        for (uint i = 0u; i < LANES; ++i)
        {
            total += red[tid + i] / 1000000.0f;
        }
        yvec[row] = total;
    }
}

// DP4a path: quantize activations to int8, use DP4a for int8·int8→int32
// Requires: cs_6_7 (Shader Model 6.7), DXC 1.8.2411+ (Agility 1.722+)
#if defined(DP4A_SUPPORTED)
[numthreads(256, 1, 1)]
void GemvQ8_0_DP4a(uint3 gid : SV_GroupID, uint tid : SV_GroupThreadID)
{
    const uint local_row = tid / LANES;
    const uint lane      = tid % LANES;
    const uint row       = gid.x * rows_per_group + local_row;

    const bool stage = blocks_per_row <= STAGE_LIMIT_BLOCKS;
    if (stage)
    {
        const uint total = blocks_per_row * 32u;
        for (uint i = tid * 4u; i < total; i += 1024u)
        {
            const float4 v = asfloat(xraw.Load<float4>(i * 4u));
            // Quantize to int8 on the fly
            int4 q = int4(
                quantize_fp32_to_int8(v.x, act_scale),
                quantize_fp32_to_int8(v.y, act_scale),
                quantize_fp32_to_int8(v.z, act_scale),
                quantize_fp32_to_int8(v.w, act_scale)
            );
            // Pack into 32-bit words for xqbuf
            uint packed = (uint(q.x) & 0xFF) | ((uint(q.y) & 0xFF) << 8) | ((uint(q.z) & 0xFF) << 16) | ((uint(q.w) & 0xFF) << 24);
            xqbuf.Store(i * 4u, packed);
        }
        GroupMemoryBarrierWithGroupSync();
    }

    int acc = 0;
    if (row < rows)
    {
        const uint qbase = row * blocks_per_row * 32u;
        const uint sbase = row * blocks_per_row;

        for (uint b = lane; b < blocks_per_row; b += LANES)
        {
            const float weight_scale = sbuf[sbase + b];
            const uint  qoff  = qbase + b * 32u;

            // Process 32 elements = 8 DP4a instructions (4 elements each)
            for (uint w = 0; w < 32; w += 4)
            {
                const uint qoff_elem = qoff + w;
                
                // Load 4 int8 weights (packed in uint)
                const uint packed_w = qbuf.Load<uint>(qoff_elem);
                
                // Load 4 int8 activations from quantized buffer
                const uint xoff_elem = b * 32u + w;
                const uint packed_a = xqbuf.Load(xoff_elem * 4u);
                
                // DP4a: int8 weights · int8 activations → int32 accumulate
                // Intrinsic: dot4add_i8packed(uint a, uint b, uint c) where a,b are packed int8
                acc = dot4add_i8packed(packed_w, packed_a, acc);
            }
            
            // Apply weight scale and activation scale
            // acc is int32 dot product of int8·int8
            // True value = (acc * weight_scale) / act_scale
            red[tid] = int(acc * weight_scale * act_scale_inv * 1000000.0f);
            acc = 0; // reset for next block
        }
    }

    // Reduce the 32 threads that own this row
    GroupMemoryBarrierWithGroupSync();
    if (lane == 0u && row < rows)
    {
        float total = 0.0f;
        [unroll]
        for (uint i = 0u; i < LANES; ++i)
        {
            total += red[tid + i] / 1000000.0f;
        }
        yvec[row] = total;
    }
}
#endif

// Entry point - selects DP4a path when supported (SM 6.7+)
[numthreads(256, 1, 1)]
void GemvQ8_0(uint3 gid : SV_GroupID, uint tid : SV_GroupThreadID)
{
#ifdef DP4A_SUPPORTED
    GemvQ8_0_DP4a(gid, tid);
#else
    GemvQ8_0_FP32(gid, tid);
#endif
}