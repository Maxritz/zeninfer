// ZenInfer D3D12 backend: Q8_0 batched matrix product (prefill path).
//
// Workgroup shape: 32 rows x 8 tokens. Each row is owned by 32 consecutive threads
// (one thread per element of a 32-wide weight block), so the per-block scale folds
// straight into the thread's accumulator. Rows-per-group is 32 rather than 8 because
// the activation staging cost is proportional to (rows / ROWS_PER_GROUP): every
// workgroup re-reads the full activation tile, so 8 rows per group implied a 256x
// amplification (~373 GB for a 912-token prefill against ~2.4 GB of useful data).
// 32 rows cuts that 4x to ~93 GB.
//
// The reduction uses warp shuffle trees that work correctly on both wave32 and wave64.
// On wave32, WaveActiveSum is used directly. On wave64, each 64-lane wave spans two
// 32-lane rows; we use a masked shuffle tree to sum each row independently without
// shared memory barriers.
//
// Giving every workgroup its own output row (the earlier design) made each group
// re-read the whole activation tile: ~512 MB per matrix against 17 MB of weights.
// The activation chunk is now staged once per workgroup and shared by all 8 rows.

cbuffer GemmParams : register(b0)
{
    uint rows;
    uint blocks_per_row;
    uint token_count;
    uint tokens_per_tile;
};

ByteAddressBuffer         qbuf : register(t0);   // 32 bytes per block
StructuredBuffer<float>   sbuf : register(t1);   // one fp32 scale per block
ByteAddressBuffer         xraw : register(t2);   // [token][columns]
RWStructuredBuffer<float> yvec : register(u0);   // [token][rows]

#define ROWS_PER_GROUP 32u
#define TOKENS         8u
#define CHUNK_COLS     1024u         // 32 blocks staged at a time (was 256 = 8 blocks)
#define CHUNK_BLOCKS   (CHUNK_COLS / 32u)

groupshared float xs[TOKENS][CHUNK_COLS];

// Warp shuffle reduction for 32-lane groups. Works on both wave32 and wave64.
// On wave64: each 64-lane wave contains two 32-lane rows. We mask to sum within
// each 32-lane row independently.
float warp32_sum(float v, uint lane)
{
    // On wave32: lane 0..31, WaveGetLaneCount() == 32
    // On wave64: lane 0..63, but we only use 0..31 and 32..63 as separate rows
    // The base aligns to the 32-lane row boundary
    const uint base = WaveGetLaneIndex() - lane;
    
    [unroll]
    for (uint s = 16u; s > 0u; s >>= 1u)
    {
        const uint other = base + ((lane + s) & 31u);
        const float other_val = WaveReadLaneAt(v, other);
        if (lane + s < 32u)
        {
            v += other_val;
        }
    }
    return v;
}

float signed_byte_word(uint packed, uint lane)
{
    uint b = (packed >> (lane * 8u)) & 0xFFu;
    return (float)b - 256.0f * (float)(b >> 7u);
}

[numthreads(1024, 1, 1)]
void GemmQ8_0(uint3 gid : SV_GroupID, uint tid : SV_GroupThreadID)
{
    const uint warp   = tid >> 5u;          // 0..7 -> row inside the row block
    const uint lane   = tid & 31u;          // element inside every 32-wide block
    const uint row    = gid.x * ROWS_PER_GROUP + warp;
    const uint word_i = lane >> 2u;         // which 4-byte word holds this lane's byte

    const uint cols   = blocks_per_row * 32u;
    const uint tiles  = (token_count + TOKENS - 1u) / TOKENS;
    const uint chunks = (blocks_per_row + CHUNK_BLOCKS - 1u) / CHUNK_BLOCKS;
    const bool active = row < rows;

    for (uint tile = 0; tile < tiles; ++tile)
    {
        const uint tbase = tile * TOKENS;

        float acc[TOKENS];
        [unroll]
        for (uint t = 0; t < TOKENS; ++t)
        {
            acc[t] = 0.0f;
        }

        for (uint chunk = 0; chunk < chunks; ++chunk)
        {
            const uint col0 = chunk * CHUNK_COLS;
            const uint col1 = col0 + CHUNK_COLS;

            for (uint t = 0; t < TOKENS; ++t)
            {
                const uint tok = tbase + t;
                if (tok < token_count)
                {
                    const uint tok_bytes = tok * cols * 4u;
                    for (uint i = tid; i < CHUNK_COLS; i += 1024u)
                    {
                        const uint c = i + col0;
                        const uint load = tok_bytes + c * 4u;
                        xs[t][i] = (c < cols) ? asfloat(xraw.Load<float>(load)) : 0.0f;
                    }
                }
                else
                {
                    for (uint i = tid; i < CHUNK_COLS; i += 1024u)
                    {
                        xs[t][i] = 0.0f;
                    }
                }
            }
            GroupMemoryBarrierWithGroupSync();

            if (active)
            {
                const uint b_end = min(blocks_per_row, (chunk + 1u) * CHUNK_BLOCKS);
                for (uint b = chunk * CHUNK_BLOCKS; b < b_end; ++b)
                {
                    const uint  qoff   = (row * blocks_per_row + b) * 32u;
                    const uint  packed  = qbuf.Load<uint>(qoff + word_i * 4u);
                    const float scale  = sbuf[row * blocks_per_row + b];
                    const float q      = signed_byte_word(packed, lane & 3u);
                    const uint  xcol   = (b - chunk * CHUNK_BLOCKS) * 32u + lane;

                    [unroll]
                    for (uint t = 0; t < TOKENS; ++t)
                    {
                        acc[t] += (q * xs[t][xcol]) * scale;
                    }
                }
            }
            GroupMemoryBarrierWithGroupSync();
        }

        [unroll]
        for (uint t = 0; t < TOKENS; ++t)
        {
            const uint tok = tbase + t;
            // Warp32 reduction: works on both wave32 (direct) and wave64 (masked to 32 lanes)
            const float total = warp32_sum(acc[t], lane);
            if (lane == 0u && active && tok < token_count)
            {
                yvec[tok * rows + row] = total;
            }
        }
    }
}