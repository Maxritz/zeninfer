// ZenInfer D3D12 backend: FlashAttention for prefill with KV cache support.
//
// Tiling strategy:
// - Q block: 32 tokens (processed by one thread block)
// - K/V sub-block: 8 tokens (loaded into shared memory, fits in 32KB)
// - For each Q block, iterate over K/V in sub-blocks of 8 tokens
// - Accumulate partial attention results across K/V sub-blocks
//
// K/V source: KV cache [kv_heads][context][head_dim] with a base offset for the layer.
// Valid K/V tokens: [0..first_pos+T-1] where T=prefill tokens, first_pos=context start.
//
// Shared memory budget: 32KB = 8192 floats
// K_shared: BLOCK_KV * kv_heads * head_dim = 8 * 8 * 64 = 4096 floats
// V_shared: BLOCK_KV * kv_heads * head_dim = 8 * 8 * 64 = 4096 floats
// Total: 8192 floats = 32KB (exactly at limit for kv_heads=8, head_dim=64)

#define MAX_HEADS 64
#define MAX_KV_HEADS 16
#define MAX_HEAD_DIM 128
#define BLOCK_Q 32       // Q tokens per thread block
#define BLOCK_KV 8       // K/V tokens per sub-block (fits in 32KB shared memory)

cbuffer FlashAttnParams : register(b0)
{
    uint tokens;          // number of tokens in prefill (e.g., 128)
    uint heads;           // query heads (e.g., 32)
    uint kv_heads;        // key/value heads (e.g., 8)
    uint head_dim;        // head dimension (e.g., 64)
    float inv_scale;      // 1 / sqrt(head_dim)
    uint kv_cache_base;   // base element offset into KV cache for this layer
    uint kv_cache_stride; // stride between tokens in KV cache (kv_heads * head_dim)
    uint valid_kv_tokens; // number of valid tokens in KV cache (first_pos + T)
    uint pad0;
};

StructuredBuffer<float> qbuf : register(t0);   // [tokens, heads, head_dim] - prefill Q only
StructuredBuffer<float> k_cache : register(t1); // KV cache K [layers*context*kv_heads*head_dim] flat
StructuredBuffer<float> v_cache : register(t2); // KV cache V [layers*context*kv_heads*head_dim] flat
RWStructuredBuffer<float> outbuf : register(u0); // [tokens, heads, head_dim]

// Shared memory for K/V sub-blocks (fits in 32KB for kv_heads=8, head_dim=64)
// BLOCK_KV * kv_heads * head_dim = 8 * 8 * 64 = 4096 floats per buffer
// Total: 8192 floats = 32KB
groupshared float k_shared[8 * 8 * 64];  // [BLOCK_KV][kv_heads * head_dim]
groupshared float v_shared[8 * 8 * 64];

// Warp-level reduction for 32 lanes
float warp_reduce_sum(float val)
{
    for (uint offset = 16; offset > 0; offset >>= 1)
    {
        val += WaveReadLaneAt(val, (WaveGetLaneIndex() + offset) & 31);
    }
    return val;
}

float warp_reduce_max(float val)
{
    for (uint offset = 16; offset > 0; offset >>= 1)
    {
        float other = WaveReadLaneAt(val, (WaveGetLaneIndex() + offset) & 31);
        val = max(val, other);
    }
    return val;
}

[numthreads(256, 1, 1)]
void FlashAttentionWithCache(uint3 gid : SV_GroupID, uint tid : SV_GroupThreadID)
{
    const uint warp_id = tid / 32;
    const uint lane = tid % 32;
    const uint warps_per_block = 256 / 32; // 8 warps
    
    // Block index: which Q block we're processing
    const uint q_block_id = gid.x;
    const uint q_start = q_block_id * BLOCK_Q;
    const uint q_end = min(q_start + BLOCK_Q, tokens);
    const uint q_len = q_end - q_start;
    
    if (q_start >= tokens) return;
    
    const uint group_size = heads / kv_heads; // GQA group size
    const uint head_stride = heads * head_dim;
    const uint kv_head_stride = kv_heads * head_dim;
    
    // Each warp handles a subset of heads for the Q block
    // 8 warps, 32 heads -> 4 heads per warp
    const uint heads_per_warp = (heads + 7) / 8;
    const uint warp_head_start = warp_id * heads_per_warp;
    const uint warp_head_end = min(warp_head_start + heads_per_warp, heads);
    
    if (warp_head_start >= warp_head_end) return;
    
    // Accumulators for each head this warp handles (stored in registers)
    float acc[4][128];  // max 4 heads per warp, max 128 head_dim
    float max_vals[4];
    float sums[4];
    const uint max_heads_per_warp = 4;
    const uint max_head_dim = 128;
    
    for (uint hi = 0; hi < max_heads_per_warp; ++hi)
    {
        max_vals[hi] = -3.402823466e+38f;
        sums[hi] = 0.0f;
        for (uint d = 0; d < max_head_dim; ++d)
            acc[hi][d] = 0.0f;
    }
    
    // Iterate over Q tokens in this block
    for (uint q_rel = 0; q_rel < q_len; ++q_rel)
    {
        const uint q_abs = q_start + q_rel;
        
        // Iterate over K/V sub-blocks from KV cache
        const uint num_kv_blocks = (valid_kv_tokens + BLOCK_KV - 1) / BLOCK_KV;
        
        for (uint kv_block_id = 0; kv_block_id < num_kv_blocks; ++kv_block_id)
        {
            const uint kv_start = kv_block_id * BLOCK_KV;
            const uint kv_end = min(kv_start + BLOCK_KV, valid_kv_tokens);
            const uint kv_len = kv_end - kv_start;
            
            // Causal masking: skip K/V sub-blocks entirely after current Q token
            if (kv_start > q_abs) break;
            
            // Load K/V sub-block from KV cache into shared memory
            // KV cache layout: [kv_cache_base + token * kv_cache_stride + kv_head * head_dim + d]
            const uint load_count = kv_len * kv_heads * head_dim;
            for (uint idx = tid; idx < load_count; idx += 256)
            {
                const uint kv_idx = idx / (kv_heads * head_dim);
                const uint rem = idx % (kv_heads * head_dim);
                const uint kv_head = rem / head_dim;
                const uint d = rem % head_dim;
                const uint token = kv_start + kv_idx;
                
                const uint k_idx = kv_cache_base + token * kv_cache_stride + kv_head * head_dim + d;
                const uint v_idx = kv_cache_base + token * kv_cache_stride + kv_head * head_dim + d;
                
                k_shared[kv_idx * kv_heads * head_dim + rem] = k_cache[k_idx];
                v_shared[kv_idx * kv_heads * head_dim + rem] = v_cache[v_idx];
            }
            GroupMemoryBarrierWithGroupSync();
            
            // Process each head this warp handles
            for (uint hi = 0; hi < heads_per_warp; ++hi)
            {
                const uint h = warp_head_start + hi;
                if (h >= heads) continue;
                
                const uint kv_head = h / (heads / kv_heads);
                const uint h_base = h * head_dim;
                
                // Causal: only attend to K/V tokens <= q_abs
                const uint kv_max = min(kv_end, q_abs + 1);
                const uint kv_actual_len = kv_max - kv_start;
                if (kv_actual_len == 0) continue;
                
                // Compute Q·K^T for this Q token against all K tokens in sub-block
                float scores[8];  // max BLOCK_KV = 8
                float local_max = -3.402823466e+38f;
                
                for (uint kv = 0; kv < kv_actual_len; ++kv)
                    scores[kv] = 0.0f;
                
                // Compute dot products (lane-strided over head_dim)
                for (uint d = lane; d < head_dim; d += 32)
                {
                    const float q_val = qbuf[(q_start + q_rel) * head_stride + h_base + d];
                    
                    for (uint kv = 0; kv < kv_actual_len; ++kv)
                    {
                        const float k_val = k_shared[kv * kv_heads * head_dim + kv_head * head_dim + d];
                        scores[kv] += q_val * k_val;
                    }
                }
                
                // Warp reduction for scores
                for (uint kv = 0; kv < kv_actual_len; ++kv)
                {
                    scores[kv] = warp_reduce_sum(scores[kv]);
                    if (lane == 0)
                    {
                        scores[kv] *= inv_scale;
                        local_max = max(local_max, scores[kv]);
                    }
                }
                
                // Broadcast max across warp
                local_max = warp_reduce_max(local_max);
                
                // Compute exp and sum
                float sum_exp = 0.0f;
                for (uint kv = 0; kv < kv_actual_len; ++kv)
                {
                    if (lane == 0)
                    {
                        scores[kv] = exp(scores[kv] - local_max);
                        sum_exp += scores[kv];
                    }
                }
                
                // Warp reduction for sum
                sum_exp = warp_reduce_sum(sum_exp);
                const float inv_sum = (sum_exp > 0.0f) ? (1.0f / sum_exp) : 0.0f;
                
                // Normalize and accumulate V (online softmax)
                const float old_max = max_vals[hi];
                if (lane == 0)
                {
                    const float new_max = max(old_max, local_max);
                    const float exp_old = exp(old_max - new_max);
                    const float exp_new = exp(local_max - new_max);
                    
                    max_vals[hi] = new_max;
                    sums[hi] = sums[hi] * exp_old + exp_new;
                }
                
                // Warp broadcast new max and sum
                float new_max = WaveReadLaneAt(max_vals[hi], 0);
                float new_sum = WaveReadLaneAt(sums[hi], 0);
                
                // Normalize and accumulate V (online softmax)
                for (uint kv = 0; kv < kv_actual_len; ++kv)
                {
                    float weight = 0.0f;
                    if (lane == 0)
                    {
                        weight = scores[kv] * inv_sum;
                    }
                    weight = WaveReadLaneAt(weight, 0);
                    
                    const float scale = (old_max < new_max) ? exp(max_vals[hi] - new_max) : 1.0f;
                    for (uint d = lane; d < head_dim; d += 32)
                    {
                        acc[hi][d] = acc[hi][d] * scale + weight * v_shared[kv * kv_heads * head_dim + kv_head * head_dim + d];
                    }
                }
                
                max_vals[hi] = new_max;
                sums[hi] = new_sum;
            }
            GroupMemoryBarrierWithGroupSync();
        }
    }
    
    // Write output
    for (uint hi = 0; hi < heads_per_warp; ++hi)
    {
        const uint h = warp_head_start + hi;
        if (h >= heads) continue;
        
        const uint h_base = h * head_dim;
        for (uint q_rel = 0; q_rel < q_len; ++q_rel)
        {
            const uint q_abs = q_start + q_rel;
            for (uint d = lane; d < head_dim; d += 32)
            {
                outbuf[(q_start + q_rel) * head_stride + h_base + d] = acc[hi][d];
            }
        }
    }
}