import urllib.request
import json
import gzip

# Check if dxc is in a separate NuGet package
packages_to_try = [
    "Microsoft.DirectX.DXC",
    "Microsoft.DirectX.Dxc",
    "microsoft.directx.dxc",
    "Microsoft.DirectX.DXC.Compiler",
    "Microsoft.DirectX.DXC.Compiler",
    "DirectXShaderCompiler",
    "Microsoft.DirectXShaderCompiler",
]

for pkg in packages_to_try:
    url = f"https://api.nuget.org/v3/registration5-gz-semver2/{pkg}/index.json"
    req = urllib.request.Request(url)
    req.add_header('Accept-Encoding', 'gzip')
    try:
        with urllib.request.urlopen(req) as response:
            content = response.read()
            if response.headers.get('Content-Encoding') == 'gzip':
                import gzip
                content = gzip.decompress(content)
            data = json.loads(content.decode('utf-8'))
            print(f"SUCCESS: {pkg}")
            versions = []
            for page in data.get('items', []):
                for item in page.get('items', []):
                    version = item.get('catalogEntry', {}).get('version')
                    if version:
                        versions.append(version)
            versions = list(set(versions))
            versions.sort(key=lambda x: tuple(map(int, x.split('.')[:3])), reverse=True)
            print(f"  Found {len(versions)} versions")
            for v in versions[:10]:
                print(f"  {v}")
            break
    except Exception as e:
        print(f"FAILED: {pkg} - {e}")