with open('include/zen/dense_transformer_runtime.h', 'r') as f:
    content = f.read()

# Find the class definition
idx = content.find('class DenseTransformerRuntime')
if idx >= 0:
    # Find the end of the class (};)
    end_idx = content.find('};', content.find('class DenseTransformerRuntime'))
    if end_idx >= 0:
        # Insert missing method declarations before the closing };
        missing_methods = '''
    bool layer_is_recurrent(std::uint32_t layer) const noexcept;
    bool hadamard_folded(const char* suffix, std::size_t layer) const noexcept;
    bool forward_q35_batch(const std::vector<std::uint32_t>& tokens,
                           std::vector<std::vector<float>>& kc,
                           std::vector<std::vector<float>>& vc,
                           std::vector<std::vector<float>>& convc,
                           std::vector<std::vector<float>>& ssmc,
                           std::vector<float>& logits,
                           std::uint32_t start_pos) const;
    bool forward_q35_token(std::uint32_t token, std::uint32_t position,
                           std::vector<std::vector<float>>& kc,
                           std::vector<std::vector<float>>& vc,
                           std::vector<std::vector<float>>& convc,
                           std::vector<std::vector<float>>& ssmc,
                           std::vector<float>& logits,
                           std::uint32_t start_pos) const;
    bool forward_batch(const std::vector<std::uint32_t>& tokens,
                       std::vector<std::vector<float>>& kc,
                       std::vector<std::vector<float>>& vc,
                       std::vector<float>& logits,
                       std::uint32_t start_pos,
                       std::size_t tail_count,
                       std::vector<float>* tail_logits) const;
    bool forward(std::uint32_t token, std::uint32_t pos,
                 std::vector<std::vector<float>>& kc,
                 std::vector<std::vector<float>>& vc,
                 std::vector<float>& logits) const;'''

        new_content = content[:content.rfind('};')] + '\n' + missing_methods + '\n' + content[content.rfind('};'):]
        
        with open('include/zen/dense_transformer_runtime.h', 'w') as f:
            f.write(new_content)
        print('Added missing method declarations!')