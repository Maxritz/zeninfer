with open('include/zen/dense_transformer_runtime.h', 'r') as f:
    lines = f.readlines()

# Remove duplicate method declarations (keep first occurrence)
seen = set()
new_lines = []
for line in lines:
    import re
    match = re.search(r'\bbool\s+(\w+)\s*\(', line)
    if match:
        method = match.group(1)
        if method in seen:
            print(f'Removing duplicate at line: {line.strip()}')
            continue
        seen.add(method)
    new_lines.append(line)

with open('include/zen/dense_transformer_runtime.h', 'w') as f:
    f.writelines(new_lines)

print('Removed duplicates!')