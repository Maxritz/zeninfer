with open('src/adapters/dense_transformer_runtime.cpp', 'r') as f:
    lines = f.readlines()

# Fix: Remove duplicate scope_attn declaration
for i, line in enumerate(lines):
    if line.strip().count('zen::diag::Scope scope_attn("transformer.prefill.attention"') == 2:
        lines[i] = '        {zen::diag::Scope scope_attn("transformer.prefill.attention",zen::diag::Phase::compute);\n'
        print(f'Fixed duplicate scope_attn at line {i+1}')
        break

with open('src/adapters/dense_transformer_runtime.cpp', 'w') as f:
    f.writelines(lines)

print('Fix applied!')