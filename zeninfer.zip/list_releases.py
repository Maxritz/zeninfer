import urllib.request
import json

# List all releases
url = "https://api.github.com/repos/microsoft/DirectXShaderCompiler/releases"

req = urllib.request.Request(url, headers={'Accept': 'application/vnd.github.v3+json'})
with urllib.request.urlopen(req) as response:
    data = json.load(response)
    print(f"Total releases: {len(data)}")
    for release in data[:10]:
        print(f"  {release['tag_name']} - {release['name']} - Assets: {len(release.get('assets', []))}")
        for asset in release.get('assets', []):
            print(f"    {asset['name']} ({asset['size']} bytes)")