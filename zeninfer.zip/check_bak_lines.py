with open('src/adapters/dense_transformer_runtime.cpp.bak', 'r') as f:
    lines = f.readlines()

# Find the duplicate scope_attn
for i, line in enumerate(lines):
    if line.strip().count('zen::diag::Scope scope_attn("transformer.prefill.attention"') == 2:
        print(f'Found duplicate at line {i+1}: {line.strip()[:100]}')
        break

# Find the printf line
for i, line in enumerate(lines):
    if 'std::printf("[d3d12] batched kv append' in line and 'num_tokens=%zu\n"' in line:
        print(f'Found printf at line {i+1}: {line.strip()[:100]}')
        break