import urllib.request
import gzip
import json

# Try different package IDs
packages = [
    "microsoft.directx.dxc",
    "Microsoft.DirectX.DXC",
    "Microsoft.DirectX.Dxc",
    "microsoft.directx.dxc.compiler",
    "Microsoft.DirectX.Dxc.Compiler",
    "DirectXShaderCompiler",
    "Microsoft.DirectXShaderCompiler",
]

for pkg in packages:
    url = f"https://api.nuget.org/v3/registration5-gz-semver2/{pkg}/index.json"
    req = urllib.request.Request(url)
    req.add_header('Accept-Encoding', 'gzip')
    try:
        with urllib.request.urlopen(req) as response:
            content = response.read()
            if response.headers.get('Content-Encoding') == 'gzip':
                content = gzip.decompress(content)
            data = json.loads(content.decode('utf-8'))
            print(f"SUCCESS: {pkg}")
            versions = []
            for page in data.get('items', []):
                for item in page.get('items', []):
                    version = item.get('catalogEntry', {}).get('version')
                    if version:
                        print(f"  {version}")
            break
    except Exception as e:
        print(f"FAILED: {pkg} - {e}")