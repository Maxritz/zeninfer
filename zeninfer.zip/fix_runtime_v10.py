with open('src/adapters/dense_transformer_runtime.cpp', 'r') as f:
    lines = f.readlines()

# Fix the issues:
# 1. Move variable declarations OUTSIDE the scope_rope block (before line 1041)
# 2. Fix printf format string (use \n instead of newline)
# 3. Remove duplicate scope_attn declaration

# Line numbers (0-indexed)
scope_rope_line = 1040  # {zen::diag::Scope scope_rope...
kv_layers_line = 1042   # std::vector<std::size_t> kv_layers;
batched_comment_line = 1076  # // Batched KV cache append for this layer
printf_line = 1080  # std::printf(...)
scope_attn_line = 1085  # duplicate scope_attn

# Fix 1: Move variable declarations BEFORE the scope_rope block
# Insert variable declarations before line 1041 (the scope_rope line)
var_decls = [
    '        // Collect all K/V pointers for batched KV cache append\n',
    '        std::vector<std::size_t> kv_layers;\n',
    '        std::vector<std::size_t> kv_positions;\n',
    '        std::vector<const float*> kv_ks;\n',
    '        std::vector<const float*> kv_vs;\n',
    '        kv_layers.reserve(T);\n',
    '        kv_positions.reserve(T);\n',
    '        kv_ks.reserve(T);\n',
    '        kv_vs.reserve(T);\n',
    '\n',
]

# Remove the duplicate variable declarations inside the scope_rope block (lines 1043-1050)
# Lines 1042-1050 (0-indexed: 1042-1049) contain the duplicate declarations
del lines[1042:1050]  # Remove lines 1043-1050 (0-indexed)

# Insert variable declarations before scope_rope line (line 1041, 0-indexed 1040)
for i, decl in enumerate(var_decls):
    lines.insert(1040 + i, decl)

# Fix 2: Fix printf format string (line 1080 -> 1080 + 8 = 1088 after insertions)
# The printf line has a literal newline in the string, should be \n
# Find the printf line after insertions
for i, line in enumerate(lines):
    if 'std::printf("[d3d12] batched kv append' in line and 'num_tokens=%zu\n"' in line:
        lines[i] = lines[i].replace('num_tokens=%zu\n"', 'num_tokens=%zu\\n"')
        print(f'Fixed printf at line {i+1}')
        break

# Fix 3: Remove duplicate scope_attn declaration (line 1085 -> now shifted)
# Find the duplicate scope_attn line
for i, line in enumerate(lines):
    if line.strip().count('zen::diag::Scope scope_attn("transformer.prefill.attention"') == 2:
        # Replace with single declaration
        lines[i] = '        {zen::diag::Scope scope_attn("transformer.prefill.attention",zen::diag::Phase::compute);\n'
        print(f'Fixed duplicate scope_attn at line {i+1}')
        break

# Write back
with open('src/adapters/dense_transformer_runtime.cpp', 'w') as f:
    f.writelines(lines)

print('Fixes applied!')