import urllib.request
import zipfile
import shutil
import subprocess
import tempfile
import os

# Use the latest 1.8.x release - v1.8.2505.1
url = "https://github.com/microsoft/DirectXShaderCompiler/releases/download/v1.8.2505.1/dxc_2025_07_14.zip"

with tempfile.TemporaryDirectory() as tmpdir:
    zip_path = os.path.join(tmpdir, "dxc.zip")
    
    try:
        print(f"Downloading dxc 1.8.2505.1 from GitHub...")
        urllib.request.urlretrieve(url, zip_path)
        print("Downloaded successfully")
    except urllib.error.HTTPError as e:
        if e.code == 404:
            print(f"Version not found on GitHub releases")
            exit(1)
        else:
            raise
    except Exception as e:
        print(f"Download failed: {e}")
        exit(1)
    
    # Extract and test
    extract_dir = os.path.join(tmpdir, "extract")
    os.makedirs(extract_dir)
    
    with zipfile.ZipFile(zip_path, 'r') as zf:
        zf.extractall(extract_dir)
    
    # Find dxc.exe
    dxc_path = None
    for root, dirs, files in os.walk(extract_dir):
        for f in files:
            if f == "dxc.exe":
                dxc_path = os.path.join(root, f)
                break
        if dxc_path:
            break
    
    if not dxc_path:
        print("dxc.exe not found in package")
        exit(1)
    
    print(f"Found dxc.exe at: {dxc_path}")
    
    # Install to H:\llamadx\update\dxc1.8
    install_dir = r"H:\llamadx\update\dxc1.8"
    if os.path.exists(install_dir):
        shutil.rmtree(install_dir)
    os.makedirs(install_dir, exist_ok=True)
    
    # Copy all files
    for root, dirs, files in os.walk(extract_dir):
        for f in files:
            src = os.path.join(root, f)
            rel = os.path.relpath(src, extract_dir)
            dst = os.path.join(install_dir, rel)
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copy2(src, dst)
    
    # Test
    dxc_exe = os.path.join(install_dir, "bin", "x64", "dxc.exe")
    if not os.path.exists(dxc_exe):
        for root, dirs, files in os.walk(install_dir):
            if "dxc.exe" in files:
                dxc_exe = os.path.join(root, "dxc.exe")
                break
    
    if os.path.exists(dxc_exe):
        result = subprocess.run([dxc_exe, "--version"], capture_output=True, text=True)
        print(f"Version: {result.stdout.strip()}")
        
        result = subprocess.run([dxc_exe, "-help"], capture_output=True, text=True)
        if "enable-work-graph" in result.stdout:
            print("SUCCESS: -enable-work-graph flag found!")
        else:
            print("WARNING: -enable-work-graph flag NOT found")
            print("Help output sample:", result.stdout[:500])
    else:
        print("dxc.exe not found after install")