with open('src/adapters/dense_transformer_runtime.cpp', 'r') as f:
    content = f.read()

# Fix the merged #endifnfig_ issue
content = content.replace('#endifnfig_.use_alibi', '#endif\n                if(!config_.use_alibi')

# Also fix the duplicate block - there's a duplicate block after line 1075
# Find the second duplicate block starting with "nfig_.use_alibi&&device_attention_available"
idx = content.find('\n                kv_layers.push_back(l);\n                kv_positions.push_back(pos);\n                kv_ks.push_back(k.data()+t*KW);\n                kv_vs.push_back(v.data()+t*KW);\n            }\n#endif\n        }}\n        // Batched KV cache append for this layer\n#if defined(ZEN_HAS_D3D12)\n        if(!kv_layers.empty() && !config_.use_alibi && device_attention_available(config_.layers,kc[l].size()/KW,KH,D,config_.rms_epsilon)){')

if 'nfig_.use_alibi&&device_attention_available(config_.layers,kc[l].size()/KW,KH,D,config_.rms_epsilon)){' in content:
    # Find the second occurrence and remove the duplicate
    first = content.find('nfig_.use_alibi&&device_attention_available(config_.layers,kc[l].size()/KW,KH,D,config_.rms_epsilon)){')
    second = content.find('nfig_.use_alibi&&device_attention_available(config_.layers,kc[l].size()/KW,KH,D,config_.rms_epsilon)){', first + 1)
    if second != -1:
        # Find the end of the second duplicate block
        end_idx = content.find('#endif', second)
        if end_idx != -1:
            end_idx = content.find('\n', end_idx)
            if end_idx != -1:
                content = content[:second] + content[end_idx+1:]
                print('Removed duplicate block')

# Also fix the broken printf at line 1087-1088
content = content.replace('std::printf("[d3d12] batched kv append (runtime): layer=%zu num_tokens=%zu\n", l, kv_layers.size());\n", l, kv_layers.size());', 'std::printf("[d3d12] batched kv append (runtime): layer=%zu num_tokens=%zu\\n", l, kv_layers.size());')

# Fix the "endifnfig_" issue
content = content.replace('#endifnfig_.use_alibi', '#endif\n                if(!config_.use_alibi')

with open('src/adapters/dense_transformer_runtime.cpp', 'w') as f:
    f.write(content)

print('Fixes applied!')