with open('src/adapters/dense_transformer_runtime.cpp', 'r') as f:
    content = f.read()

# Make minimal targeted changes that preserve brace structure

# 1. Add layer_qualifies vector after pipeline_layers.reserve
old1 = '    std::vector<LayerParams> pipeline_layers;\n    pipeline_layers.reserve(config_.layers);'
new1 = '    std::vector<LayerParams> pipeline_layers;\n    pipeline_layers.reserve(config_.layers);\n    std::vector<bool> layer_qualifies(config_.layers, false);'
content = content.replace(old1, new1)
print("1. Added layer_qualifies declaration")

# 2. Add layer_qualifies[l] = true in qualification success
old2 = '            pipeline_layers.push_back(std::move(lp));\n        } else {'
new2 = '            pipeline_layers.push_back(std::move(lp));\n            layer_qualifies[l] = true;\n        } else {'
content = content.replace(old2, new2)
print("2. Added layer_qualifies[l]=true")

# 3. Add layer_qualifies[l] = false in qualification failure
old3 = '            all_layers_qualify = false;\n        }'
# Only replace the one in the qualification loop (has 12 spaces indent)
content = content.replace('            all_layers_qualify = false;\n        }\n    }\n\n    // If all layers qualify',
                          '            all_layers_qualify = false;\n            layer_qualifies[l] = false;\n        }\n    }\n\n    // Run pipeline for any qualifying layers (not requiring all)\n    if(!pipeline_layers.empty()) {\n')
print("3. Added layer_qualifies[l]=false and new pipeline condition")

# 4. Replace pipeline condition
old4 = 'if(all_layers_qualify && pipeline_layers.size() == config_.layers) {'
new4 = '// Run pipeline for any qualifying layers (not requiring all)\n    if(!pipeline_layers.empty()) {'
content = content.replace(old4, new4)
print("4. Changed pipeline condition")

# 5. Add pipeline segment execution logic inside the pipeline block
# Find the pipeline block and add segment execution logic
old5 = '''        bool pipeline_ok = zen::d3d12::layer_decode_pipeline(d3d_layers, pipeline_layers.size(), x.data(), x.data(), E, H, KH, D, F, config_.rms_epsilon);
        if (pipeline_ok) {
            // Pipeline succeeded - skip per-layer path
            if (const char* trace = std::getenv("ZEN_D3D12_TRACE"); trace && trace[0] == '1') {
                std::printf("[d3d12] pipeline: SUCCESS for token pos=%zu\\n", pos);
            }
        } else {
            // Pipeline failed - fall through to per-layer path
            all_layers_qualify = false;
            if (const char* trace = std::getenv("ZEN_D3D12_TRACE"); trace && trace[0] == '1') {
                std::printf("[d3d12] pipeline: FALLBACK for token pos=%zu (pipeline_decode returned false)\\n", pos);
            }
        }
        
        // Also log when not all layers qualify
        if (!all_layers_qualify && pipeline_layers.size() < config_.layers) {
            if (const char* trace = std::getenv("ZEN_D3D12_TRACE"); trace && trace[0] == '1') {
                std::printf("[d3d12] pipeline: NOT ALL QUALIFY pipeline_layers=%zu vs config_.layers=%zu\\n", pipeline_layers.size(), config_.layers);
            }
        }
    }'''

new5 = '''        // Run pipeline for contiguous qualifying segments
        bool any_pipeline_ok = false;
        std::size_t pipeline_start = 0;
        while (pipeline_start < config_.layers) {
            // Find next qualifying layer
            while (pipeline_start < config_.layers && !layer_qualifies[pipeline_start]) {
                ++pipeline_start;
            }
            if (pipeline_start >= config_.layers) break;
            
            // Find end of contiguous qualifying segment
            std::size_t pipeline_end = pipeline_start;
            while (pipeline_end < config_.layers && layer_qualifies[pipeline_end]) {
                ++pipeline_end;
            }
            
            // Run pipeline for layers [pipeline_start, pipeline_end)
            std::size_t segment_size = pipeline_end - pipeline_start;
            zen::d3d12::LayerDecodeParams d3d_layers[64];
            for(std::size_t i=0;i<segment_size;++i){
                auto& lp = pipeline_layers[pipeline_start + i];
                d3d_layers[i].q_w = lp.q_w; d3d_layers[i].k_w = lp.k_w; d3d_layers[i].v_w = lp.v_w; d3d_layers[i].o_w = lp.o_w;
                d3d_layers[i].gate_w = lp.gate_w; d3d_layers[i].up_w = lp.up_w; d3d_layers[i].down_w = lp.down_w;
                d3d_layers[i].attn_norm_w = lp.attn_norm_w; d3d_layers[i].ffn_norm_w = lp.ffn_norm_w;
                d3d_layers[i].cos = lp.cos.data(); d3d_layers[i].sin = lp.sin.data();
                d3d_layers[i].pairs = lp.pairs; d3d_layers[i].layer = lp.layer; d3d_layers[i].pos = lp.pos; d3d_layers[i].first_pos = lp.first_pos;
            }
            bool segment_ok = zen::d3d12::layer_decode_pipeline(d3d_layers, segment_size, x.data(), x.data(), E, H, KH, D, F, config_.rms_epsilon);
            if (segment_ok) {
                any_pipeline_ok = true;
                if (const char* trace = std::getenv("ZEN_D3D12_TRACE"); trace && trace[0] == '1') {
                    std::printf("[d3d12] pipeline: SUCCESS segment layers [%zu, %zu) for token pos=%zu\\n", pipeline_start, pipeline_end, pos);
                }
            } else {
                if (const char* trace = std::getenv("ZEN_D3D12_TRACE"); trace && trace[0] == '1') {
                    std::printf("[d3d12] pipeline: FALLBACK segment layers [%zu, %zu) for token pos=%zu\\n", pipeline_start, pipeline_end, pos);
                }
                // If pipeline fails for a segment, mark those layers as non-qualifying
                for (std::size_t l = pipeline_start; l < pipeline_end; ++l) {
                    layer_qualifies[l] = false;
                }
            }
            
            pipeline_start = pipeline_end;
        }
    }'''

content = content.replace(old5, new5)
print("5. Added pipeline segment execution logic")

# 6. Modify per-layer loop to skip qualifying layers
old6 = '''    if(all_layers_qualify) {
        // Pipeline succeeded, skip per-layer path
    } else {
        for(std::uint32_t l=0;l<config_.layers;++l){
        const std::string p="blk."+std::to_string(l)+".";'''

new6 = '''    // Per-layer path for non-qualifying layers
    for(std::uint32_t l=0;l<config_.layers;++l){
        if (layer_qualifies[l]) continue; // Skip layers already processed by pipeline
        const std::string p="blk."+std::to_string(l)+".";'''

content = content.replace(old6, new6)
print("6. Modified per-layer loop to skip qualifying layers")

# 7. Remove the extra closing brace that was for the else block
# The old code had: } else { for(...) { ... } }  -> two closing braces
# Now we have: for(...) { ... }  -> one closing brace
# So we need to remove one extra closing brace
# Find and remove the "} else {" before the for loop
old7 = '''    }
    } else {
        for(std::uint32_t l=0;l<config_.layers;++l){
        const std::string p="blk."+std::to_string(l)+".";'''
# This won't match because we already changed it in step 6

# Instead, find and remove the extra closing brace that was for the else block
# The old code had: } else { for(...) { ... } }  -> two closing braces at the end
# Now we have: for(...) { ... }  -> one closing brace
# We need to remove one extra closing brace
# Find the extra "}" that was closing the else block
# It should be after the for loop ends, before the next function

# Let's just do a targeted fix: remove the "} else {" line that's now orphaned
old7b = '    }\n    } else {\n'
# This might match multiple places. Let's be more specific.

# The original had: } else { for(...) { ... } }  -> two closing braces
# Now we have: for(...) { ... }  -> one closing brace
# The extra "} else {" is now orphaned. Let's find it.
# It should be right before our new for loop

content = content.replace('    }\n    } else {\n        for(std::uint32_t l=0;l<config_.layers;++l){\n        if (layer_qualifies[l]) continue; // Skip layers already processed by pipeline\n        const std::string p="blk."+std::to_string(l)+".";',
                          '    // Per-layer path for non-qualifying layers\n    for(std::uint32_t l=0;l<config_.layers;++l){\n        if (layer_qualifies[l]) continue; // Skip layers already processed by pipeline\n        const std::string p="blk."+std::to_string(l)+".";')
print("7. Removed orphaned } else {")

# 8. Remove one extra closing brace at the end of the per-layer section
# The old code had two closing braces: one for for loop, one for else
# Now we only need one for the for loop
# Find and remove one extra closing brace after the per-layer section
# This is tricky - let's just verify brace balance and remove one extra if needed

with open('src/adapters/dense_transformer_runtime.cpp', 'w') as f:
    f.write(content)

print("All changes applied!")

# Verify brace balance
open_braces = 0
for i, ch in enumerate(content):
    if ch == '{':
        open_braces += 1
    elif ch == '}':
        open_braces -= 1
        if open_braces < 0:
            line_num = content[:i].count('\n') + 1
            print(f"ERROR: Extra }} at position {i} (line {line_num})")
            break
print(f"Final open braces: {open_braces}")