// ZenInfer Direct3D 12.1 compute backend.
//
// Scope: the Q8_0 matrix-vector (decode) and matrix-matrix (prefill) products that
// dominate both phases. Everything else stays on the CPU, so the transformer logic
// is untouched and the backend can always fall back.
//
// Why this is worth doing: decode re-reads the entire weight file once per token
// (~1.32 GB for Llama-3.2-1B-Q8_0) from DDR4. The same stream served from GDDR6 is
// an order of magnitude faster, provided the weights are repacked into VRAM once.

#ifdef ZEN_HAS_D3D12

#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>

#include <intrin.h>

#include <d3d12.h>
#include <dxgi1_6.h>
#include <wrl/client.h>

#include <algorithm>
#include <chrono>
#include <cstdlib>
#include <cstdio>
#include <iostream>
#include <cstring>
#include <mutex>
#include <string>
#include <unordered_map>
#include <vector>

#include "q8_0_gemm_cso.h"
#include "q8_0_gemv_dp4a_cso.h"
#include "q8_0_gemv_fp32_cso.h"
#include "silu_mul_cso.h"
#include "addn_cso.h"
#include "rmsnorm_cso.h"
#include "rope_cso.h"
#include "attention_cso.h"
#include "flash_attention_cso.h"
#include "repack.h"
#include "zen/d3d12_backend.h"

using Microsoft::WRL::ComPtr;

namespace zen::d3d12 {

// STRACE-style breadcrumb tracing for D3D12 backend
static inline void d3d12_trace(const char* comp, const char* evt, const char* fmt, ...) {
    const char* trace = std::getenv("ZEN_D3D12_TRACE");
    if (!trace || trace[0] != '1') return;
    va_list args;
    va_start(args, fmt);
    std::fprintf(stderr, "STRACE component=%s event=%s ", comp, evt);
    std::vfprintf(stderr, fmt, args);
    std::fprintf(stderr, "\n");
    va_end(args);
}

static inline void d3d12_trace_scope(const char* comp, const char* evt, const char* fmt, ...) {
    const char* trace = std::getenv("ZEN_D3D12_TRACE");
    if (!trace || trace[0] != '1') return;
    va_list args;
    va_start(args, fmt);
    std::fprintf(stderr, "STRACE component=%s event=%s:enter ", comp, evt);
    std::vfprintf(stderr, fmt, args);
    std::fprintf(stderr, "\n");
    va_end(args);
}

static inline void d3d12_trace_scope_end(const char* comp, const char* evt) {
    const char* trace = std::getenv("ZEN_D3D12_TRACE");
    if (!trace || trace[0] != '1') return;
    std::fprintf(stderr, "STRACE component=%s event=%s:exit\n", comp, evt);
}

// Auto RAII scope timer
struct TraceScope {
    const char* comp;
    const char* evt;
    TraceScope(const char* c, const char* e, const char* fmt, ...) : comp(c), evt(e) {
        va_list args;
        va_start(args, fmt);
        d3d12_trace_scope(comp, evt, fmt, args);
        va_end(args);
    }
    ~TraceScope() { d3d12_trace_scope_end(comp, evt); }
};

#define STRACE(comp, evt, fmt, ...) d3d12_trace(comp, evt, fmt, __VA_ARGS__)
#define STRACE_SCOPE(comp, evt, fmt, ...) TraceScope __ts_##__LINE__(comp, evt, fmt, __VA_ARGS__)

// Defined in agility_export.cpp. Declared outside the anonymous namespace so the
// reference below binds to the exported object rather than a new internal symbol.
unsigned agility_version() noexcept;

// ============================================================================
// D3D12 Feature Support Detection (Agility SDK 1.722+)
// ============================================================================

struct D3D12FeatureSupport {
    // OPTIONS12
    bool enhanced_barriers = false;
    bool relaxed_format_casting = false;
    
    // OPTIONS13
    bool unrestricted_buffer_texture_copy = false;
    bool unrestricted_vertex_alignment = false;
    
    // OPTIONS14
    bool advanced_texture_ops = false;
    bool writeable_msaa = false;
    
    // OPTIONS15
    bool triangle_fan = false;
    bool dynamic_index_buffer_strip = false;
    
    // OPTIONS16
    bool dynamic_depth_bias = false;
    bool gpu_upload_heap = false;
    
    // OPTIONS17
    bool non_normalized_samplers = false;
    bool manual_write_tracking = false;
    
    // OPTIONS18
    bool render_passes_valid = false;
    
    // OPTIONS19
    bool mismatching_output_dims = false;
    bool compute_only_custom_heap = false;
    
    // OPTIONS20
    bool compute_only_write_watch = false;
    
    // OPTIONS21
    int work_graphs_tier = 0;  // 0=unsupported, 10=1.0, 11=1.1
    int execute_indirect_tier = 0;
    bool sample_cmp_gradient_bias = false;
    bool extended_command_info = false;
    
    // OPTIONS22 (may not be in all SDKs)
    bool shader_execution_reordering = false;
    bool create_byte_offset_views = false;
    uint32_t max_1d_dispatch = 0;
    uint32_t max_1d_dispatch_mesh = 0;
    
    // Architecture
    bool uma = false;
    uint32_t shader_model = 0;
    int resource_binding_tier = 0;
};

D3D12FeatureSupport g_features;

// Forward declaration
struct State;

// Function declarations (defined after State)
void query_d3d12_features(State& s);
void enhanced_barrier(State& s, ID3D12Resource* resource,
                      D3D12_RESOURCE_STATES before, D3D12_RESOURCE_STATES after);
void enhanced_barrier_begin(State& s, ID3D12Resource* resource,
                            D3D12_RESOURCE_STATES before, D3D12_RESOURCE_STATES after,
                            D3D12_RESOURCE_BARRIER* out_barrier);
void enhanced_barrier_end(State& s, D3D12_RESOURCE_BARRIER* barrier);

// ============================================================================
// Constants
// ============================================================================

constexpr std::uint32_t kElemsPerBlock = 32;
constexpr std::uint32_t kRawBlockBytes = 34;
// One warp per row in q8_0_gemv.hlsl, so 8 rows per 256-thread group. The shader
// derives local_row as tid/32, which only lines up if this stays 8.
constexpr std::uint32_t kRowsPerGroup = 8;
// The GEMM shader blocks 8 output rows per workgroup (ROWS_PER_GROUP in the HLSL),
// which is independent of the GEMV shader's row-block size above.
// Must match ROWS_PER_GROUP in q8_0_gemm.hlsl: the shader takes rows-per-workgroup
// as a compile-time constant, so a mismatch here silently under- or over-dispatches.
constexpr std::uint32_t kGemmRowsPerGroup = 32;
constexpr std::uint32_t kTokensPerTile = 8;
// Below this many elements a dispatch costs more than the arithmetic it saves.
constexpr std::size_t kMinElements = 256u * 1024u;
constexpr std::uint64_t kVRAMBudgetPercent = 80;
constexpr double kSpinWaitUs = 2000.0;

struct GemvParams {
    std::uint32_t rows;
    std::uint32_t blocks_per_row;
    std::uint32_t rows_per_group;
    std::uint32_t reserved;
};

struct GemmParams {
    std::uint32_t rows;
    std::uint32_t blocks_per_row;
    std::uint32_t token_count;
    std::uint32_t tokens_per_tile;
};

struct WeightEntry {
    // One resource holds [quants | 256B pad | scales]. Two committed resources per
    // tensor cost ~0.85ms each (every CreateCommittedResource creates its own implicit
    // heap), measured at 191ms of a 476ms staging pass across 112 tensors. scales_va
    // points into this same buffer, so holding `quants` keeps both alive - which is
    // also what preserves the F-09 lifetime guarantee.
    ComPtr<ID3D12Resource> quants;  // 32 bytes per block, 16-byte aligned
    std::uint64_t scales_va{};      // quants GPU VA + scale_offset
    std::size_t rows{};
    std::size_t columns{};
};

// Component tags for the trace table. Each maps to the code path that owns one
// command list (and therefore one fence wait), which is the unit that actually costs.
enum class Comp : int {
    Projections,  // gemv_batch_locked: qkv and attn-out matvec lists
    FfnUpDown,    // gemv_ffn_locked: gate|up + SiLU + down in one list
    FfnFused,     // ffn_residual_fused_locked: 8 dispatches in one list
    Norms,        // rms_norm_locked
    Residual,     // addn_locked
    Count
};

struct State {
    std::mutex mutex;
    bool ready{};
    bool failed{};
    AdapterInfo adapter{};
    Stats stats{};

    ComPtr<ID3D12Device> device;
    ComPtr<ID3D12CommandQueue> queue;
    ComPtr<ID3D12CommandAllocator> allocator;
    ComPtr<ID3D12GraphicsCommandList> list;
    ComPtr<ID3D12Fence> fence;
    HANDLE fence_event{};
    std::uint64_t fence_value{};
    ComPtr<ID3D12RootSignature> root;
    ComPtr<ID3D12PipelineState> pso_gemv;
    ComPtr<ID3D12PipelineState> pso_rope;
    ComPtr<ID3D12PipelineState> pso_attn;

    // Device-resident KV cache, [layers][kv_heads][context][head_dim] floats, with k and
    // v in separate buffers. Configured once per model by kv_cache_configure; the
    // attention block appends at `pos` with a device-to-device copy, so k and v never
    // travel to the host.
    ComPtr<ID3D12Resource> kcache;
    ComPtr<ID3D12Resource> vcache;
    std::size_t kv_layers{};
    std::size_t kv_context{};
    std::size_t kv_heads{};
    std::size_t kv_head_dim{};

    // Small CPU-visible operands for the attention block. Upload heaps mean the host
    // writes them directly, so the block needs no staging copy for q/k/v or the table.
    ComPtr<ID3D12Resource> dq, dk, dv, dqr, dkr, dcos, dsin, datt;
    // Third activation arena for the whole-layer path: the first residual base has to
    // stay readable while another buffer is being written, and two arenas cannot hold
    // it alongside everything else.
    ComPtr<ID3D12Resource> hbuf;
    std::size_t h_cap{};
    void* dq_cpu{};
    void* dk_cpu{};
    void* dv_cpu{};
    void* dqr_cpu{};
    void* dkr_cpu{};
    void* dcos_cpu{};
    void* dsin_cpu{};
    // One capacity per buffer: sharing a single cap made a smaller buffer look
    // large enough as soon as a bigger sibling had been sized first.
    std::size_t dq_cap{}, dk_cap{}, dv_cap{}, dqr_cap{}, dkr_cap{};
    std::size_t dcos_cap{}, dsin_cap{}, datt_cap{};
    ComPtr<ID3D12PipelineState> pso_gemm;
    ComPtr<ID3D12PipelineState> pso_silu;
    ComPtr<ID3D12PipelineState> pso_rms;
    ComPtr<ID3D12PipelineState> pso_addn;
    ComPtr<ID3D12PipelineState> pso_flash_attn;

    // Async copy queue for KV cache operations (overlaps with compute)
    ComPtr<ID3D12CommandQueue> copy_queue;
    ComPtr<ID3D12CommandAllocator> copy_allocator;
    ComPtr<ID3D12GraphicsCommandList> copy_list;
    ComPtr<ID3D12Fence> copy_fence;
    HANDLE copy_fence_event{};
    std::uint64_t copy_fence_value{};

    ComPtr<ID3D12Resource> params;
    void* params_cpu{};
    ComPtr<ID3D12Resource> xbuf;
    void* x_cpu{};
    std::size_t x_cap{};
    ComPtr<ID3D12Resource> ybuf;
    ComPtr<ID3D12Resource> yread;
    ComPtr<ID3D12Resource> fbuf;
    std::size_t f_cap{};
    ComPtr<ID3D12Resource> wbuf;
    void* w_cpu{};
    std::size_t w_cap{};
    // Third upload operand, needed by the fused FFN path: it feeds an activation, a
    // residual base and a norm weight to one command list at the same time.
    ComPtr<ID3D12Resource> nbuf;
    void* n_cpu{};
    std::size_t n_cap{};
    std::size_t y_cap{};
    ComPtr<ID3D12Resource> stage;
    void* stage_cpu{};
    std::size_t stage_cap{};

    bool trace{};
    bool no_readback{};
    ComPtr<ID3D12QueryHeap> ts_heap;
    ComPtr<ID3D12Resource> ts_read;
    std::uint64_t ts_freq{};

    // Per-component trace accumulators (ZEN_D3D12_TRACE=1).
    struct CompStat {
        std::uint64_t ops{};
        std::uint64_t dev_us{};
        std::uint64_t wait_us{};
    };
    CompStat comp_stats[static_cast<int>(Comp::Count)]{};
    Comp current_comp{Comp::Projections};

    std::unordered_map<const void*, WeightEntry> weights;
    std::uint64_t weight_bytes{};
};

// ============================================================================
// D3D12 Feature Support Detection Implementation
// ============================================================================

// Maps legacy D3D12_RESOURCE_STATES to new BARRIER_LAYOUT
D3D12_BARRIER_LAYOUT state_to_layout(D3D12_RESOURCE_STATES state) {
    // Simplified mapping for compute-only resources
    if (state & D3D12_RESOURCE_STATE_UNORDERED_ACCESS) return D3D12_BARRIER_LAYOUT_UNORDERED_ACCESS;
    if (state & D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE) return D3D12_BARRIER_LAYOUT_SHADER_RESOURCE;
    if (state & D3D12_RESOURCE_STATE_COPY_DEST) return D3D12_BARRIER_LAYOUT_COPY_DEST;
    if (state & D3D12_RESOURCE_STATE_COPY_SOURCE) return D3D12_BARRIER_LAYOUT_COPY_SOURCE;
    if (state & D3D12_RESOURCE_STATE_COMMON) return D3D12_BARRIER_LAYOUT_COMMON;
    if (state & D3D12_RESOURCE_STATE_GENERIC_READ) return D3D12_BARRIER_LAYOUT_GENERIC_READ;
    return D3D12_BARRIER_LAYOUT_COMMON;
}

D3D12_BARRIER_SYNC state_to_sync(D3D12_RESOURCE_STATES state) {
    if (state & D3D12_RESOURCE_STATE_UNORDERED_ACCESS) return D3D12_BARRIER_SYNC_COMPUTE_SHADING;
    if (state & D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE) return D3D12_BARRIER_SYNC_COMPUTE_SHADING;
    if (state & D3D12_RESOURCE_STATE_COPY_DEST) return D3D12_BARRIER_SYNC_COPY;
    if (state & D3D12_RESOURCE_STATE_COPY_SOURCE) return D3D12_BARRIER_SYNC_COPY;
    return D3D12_BARRIER_SYNC_NONE;
}

void query_d3d12_features(State& s) {
    // OPTIONS12
    D3D12_FEATURE_DATA_D3D12_OPTIONS12 opts12{};
    if (SUCCEEDED(s.device->CheckFeatureSupport(D3D12_FEATURE_D3D12_OPTIONS12, &opts12, sizeof(opts12)))) {
        g_features.enhanced_barriers = opts12.EnhancedBarriersSupported;
        g_features.relaxed_format_casting = opts12.RelaxedFormatCastingSupported;
    }
    
    // OPTIONS13
    D3D12_FEATURE_DATA_D3D12_OPTIONS13 opts13{};
    if (SUCCEEDED(s.device->CheckFeatureSupport(D3D12_FEATURE_D3D12_OPTIONS13, &opts13, sizeof(opts13)))) {
        g_features.unrestricted_buffer_texture_copy = opts13.UnrestrictedBufferTextureCopyPitchSupported;
        g_features.unrestricted_vertex_alignment = opts13.UnrestrictedVertexElementAlignmentSupported;
    }
    
    // OPTIONS14
    D3D12_FEATURE_DATA_D3D12_OPTIONS14 opts14{};
    if (SUCCEEDED(s.device->CheckFeatureSupport(D3D12_FEATURE_D3D12_OPTIONS14, &opts14, sizeof(opts14)))) {
        g_features.advanced_texture_ops = opts14.AdvancedTextureOpsSupported;
        g_features.writeable_msaa = opts14.WriteableMSAATexturesSupported;
    }
    
    // OPTIONS15
    D3D12_FEATURE_DATA_D3D12_OPTIONS15 opts15{};
    if (SUCCEEDED(s.device->CheckFeatureSupport(D3D12_FEATURE_D3D12_OPTIONS15, &opts15, sizeof(opts15)))) {
        g_features.triangle_fan = opts15.TriangleFanSupported;
        g_features.dynamic_index_buffer_strip = opts15.DynamicIndexBufferStripCutSupported;
    }
    
    // OPTIONS16
    D3D12_FEATURE_DATA_D3D12_OPTIONS16 opts16{};
    if (SUCCEEDED(s.device->CheckFeatureSupport(D3D12_FEATURE_D3D12_OPTIONS16, &opts16, sizeof(opts16)))) {
        g_features.dynamic_depth_bias = opts16.DynamicDepthBiasSupported;
        g_features.gpu_upload_heap = opts16.GPUUploadHeapSupported;
    }
    
    // OPTIONS17
    D3D12_FEATURE_DATA_D3D12_OPTIONS17 opts17{};
    if (SUCCEEDED(s.device->CheckFeatureSupport(D3D12_FEATURE_D3D12_OPTIONS17, &opts17, sizeof(opts17)))) {
        g_features.non_normalized_samplers = opts17.NonNormalizedCoordinateSamplersSupported;
        g_features.manual_write_tracking = opts17.ManualWriteTrackingResourceSupported;
    }
    
    // OPTIONS18
    D3D12_FEATURE_DATA_D3D12_OPTIONS18 opts18{};
    if (SUCCEEDED(s.device->CheckFeatureSupport(D3D12_FEATURE_D3D12_OPTIONS18, &opts18, sizeof(opts18)))) {
        g_features.render_passes_valid = opts18.RenderPassesValid;
    }
    
    // OPTIONS19
    D3D12_FEATURE_DATA_D3D12_OPTIONS19 opts19{};
    if (SUCCEEDED(s.device->CheckFeatureSupport(D3D12_FEATURE_D3D12_OPTIONS19, &opts19, sizeof(opts19)))) {
        g_features.mismatching_output_dims = opts19.MismatchingOutputDimensionsSupported;
        g_features.compute_only_custom_heap = opts19.ComputeOnlyCustomHeapSupported;
    }
    
    // OPTIONS21
    D3D12_FEATURE_DATA_D3D12_OPTIONS21 opts21{};
    if (SUCCEEDED(s.device->CheckFeatureSupport(D3D12_FEATURE_D3D12_OPTIONS21, &opts21, sizeof(opts21)))) {
        g_features.execute_indirect_tier = static_cast<int>(opts21.ExecuteIndirectTier);
        g_features.sample_cmp_gradient_bias = opts21.SampleCmpGradientAndBiasSupported;
        g_features.extended_command_info = opts21.ExtendedCommandInfoSupported;
    }
    
    // OPTIONS22 (may not be in all SDKs - guard with macro check)
#if defined(D3D12_FEATURE_D3D12_OPTIONS22) && defined(D3D12_FEATURE_DATA_D3D12_OPTIONS22)
    D3D12_FEATURE_DATA_D3D12_OPTIONS22 opts22{};
    if (SUCCEEDED(s.device->CheckFeatureSupport(D3D12_FEATURE_D3D12_OPTIONS22, &opts22, sizeof(opts22)))) {
        g_features.shader_execution_reordering = opts22.ShaderExecutionReorderingActuallyReorders;
        g_features.create_byte_offset_views = opts22.CreateByteOffsetViewsSupported;
        g_features.max_1d_dispatch = opts22.Max1DDispatchSize;
        g_features.max_1d_dispatch_mesh = opts22.Max1DDispatchMeshSize;
    }
#endif
    
    // Architecture
    D3D12_FEATURE_DATA_ARCHITECTURE arch{};
    if (SUCCEEDED(s.device->CheckFeatureSupport(D3D12_FEATURE_ARCHITECTURE, &arch, sizeof(arch)))) {
        g_features.uma = arch.UMA;
    }
    
    D3D12_FEATURE_DATA_SHADER_MODEL sm{};
    sm.HighestShaderModel = D3D_SHADER_MODEL_6_8;
    if (SUCCEEDED(s.device->CheckFeatureSupport(D3D12_FEATURE_SHADER_MODEL, &sm, sizeof(sm)))) {
        g_features.shader_model = static_cast<uint32_t>(sm.HighestShaderModel & 0xF);
    }
    
    D3D12_FEATURE_DATA_D3D12_OPTIONS opts{};
    if (SUCCEEDED(s.device->CheckFeatureSupport(D3D12_FEATURE_D3D12_OPTIONS, &opts, sizeof(opts)))) {
        g_features.resource_binding_tier = static_cast<int>(opts.ResourceBindingTier);
    }
    
    // Update adapter info with new features
    s.adapter.gpu_upload_heap_supported = g_features.gpu_upload_heap;
    
    // Log features
    if (const char* trace = std::getenv("ZEN_D3D12_TRACE"); trace && trace[0] == '1') {
        std::printf("[d3d12] EnhancedBarriers=%d GPUUploadHeap=%d "
                    "ShaderReordering=%d ExecuteIndirectTier=%d ComputeOnlyHeap=%d\n",
                    g_features.enhanced_barriers, g_features.gpu_upload_heap,
                    g_features.shader_execution_reordering,
                    g_features.execute_indirect_tier, g_features.compute_only_custom_heap);
    }
}

// ============================================================================
// Enhanced Barriers Emulation using Legacy D3D12_RESOURCE_BARRIER
// True Enhanced Barriers API (D3D12_BARRIER, D3D12_BUFFER_BARRIER, ID3D12Device10::Barrier)
// requires Agility SDK 1.8+ and Windows 11, which is not available in SDK 1.722.
// This implementation uses legacy D3D12_RESOURCE_BARRIER with BEGIN_ONLY/END_ONLY flags
// to emulate split barriers for overlapping transitions.
// ============================================================================

// Split barrier: begin transition early, end late (legacy D3D12_RESOURCE_BARRIER with BEGIN_ONLY/END_ONLY flags)
void enhanced_barrier_begin(State& s, ID3D12Resource* resource,
                            D3D12_RESOURCE_STATES before, D3D12_RESOURCE_STATES after,
                            D3D12_RESOURCE_BARRIER* out_barrier) {
    out_barrier->Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
    out_barrier->Flags = D3D12_RESOURCE_BARRIER_FLAG_BEGIN_ONLY;
    out_barrier->Transition.pResource = resource;
    out_barrier->Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
    out_barrier->Transition.StateBefore = before;
    out_barrier->Transition.StateAfter = after;
}

void enhanced_barrier_end(State& s, D3D12_RESOURCE_BARRIER* barrier) {
    if (!barrier->Transition.pResource) return;
    
    barrier->Flags = D3D12_RESOURCE_BARRIER_FLAG_END_ONLY;
    s.list->ResourceBarrier(1, barrier);
    
    barrier->Transition.pResource = nullptr;  // Mark as consumed
}

// Legacy wrapper for transition() function
void transition(State& s, ID3D12Resource* resource, D3D12_RESOURCE_STATES before,
                D3D12_RESOURCE_STATES after) {
    D3D12_RESOURCE_BARRIER barrier{};
    barrier.Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
    barrier.Flags = D3D12_RESOURCE_BARRIER_FLAG_NONE;
    barrier.Transition.pResource = resource;
    barrier.Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
    barrier.Transition.StateBefore = before;
    barrier.Transition.StateAfter = after;
    s.list->ResourceBarrier(1, &barrier);
}

// Forward declaration
bool wait_gpu(State& s);
// Forward declaration
bool wait_gpu(State& s);

// ============================================================================
// Work Graph Implementation
// ============================================================================

bool build_work_graph(State& s) {
    if (g_features.work_graphs_tier < 10) {
        return false;
    }
    return false;
}

State& state() {
    static State s;
    return s;
}

// The GEMM shader re-reads the activation tile from global memory once per output
// row instead of staging it through groupshared. Parity tests pass at <=1.9e-07
// relative error across all shapes. Enabled by default for prefill.
bool gemm_opted_in() {
    static const bool value = [] {
        const char* flag = std::getenv("ZEN_D3D12_GEMM_EXPERIMENTAL");
        // Default to enabled; allow opt-out with ZEN_D3D12_GEMM_EXPERIMENTAL=0
        if (flag) return flag[0] != '0';
        return true;
    }();
    return value;
}

bool opted_in() {
    static const bool value = [] {
        const char* backend = std::getenv("ZEN_BACKEND");
        if (backend) {
            std::string name(backend);
            for (char& c : name) {
                c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
            }
            if (name == "d3d12" || name == "dx12" || name == "gpu") {
                return true;
            }
        }
        const char* flag = std::getenv("ZEN_D3D12");
        return flag && flag[0] == '1';
    }();
    return value;
}

// When the adapter reports CPU-visible VRAM (i.e. Resizable BAR is live), small
// buffers that the CPU rewrites every dispatch can live in VRAM instead of system
// memory, so the GPU reads them locally instead of crossing PCIe.
//
// A GPU upload heap resource must be created in COMMON and is permanently readable,
// so it never takes a transition barrier; it is still CPU-mappable, so Map() and the
// existing write paths are unchanged. The only new requirement is that a CPU write
// must not race the GPU still reading the previous contents, which holds here because
// every submit path fences with wait_gpu() before the next CPU write.
bool g_gpu_upload_heap = false;

D3D12_HEAP_TYPE upload_heap_type() {
    return g_gpu_upload_heap ? D3D12_HEAP_TYPE_GPU_UPLOAD : D3D12_HEAP_TYPE_UPLOAD;
}

D3D12_RESOURCE_STATES upload_heap_state() {
    return g_gpu_upload_heap ? D3D12_RESOURCE_STATE_COMMON : D3D12_RESOURCE_STATE_GENERIC_READ;
}

ComPtr<ID3D12Resource> create_buffer(ID3D12Device* device, std::uint64_t bytes,
                                     D3D12_HEAP_TYPE heap, D3D12_RESOURCE_STATES state,
                                     D3D12_RESOURCE_FLAGS flags = D3D12_RESOURCE_FLAG_NONE) {
    D3D12_HEAP_PROPERTIES props{};
    props.Type = heap;
    props.CPUPageProperty = D3D12_CPU_PAGE_PROPERTY_UNKNOWN;
    props.MemoryPoolPreference = D3D12_MEMORY_POOL_UNKNOWN;
    props.CreationNodeMask = 1;
    props.VisibleNodeMask = 1;

    D3D12_RESOURCE_DESC desc{};
    desc.Dimension = D3D12_RESOURCE_DIMENSION_BUFFER;
    desc.Width = bytes ? bytes : 4;
    desc.Height = 1;
    desc.DepthOrArraySize = 1;
    desc.MipLevels = 1;
    desc.Format = DXGI_FORMAT_UNKNOWN;
    desc.SampleDesc.Count = 1;
    desc.Layout = D3D12_TEXTURE_LAYOUT_ROW_MAJOR;
    desc.Flags = flags;

    ComPtr<ID3D12Resource> res;
    if (FAILED(device->CreateCommittedResource(&props, D3D12_HEAP_FLAG_NONE, &desc, state, nullptr,
                                               IID_PPV_ARGS(&res)))) {
        return nullptr;
    }
    return res;
}

// Adds device time to a component. The op count and fence wait are attributed
// centrally by execute_and_wait(), so this only fills in the GPU-time column.
void note_dev(State& s, Comp c, std::uint64_t dev_us) {
    if (!s.trace) {
        return;
    }
    s.comp_stats[static_cast<int>(c)].dev_us += dev_us;
}

// Prints the per-component decomposition. dev_us comes from GPU timestamp queries,
// wait_us from the fence; the difference is time the queue spent idle waiting for the
// GPU, which is where fixed per-submission latency shows up.
void print_trace_report() {
    State& s = state();
    if (!s.trace) {
        std::cout << "[trace] per-op tracing disabled (set ZEN_D3D12_TRACE=1)" << std::endl;
        return;
    }
    std::cout << "\n     component        ops  submits     dev us    wait us    idle us"
              << std::endl;
    std::uint64_t tot_dev = 0, tot_wait = 0, tot_ops = 0;
    auto row = [](const char* name, const State::CompStat& e) {
        const std::uint64_t idle = e.wait_us > e.dev_us ? e.wait_us - e.dev_us : 0;
        std::printf("     %-15s %5llu %8llu %10llu %10llu %10llu\n", name,
                    static_cast<unsigned long long>(e.ops),
                    static_cast<unsigned long long>(e.ops),
                    static_cast<unsigned long long>(e.dev_us),
                    static_cast<unsigned long long>(e.wait_us),
                    static_cast<unsigned long long>(idle));
    };
    for (int i = 0; i < static_cast<int>(Comp::Count); ++i) {
        const auto& e = s.comp_stats[i];
        if (!e.ops) {
            continue;
        }
        const char* name = i == static_cast<int>(Comp::Projections) ? "projections"
                           : i == static_cast<int>(Comp::FfnUpDown) ? "ffn"
                           : i == static_cast<int>(Comp::FfnFused)   ? "ffn-fused"
                           : i == static_cast<int>(Comp::Norms)      ? "norms"
                                                                     : "residual";
        row(name, e);
        tot_ops += e.ops;
        tot_dev += e.dev_us;
        tot_wait += e.wait_us;
    }
    const std::uint64_t tot_idle = tot_wait > tot_dev ? tot_wait - tot_dev : 0;
    std::printf("     %-15s %5llu %8llu %10llu %10llu %10llu\n", "TOTAL",
                static_cast<unsigned long long>(tot_ops),
                static_cast<unsigned long long>(tot_ops),
                static_cast<unsigned long long>(tot_dev),
                static_cast<unsigned long long>(tot_wait),
                static_cast<unsigned long long>(tot_idle));
    if (tot_wait) {
        std::printf("     idle share of fence time: %.1f%%\n",
                    100.0 * static_cast<double>(tot_idle) / static_cast<double>(tot_wait));
    }
    std::cout.flush();
}

bool wait_gpu(State& s);

bool wait_gpu(State& s) {
    const std::uint64_t value = ++s.fence_value;
    if (FAILED(s.queue->Signal(s.fence.Get(), value))) {
        return false;
    }
    if (s.fence->GetCompletedValue() < value) {
        // A decode-sized dispatch retires in tens of microseconds, while the
        // SetEventOnCompletion/WaitForSingleObject round trip alone costs more
        // than that. Spin for a bounded window, then block for anything longer.
        LARGE_INTEGER frequency{}, started{}, now{};
        QueryPerformanceFrequency(&frequency);
        QueryPerformanceCounter(&started);
        for (;;) {
            if (s.fence->GetCompletedValue() >= value) {
                return true;
            }
            _mm_pause();
            QueryPerformanceCounter(&now);
            const double elapsed_us = static_cast<double>(now.QuadPart - started.QuadPart) *
                                      1000000.0 / static_cast<double>(frequency.QuadPart);
            if (elapsed_us > kSpinWaitUs) {
                break;
            }
        }
        if (s.fence->GetCompletedValue() < value) {
            if (FAILED(s.fence->SetEventOnCompletion(value, s.fence_event))) {
                return false;
            }
            WaitForSingleObject(s.fence_event, INFINITE);
        }
    }
    return true;
}

// Submits the closed command list and blocks to completion, recording the CPU-side
// queue cost separately from the fence wait. The split decides the fix: a large
// queue_us means the driver is slow to accept many small command lists (fewer, bigger
// lists), a large wait_us means the GPU is slow to retire them (fewer submissions).
bool execute_and_wait(State& s) {
    const auto queue_start = std::chrono::steady_clock::now();
    ID3D12CommandList* lists[] = {s.list.Get()};
    ++s.stats.submits;
    s.queue->ExecuteCommandLists(1, lists);
    s.stats.queue_us += static_cast<std::uint64_t>(
        std::chrono::duration_cast<std::chrono::microseconds>(
            std::chrono::steady_clock::now() - queue_start)
            .count());

    const auto fence_start = std::chrono::steady_clock::now();
    if (!wait_gpu(s)) {
        return false;
    }
    const std::uint64_t waited = static_cast<std::uint64_t>(
        std::chrono::duration_cast<std::chrono::microseconds>(
            std::chrono::steady_clock::now() - fence_start)
            .count());
    s.stats.wait_us += waited;
    if (s.trace) {
        auto& e = s.comp_stats[static_cast<int>(s.current_comp)];
        ++e.ops;
        e.wait_us += waited;
    }
    return true;
}

// Adds the GPU time between stamps[lo] and stamps[hi] as resolved by the retired
// command list. No-op without the trace flag, and never trusts a non-increasing pair.
void accumulate_gpu_us(State& s, std::uint64_t& out, unsigned lo, unsigned hi) {
    if (!s.trace) {
        return;
    }
    std::uint64_t* stamps = nullptr;
    const D3D12_RANGE range{0, 3 * sizeof(std::uint64_t)};
    if (FAILED(s.ts_read->Map(0, &range, reinterpret_cast<void**>(&stamps)))) {
        return;
    }
    if (stamps[hi] > stamps[lo]) {
        out += static_cast<std::uint64_t>(
            static_cast<double>(stamps[hi] - stamps[lo]) * 1000000.0 /
            static_cast<double>(s.ts_freq));
    }
    const D3D12_RANGE none{0, 0};
    s.ts_read->Unmap(0, &none);
}

bool build_root_signature(State& s) {
    D3D12_ROOT_PARAMETER params[5]{};
    params[0].ParameterType = D3D12_ROOT_PARAMETER_TYPE_CBV;
    params[0].Descriptor.ShaderRegister = 0;
    params[0].Descriptor.RegisterSpace = 0;
    params[0].ShaderVisibility = D3D12_SHADER_VISIBILITY_ALL;
    for (std::uint32_t i = 0; i < 3; ++i) {
        params[1 + i].ParameterType = D3D12_ROOT_PARAMETER_TYPE_SRV;
        params[1 + i].Descriptor.ShaderRegister = i;
        params[1 + i].Descriptor.RegisterSpace = 0;
        params[1 + i].ShaderVisibility = D3D12_SHADER_VISIBILITY_ALL;
    }
    params[4].ParameterType = D3D12_ROOT_PARAMETER_TYPE_UAV;
    params[4].Descriptor.ShaderRegister = 0;
    params[4].Descriptor.RegisterSpace = 0;
    params[4].ShaderVisibility = D3D12_SHADER_VISIBILITY_ALL;

    D3D12_ROOT_SIGNATURE_DESC desc{};
    desc.NumParameters = 5;
    desc.pParameters = params;
    desc.NumStaticSamplers = 0;
    desc.pStaticSamplers = nullptr;
    desc.Flags = D3D12_ROOT_SIGNATURE_FLAG_NONE;

    ComPtr<ID3DBlob> blob;
    ComPtr<ID3DBlob> error;
    if (FAILED(D3D12SerializeRootSignature(&desc, D3D_ROOT_SIGNATURE_VERSION_1,
                                           blob.GetAddressOf(), error.GetAddressOf()))) {
        return false;
    }
    return SUCCEEDED(s.device->CreateRootSignature(0, blob->GetBufferPointer(),
                                                   blob->GetBufferSize(),
                                                   IID_PPV_ARGS(&s.root)));
}

ComPtr<ID3D12PipelineState> build_pso(State& s, const void* code, std::size_t size) {
    D3D12_COMPUTE_PIPELINE_STATE_DESC desc{};
    desc.pRootSignature = s.root.Get();
    desc.CS.pShaderBytecode = code;
    desc.CS.BytecodeLength = size;
    desc.NodeMask = 0;
    desc.Flags = D3D12_PIPELINE_STATE_FLAG_NONE;
    
    // Enable Shader Execution Reordering (SER) when supported (OPTIONS22)
    if (g_features.shader_execution_reordering) {
        // Check if the device supports the flag
        #if defined(D3D12_PIPELINE_STATE_FLAG_ALLOW_SHADER_EXECUTION_REORDERING)
        desc.Flags |= D3D12_PIPELINE_STATE_FLAG_ALLOW_SHADER_EXECUTION_REORDERING;
        #endif
    }
    
    ComPtr<ID3D12PipelineState> pso;
    if (FAILED(s.device->CreateComputePipelineState(&desc, IID_PPV_ARGS(&pso)))) {
        // Retry without SER flag if it fails
        desc.Flags = D3D12_PIPELINE_STATE_FLAG_NONE;
        if (FAILED(s.device->CreateComputePipelineState(&desc, IID_PPV_ARGS(&pso)))) {
            return nullptr;
        }
    }
    return pso;
}

bool reserve_scratch(State& s, std::size_t x_bytes, std::size_t y_bytes);

bool init_locked(State& s) {
    if (s.ready) {
        return true;
    }
    if (s.failed) {
        return false;
    }

    auto fail = [&s] {
        s.failed = true;
        return false;
    };

    // Require a genuine 12.1 device: the shaders are SM 6.0 but the feature level
    // is what the caller asked for, and refusing early keeps the failure obvious.
    if (FAILED(D3D12CreateDevice(nullptr, D3D_FEATURE_LEVEL_12_1, IID_PPV_ARGS(&s.device)))) {
        return fail();
    }

    D3D_FEATURE_LEVEL requested[] = {D3D_FEATURE_LEVEL_12_2, D3D_FEATURE_LEVEL_12_1};
    D3D12_FEATURE_DATA_FEATURE_LEVELS levels{};
    levels.pFeatureLevelsRequested = requested;
    levels.NumFeatureLevels = 2;
    if (SUCCEEDED(s.device->CheckFeatureSupport(D3D12_FEATURE_FEATURE_LEVELS, &levels,
                                                sizeof(levels)))) {
        s.adapter.feature_level =
            (levels.MaxSupportedFeatureLevel == D3D_FEATURE_LEVEL_12_2) ? 122 : 121;
    }

    // Agility SDK activation and ReBAR evidence.
    s.adapter.agility_sdk_version = agility_version();
    // Query ALL D3D12 options (12-22) for modern features
    query_d3d12_features(s);
    
    // GPU upload heaps are the only D3D12 feature that consumes Resizable BAR, and
    // on a discrete GPU the runtime only reports them when the whole VRAM is
    // CPU-visible. So this single flag is the only in-process answer to "is ReBAR
    // actually live here"; there is no dedicated ReBAR query.
    // Enable by default when ReBAR is live (GPU upload heap supported on discrete GPU)
    // since it eliminates PCIe crossings for per-token activation/param buffers.
    if (s.adapter.gpu_upload_heap_supported && !g_features.uma) {
        g_gpu_upload_heap = true;
    }
    // Allow explicit override
    if (const char* e = std::getenv("ZEN_D3D12_GPU_UPLOAD"); e) {
        g_gpu_upload_heap = (e[0] == '1') && s.adapter.gpu_upload_heap_supported;
    }

    if (ComPtr<IDXGIFactory4> factory;
        SUCCEEDED(CreateDXGIFactory1(IID_PPV_ARGS(&factory)))) {
        ComPtr<IDXGIAdapter1> adapter;
        const LUID luid = s.device->GetAdapterLuid();
        if (SUCCEEDED(factory->EnumAdapterByLuid(luid, IID_PPV_ARGS(&adapter)))) {
            DXGI_ADAPTER_DESC desc{};
            if (SUCCEEDED(adapter->GetDesc(&desc))) {
                WideCharToMultiByte(CP_UTF8, 0, desc.Description, -1, s.adapter.name,
                                    static_cast<int>(sizeof(s.adapter.name)), nullptr, nullptr);
                s.adapter.dedicated_vram = desc.DedicatedVideoMemory;
                s.adapter.shared_memory = desc.SharedSystemMemory;
            }
        }
    }

    D3D12_COMMAND_QUEUE_DESC queue_desc{};
    queue_desc.Type = D3D12_COMMAND_LIST_TYPE_COMPUTE;
    queue_desc.Flags = D3D12_COMMAND_QUEUE_FLAG_NONE;
    if (FAILED(s.device->CreateCommandQueue(&queue_desc, IID_PPV_ARGS(&s.queue)))) {
        return fail();
    }
    if (FAILED(s.device->CreateCommandAllocator(D3D12_COMMAND_LIST_TYPE_COMPUTE,
                                                IID_PPV_ARGS(&s.allocator)))) {
        return fail();
    }
    if (FAILED(s.device->CreateCommandList(0, D3D12_COMMAND_LIST_TYPE_COMPUTE, s.allocator.Get(),
                                           nullptr, IID_PPV_ARGS(&s.list)))) {
        return fail();
    }
    s.list->Close();
    if (FAILED(s.device->CreateFence(0, D3D12_FENCE_FLAG_NONE, IID_PPV_ARGS(&s.fence)))) {
        return fail();
    }
    s.fence_event = CreateEventExW(nullptr, nullptr, 0, EVENT_ALL_ACCESS);
    if (!s.fence_event) {
        return fail();
    }

    // Create async copy queue for KV cache operations
    D3D12_COMMAND_QUEUE_DESC copy_queue_desc{};
    copy_queue_desc.Type = D3D12_COMMAND_LIST_TYPE_COPY;
    copy_queue_desc.Flags = D3D12_COMMAND_QUEUE_FLAG_NONE;
    if (FAILED(s.device->CreateCommandQueue(&copy_queue_desc, IID_PPV_ARGS(&s.copy_queue)))) {
        return fail();
    }
    if (FAILED(s.device->CreateCommandAllocator(D3D12_COMMAND_LIST_TYPE_COPY,
                                                IID_PPV_ARGS(&s.copy_allocator)))) {
        return fail();
    }
    if (FAILED(s.device->CreateCommandList(0, D3D12_COMMAND_LIST_TYPE_COPY, s.copy_allocator.Get(),
                                           nullptr, IID_PPV_ARGS(&s.copy_list)))) {
        return fail();
    }
    s.copy_list->Close();
    if (FAILED(s.device->CreateFence(0, D3D12_FENCE_FLAG_NONE, IID_PPV_ARGS(&s.copy_fence)))) {
        return fail();
    }
    s.copy_fence_event = CreateEventExW(nullptr, nullptr, 0, EVENT_ALL_ACCESS);
    if (!s.copy_fence_event) {
        return fail();
    }

    if (!build_root_signature(s)) {
        return fail();
    }
    s.pso_gemv = build_pso(s, zen_dx12_shaders::kQ8_0GemvCso, zen_dx12_shaders::kQ8_0GemvCsoSize);
    s.pso_rope = build_pso(s, zen_dx12_shaders::kRopeCso, zen_dx12_shaders::kRopeCsoSize);
    s.pso_attn = build_pso(s, zen_dx12_shaders::kAttnCso, zen_dx12_shaders::kAttnCsoSize);
    s.pso_rms = build_pso(s, zen_dx12_shaders::kRmsNormCso, zen_dx12_shaders::kRmsNormCsoSize);
    s.pso_silu = build_pso(s, zen_dx12_shaders::kSiluMulCso, zen_dx12_shaders::kSiluMulCsoSize);
    s.pso_gemm = build_pso(s, zen_dx12_shaders::kQ8_0GemmCso, zen_dx12_shaders::kQ8_0GemmCsoSize);
    s.pso_addn = build_pso(s, zen_dx12_shaders::kAddnCso, zen_dx12_shaders::kAddnCsoSize);
    s.pso_flash_attn = build_pso(s, zen_dx12_shaders::kFlashAttnCso, zen_dx12_shaders::kFlashAttnCsoSize);
    if (!s.pso_gemv || !s.pso_gemm || !s.pso_silu || !s.pso_rms || !s.pso_addn ||
        !s.pso_rope || !s.pso_attn || !s.pso_flash_attn) {
        return fail();
    }

    // Two slots past the batch range are reserved for the fused FFN path's two
    // residual adds, which must not alias a batch slot that a matvec group uses.
    // 8192 bytes: the legacy slots below 3072 are unchanged, and the whole-layer path
    // (task 7) needs seven gemv slots, two norms, two residual adds and a SiLU beyond
    // them. Slot 1024/1280/1536 are the rope and attention parameters.
    s.params = create_buffer(s.device.Get(), 8192, upload_heap_type(),
                             upload_heap_state());
    if (!s.params) {
        return fail();
    }
    if (FAILED(s.params->Map(0, nullptr, &s.params_cpu))) {
        return fail();
    }

    if (s.trace) {
        D3D12_QUERY_HEAP_DESC query_desc{};
        query_desc.Type = D3D12_QUERY_HEAP_TYPE_TIMESTAMP;
        // Pipeline needs 16 layers * 2 queries = 32. Prefill needs 4. Use max.
        query_desc.Count = 64;
        query_desc.NodeMask = 0;
        if (FAILED(s.device->CreateQueryHeap(&query_desc, IID_PPV_ARGS(&s.ts_heap)))) {
            return fail();
        }
        s.ts_read = create_buffer(s.device.Get(), 64 * sizeof(std::uint64_t),
                                  D3D12_HEAP_TYPE_READBACK, D3D12_RESOURCE_STATE_COPY_DEST);
        if (!s.ts_read) {
            return fail();
        }
        UINT64 frequency = 0;
        if (FAILED(s.queue->GetTimestampFrequency(&frequency)) || !frequency) {
            return fail();
        }
        s.ts_freq = frequency;
    }

    // Diagnostic floor probe: what does an empty submit + fence round trip cost?
    // Whatever remains above the real work in gemv is this, not arithmetic.
    if (const char* probe = std::getenv("ZEN_D3D12_BENCH_SUBMIT"); probe && probe[0] == '1') {
        double total = 0.0;
        constexpr int kRounds = 200;
        for (int i = 0; i < kRounds; ++i) {
            s.allocator->Reset();
            s.list->Reset(s.allocator.Get(), nullptr);
            s.list->Close();
            const auto start = std::chrono::steady_clock::now();
            ID3D12CommandList* lists[] = {s.list.Get()};
            s.queue->ExecuteCommandLists(1, lists);
            wait_gpu(s);
            total += std::chrono::duration<double, std::micro>(
                         std::chrono::steady_clock::now() - start)
                         .count();
        }
        std::cerr << "[d3d12] empty submit round trip: " << (total / kRounds) << " us" << std::endl;

        // How does the round trip scale with the number of dispatches in one
        // submission? A flat fixed cost means batching calls is the only lever.
        if (!reserve_scratch(s, 64 * 1024, 8 * 1024)) {
            return fail();
        }
        auto* probe_params = static_cast<GemvParams*>(s.params_cpu);
        probe_params->rows = 64;
        probe_params->blocks_per_row = 1;
        probe_params->rows_per_group = kRowsPerGroup;
        probe_params->reserved = 0;
        for (UINT count : {1u, 2u, 4u, 8u, 16u}) {
            double batch_total = 0.0;
            for (int i = 0; i < 50; ++i) {
                s.allocator->Reset();
                s.list->Reset(s.allocator.Get(), s.pso_gemv.Get());
                s.list->SetComputeRootSignature(s.root.Get());
                s.list->SetComputeRootConstantBufferView(0, s.params->GetGPUVirtualAddress());
                s.list->SetComputeRootShaderResourceView(1, s.xbuf->GetGPUVirtualAddress());
                s.list->SetComputeRootShaderResourceView(2, s.xbuf->GetGPUVirtualAddress());
                s.list->SetComputeRootShaderResourceView(3, s.xbuf->GetGPUVirtualAddress());
                s.list->SetComputeRootUnorderedAccessView(4, s.ybuf->GetGPUVirtualAddress());
                for (UINT d = 0; d < count; ++d) {
                    s.list->Dispatch(16, 1, 1);
                }
                s.list->Close();
                const auto start = std::chrono::steady_clock::now();
                ID3D12CommandList* lists[] = {s.list.Get()};
                s.queue->ExecuteCommandLists(1, lists);
                wait_gpu(s);
                batch_total += std::chrono::duration<double, std::micro>(
                                   std::chrono::steady_clock::now() - start)
                                   .count();
            }
            std::cerr << "[d3d12] submit round trip with " << count << " dispatches: "
                      << (batch_total / 50.0) << " us" << std::endl;
        }
    }

    // ZEN_D3D12_BENCH_GPUTS: are the GPU timestamps trustworthy? Production brackets
    // only the Dispatch, and on prefill it reports ~5us per call while the CPU blocks
    // 11.35ms on the same fence - four orders of magnitude apart (F-19). Dispatch N
    // times inside one list, timestamp them exactly as production does, and compare the
    // reported GPU time against the fence round trip. If the stamp does not scale with N
    // it is unusable, and so is every conclusion drawn from gpu_us.
    if (const char* gputs = std::getenv("ZEN_D3D12_BENCH_GPUTS"); gputs && gputs[0] == '1') {
        if (s.ts_heap && s.ts_read && reserve_scratch(s, 64 * 1024, 8 * 1024)) {
            auto* probe_params = static_cast<GemvParams*>(s.params_cpu);
            probe_params->rows = 64;
            probe_params->blocks_per_row = 1;
            probe_params->rows_per_group = kRowsPerGroup;
            probe_params->reserved = 0;
            for (UINT count : {1u, 32u, 256u, 1024u}) {
                double fence_total = 0.0;
                double stamp_total = 0.0;
                int stamp_samples = 0;
                constexpr int kRounds = 16;
                for (int r = 0; r < kRounds; ++r) {
                    s.allocator->Reset();
                    s.list->Reset(s.allocator.Get(), s.pso_gemv.Get());
                    s.list->SetComputeRootSignature(s.root.Get());
                    s.list->SetComputeRootConstantBufferView(0, s.params->GetGPUVirtualAddress());
                    s.list->SetComputeRootShaderResourceView(1, s.xbuf->GetGPUVirtualAddress());
                    s.list->SetComputeRootShaderResourceView(2, s.xbuf->GetGPUVirtualAddress());
                    s.list->SetComputeRootShaderResourceView(3, s.xbuf->GetGPUVirtualAddress());
                    s.list->SetComputeRootUnorderedAccessView(4, s.ybuf->GetGPUVirtualAddress());
                    s.list->EndQuery(s.ts_heap.Get(), D3D12_QUERY_TYPE_TIMESTAMP, 0);
                    for (UINT d = 0; d < count; ++d) {
                        s.list->Dispatch(16, 1, 1);
                    }
                    s.list->EndQuery(s.ts_heap.Get(), D3D12_QUERY_TYPE_TIMESTAMP, 1);
                    s.list->ResolveQueryData(s.ts_heap.Get(), D3D12_QUERY_TYPE_TIMESTAMP, 0, 2,
                                             s.ts_read.Get(), 0);
                    s.list->Close();

                    const auto start = std::chrono::steady_clock::now();
                    ID3D12CommandList* lists[] = {s.list.Get()};
                    s.queue->ExecuteCommandLists(1, lists);
                    wait_gpu(s);
                    fence_total += std::chrono::duration<double, std::micro>(
                                       std::chrono::steady_clock::now() - start)
                                       .count();

                    void* mapped = nullptr;
                    const D3D12_RANGE range{0, 2 * sizeof(std::uint64_t)};
                    if (SUCCEEDED(s.ts_read->Map(0, &range, &mapped))) {
                        const auto* stamps = static_cast<const std::uint64_t*>(mapped);
                        if (stamps[1] > stamps[0]) {
                            stamp_total += static_cast<double>(stamps[1] - stamps[0]) *
                                           1000000.0 / static_cast<double>(s.ts_freq);
                            ++stamp_samples;
                        }
                        const D3D12_RANGE none{0, 0};
                        s.ts_read->Unmap(0, &none);
                    }
                }
                std::cerr << "[d3d12] " << count << " dispatches: gpu_stamp="
                          << (stamp_samples ? stamp_total / stamp_samples : -1.0)
                          << " us, fence=" << (fence_total / kRounds) << " us, samples="
                          << stamp_samples << "/" << kRounds << std::endl;
            }
        }
    }

    // Does an idle gap between submissions make the next one expensive? The real path
    // pays 265us of fence wait per list while an isolated one costs 82us; the CPU does
    // attention between submissions, so the GPU gets to fall asleep in between. If
    // retire latency tracks the gap, this is clock/power wake latency, and no amount
    // of command-list batching removes it - only keeping the GPU busy does.
    if (const char* idle = std::getenv("ZEN_D3D12_BENCH_IDLE"); idle && idle[0] == '1') {
        if (reserve_scratch(s, 64 * 1024, 8 * 1024)) {
            auto* probe_params = static_cast<GemvParams*>(s.params_cpu);
            probe_params->rows = 64;
            probe_params->blocks_per_row = 1;
            probe_params->rows_per_group = kRowsPerGroup;
            probe_params->reserved = 0;
            LARGE_INTEGER perf_freq{};
            QueryPerformanceFrequency(&perf_freq);
            auto spin_us = [&](double us) {
                LARGE_INTEGER t0{}, t1{};
                QueryPerformanceCounter(&t0);
                for (;;) {
                    QueryPerformanceCounter(&t1);
                    const double elapsed = static_cast<double>(t1.QuadPart - t0.QuadPart) *
                                           1000000.0 / static_cast<double>(perf_freq.QuadPart);
                    if (elapsed >= us) {
                        break;
                    }
                    _mm_pause();
                }
            };
            for (double gap : {0.0, 25.0, 50.0, 100.0, 250.0, 500.0, 1000.0}) {
                double total = 0.0;
                constexpr int kRounds = 60;
                for (int i = 0; i < kRounds; ++i) {
                    s.allocator->Reset();
                    s.list->Reset(s.allocator.Get(), s.pso_gemv.Get());
                    s.list->SetComputeRootSignature(s.root.Get());
                    s.list->SetComputeRootConstantBufferView(0, s.params->GetGPUVirtualAddress());
                    s.list->SetComputeRootShaderResourceView(1, s.xbuf->GetGPUVirtualAddress());
                    s.list->SetComputeRootShaderResourceView(2, s.xbuf->GetGPUVirtualAddress());
                    s.list->SetComputeRootShaderResourceView(3, s.xbuf->GetGPUVirtualAddress());
                    s.list->SetComputeRootUnorderedAccessView(4, s.ybuf->GetGPUVirtualAddress());
                    for (UINT d = 0; d < 4; ++d) {
                        s.list->Dispatch(16, 1, 1);
                    }
                    s.list->Close();
                    if (gap > 0.0) {
                        spin_us(gap);  // let the GPU fall idle between submissions
                    }
                    const auto start = std::chrono::steady_clock::now();
                    ID3D12CommandList* lists[] = {s.list.Get()};
                    s.queue->ExecuteCommandLists(1, lists);
                    wait_gpu(s);
                    total += std::chrono::duration<double, std::micro>(
                                 std::chrono::steady_clock::now() - start)
                                 .count();
                }
                std::cerr << "[d3d12] retire latency after " << gap << " us idle gap: "
                          << (total / kRounds) << " us" << std::endl;
            }
        }
    }

    // Is the per-submission cost a drain/empty-queue effect? Submit many lists
    // back-to-back without waiting, then wait once at the end.
    if (const char* pipe = std::getenv("ZEN_D3D12_BENCH_PIPE"); pipe && pipe[0] == '1') {
        if (reserve_scratch(s, 64 * 1024, 8 * 1024)) {
            auto* probe_params = static_cast<GemvParams*>(s.params_cpu);
            probe_params->rows = 64;
            probe_params->blocks_per_row = 1;
            probe_params->rows_per_group = kRowsPerGroup;
            probe_params->reserved = 0;
            constexpr int kLists = 64;
            s.allocator->Reset();
            const auto start = std::chrono::steady_clock::now();
            for (int i = 0; i < kLists; ++i) {
                s.list->Reset(s.allocator.Get(), s.pso_gemv.Get());
                s.list->SetComputeRootSignature(s.root.Get());
                s.list->SetComputeRootConstantBufferView(0, s.params->GetGPUVirtualAddress());
                s.list->SetComputeRootShaderResourceView(1, s.xbuf->GetGPUVirtualAddress());
                s.list->SetComputeRootShaderResourceView(2, s.xbuf->GetGPUVirtualAddress());
                s.list->SetComputeRootShaderResourceView(3, s.xbuf->GetGPUVirtualAddress());
                s.list->SetComputeRootUnorderedAccessView(4, s.ybuf->GetGPUVirtualAddress());
                s.list->Dispatch(16, 1, 1);
                s.list->Close();
                ID3D12CommandList* lists[] = {s.list.Get()};
                s.queue->ExecuteCommandLists(1, lists);
            }
            wait_gpu(s);
            const double per_list = std::chrono::duration<double, std::micro>(
                                        std::chrono::steady_clock::now() - start)
                                        .count() / kLists;
            std::cerr << "[d3d12] pipelined submit, no wait between: " << per_list << " us/list"
                      << std::endl;
        }
    }

    s.ready = true;
    return true;
}

bool reserve_scratch(State& s, std::size_t x_bytes, std::size_t y_bytes) {
    if (x_bytes > s.x_cap) {
        s.xbuf.Reset();
        s.xbuf = create_buffer(s.device.Get(), x_bytes, upload_heap_type(),
                               upload_heap_state());
        if (!s.xbuf || FAILED(s.xbuf->Map(0, nullptr, &s.x_cpu))) {
            s.x_cap = 0;
            return false;
        }
        s.x_cap = x_bytes;
    }
    if (y_bytes > s.y_cap) {
        s.ybuf.Reset();
        s.yread.Reset();
        s.ybuf = create_buffer(s.device.Get(), y_bytes, D3D12_HEAP_TYPE_DEFAULT,
                               D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
                               D3D12_RESOURCE_FLAG_ALLOW_UNORDERED_ACCESS);
        s.yread = create_buffer(s.device.Get(), y_bytes, D3D12_HEAP_TYPE_READBACK,
                                D3D12_RESOURCE_STATE_COPY_DEST);
        if (!s.ybuf || !s.yread) {
            s.y_cap = 0;
            return false;
        }
        s.y_cap = y_bytes;
    }
    return true;
}

// Upload a Q8_0 matrix, repacking every 34-byte block into an aligned quant stream
// plus a separate fp32 scale stream.
bool upload_weights(State& s, const std::uint8_t* weights, std::size_t rows,
                    std::size_t columns, WeightEntry& entry) {
    const auto upload_start = std::chrono::steady_clock::now();
    const std::size_t blocks_per_row = (columns + kElemsPerBlock - 1) / kElemsPerBlock;
    const std::size_t row_bytes = blocks_per_row * kRawBlockBytes;
    const std::uint64_t quant_bytes =
        static_cast<std::uint64_t>(rows) * blocks_per_row * kElemsPerBlock;
    const std::uint64_t scale_bytes = static_cast<std::uint64_t>(rows) * blocks_per_row * sizeof(float);

    if (s.adapter.dedicated_vram) {
        const std::uint64_t budget = s.adapter.dedicated_vram / 100 * kVRAMBudgetPercent;
        if (s.weight_bytes + quant_bytes + scale_bytes > budget) {
            s.weights.clear();
            s.weight_bytes = 0;
        }
        if (quant_bytes + scale_bytes > budget) {
            return false;
        }
    }

    // Layout of the single buffer this tensor needs: [quants | 256B pad | scales].
    const std::uint64_t scale_offset = (quant_bytes + 255u) & ~static_cast<std::uint64_t>(255u);
    const std::uint64_t needed = scale_offset + scale_bytes;

    entry.quants = create_buffer(s.device.Get(), needed, D3D12_HEAP_TYPE_DEFAULT,
                                 D3D12_RESOURCE_STATE_COPY_DEST);
    if (!entry.quants) {
        return false;
    }
    entry.scales_va = entry.quants->GetGPUVirtualAddress() + scale_offset;

    // One staging buffer, reused for every tensor and kept for the life of the
    // backend. Allocating fresh system pages per tensor cost more than the
    // transfers themselves: ~1.3 GB of first-touch faults across 112 uploads.
    if (needed > s.stage_cap) {
        const auto stage_start = std::chrono::steady_clock::now();
        s.stage.Reset();
        s.stage_cpu = nullptr;
        s.stage = create_buffer(s.device.Get(), needed, upload_heap_type(),
                                upload_heap_state());
        if (!s.stage || FAILED(s.stage->Map(0, nullptr, &s.stage_cpu))) {
            s.stage_cap = 0;
            return false;
        }
        s.stage_cap = needed;
        // Only the growth events count here: the first one includes the initial map.
        s.stats.stage_us += static_cast<std::uint64_t>(
            std::chrono::duration_cast<std::chrono::microseconds>(
                std::chrono::steady_clock::now() - stage_start)
                .count());
    }

    auto* q_dst = static_cast<std::uint8_t*>(s.stage_cpu);
    auto* s_dst =
        reinterpret_cast<float*>(static_cast<std::uint8_t*>(s.stage_cpu) + scale_offset);

    // Everything from entry to here is committed-resource creation and staging-buffer
    // growth. upload_ms spans all of it, so without this split that cost hides behind
    // the repack and transfer timers and looks like slow PCIe.
    s.stats.alloc_us += static_cast<std::uint64_t>(
        std::chrono::duration_cast<std::chrono::microseconds>(
            std::chrono::steady_clock::now() - upload_start)
            .count());

    const auto repack_start = std::chrono::steady_clock::now();
    detail::repack_q8_0(weights, rows, blocks_per_row, q_dst, s_dst);
    s.stats.repack_us += static_cast<std::uint64_t>(
        std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now() -
                                                              repack_start)
            .count());
    const auto transfer_start = std::chrono::steady_clock::now();
    (void)row_bytes;

    s.allocator->Reset();
    s.list->Reset(s.allocator.Get(), nullptr);

    // One copy: the staging buffer already carries [quants | pad | scales], so both
    // regions move in a single transfer. The resource is still in COPY_DEST here and
    // only afterwards may it take the shader-readable state the root SRVs require.
    s.list->CopyBufferRegion(entry.quants.Get(), 0, s.stage.Get(), 0, needed);

    D3D12_RESOURCE_BARRIER back{};
    back.Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
    back.Transition.pResource = entry.quants.Get();
    back.Transition.StateBefore = D3D12_RESOURCE_STATE_COPY_DEST;
    back.Transition.StateAfter = D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE;
    back.Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
    s.list->ResourceBarrier(1, &back);

    s.list->Close();
    ID3D12CommandList* lists[] = {s.list.Get()};
    ++s.stats.submits;
    s.queue->ExecuteCommandLists(1, lists);
    if (!wait_gpu(s)) {
        return false;
    }

    s.stats.transfer_us += static_cast<std::uint64_t>(
        std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now() -
                                                              transfer_start)
            .count());
    s.weight_bytes += needed;
    s.stats.upload_bytes += needed;
    s.stats.upload_us += static_cast<std::uint64_t>(
        std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now() -
                                                              upload_start)
            .count());
    s.stats.weight_bytes = s.weight_bytes;
    entry.rows = rows;
    entry.columns = columns;
    return true;
}

WeightEntry* lookup_weights(State& s, const std::uint8_t* weights, std::size_t rows,
                            std::size_t columns) {
    auto it = s.weights.find(weights);
    if (it != s.weights.end() && it->second.rows == rows && it->second.columns == columns) {
        return &it->second;
    }
    // A different shape at the same address means the loader reused the storage;
    // drop the stale residency before uploading the new layout.
    if (it != s.weights.end()) {
        // One buffer now holds both regions, so the removal must subtract its full
        // width - exactly what upload_weights adds below - or the residency accounting
        // drifts by the 256B pad on every stale-shape replacement.
        s.weight_bytes -= it->second.quants->GetDesc().Width;
        s.weights.erase(it);
    }
    WeightEntry entry;
    if (!upload_weights(s, weights, rows, columns, entry)) {
        return nullptr;
    }
    auto& slot = s.weights[weights];
    slot = std::move(entry);
    return &slot;
}

bool gemv_batch_locked(State& s, const float* x, const GemvTask* tasks, std::size_t count) {
    s.current_comp = Comp::Projections;
    if (count == 0 || count > kMaxBatch) {
        return false;
    }
    const std::size_t cols = tasks[0].columns;
    if (cols % kElemsPerBlock != 0) {
        return false;
    }
    std::size_t total_rows = 0;
    for (std::size_t i = 0; i < count; ++i) {
        if (tasks[i].columns != cols) {
            return false;
        }
        total_rows += tasks[i].rows;
    }

    // Refcounted copies, not WeightEntry*: a later lookup_weights() inside this same
    // batch can hit the VRAM budget and clear the residency cache, which would free an
    // entry we have not bound yet (F-09).
    ComPtr<ID3D12Resource> quants[kMaxBatch];
    std::uint64_t scales[kMaxBatch];
    for (std::size_t i = 0; i < count; ++i) {
        WeightEntry* entry = lookup_weights(s, tasks[i].weights, tasks[i].rows, tasks[i].columns);
        if (!entry) {
            return false;
        }
        quants[i] = entry->quants;
        scales[i] = entry->scales_va;
    }

    // Outputs are packed back-to-back in the shared UAV buffer at 256-byte offsets,
    // which is what a root UAV descriptor requires.
    std::uint64_t offsets[kMaxBatch];
    std::uint64_t span = 0;
    for (std::size_t i = 0; i < count; ++i) {
        offsets[i] = span;
        span = (span + tasks[i].rows * sizeof(float) + 255u) & ~static_cast<std::uint64_t>(255u);
    }

    if (!reserve_scratch(s, cols * sizeof(float), span)) {
        return false;
    }
    std::memcpy(s.x_cpu, x, cols * sizeof(float));

    auto* params_base = static_cast<std::uint8_t*>(s.params_cpu);
    for (std::size_t i = 0; i < count; ++i) {
        auto* params = reinterpret_cast<GemvParams*>(params_base + 512 + 256 * i);
        params->rows = static_cast<std::uint32_t>(tasks[i].rows);
        params->blocks_per_row = static_cast<std::uint32_t>(cols / kElemsPerBlock);
        params->rows_per_group = kRowsPerGroup;
        params->reserved = 0;
    }

    s.allocator->Reset();
    s.list->Reset(s.allocator.Get(), s.pso_gemv.Get());
    s.list->SetComputeRootSignature(s.root.Get());
    if (s.trace) {
        s.list->EndQuery(s.ts_heap.Get(), D3D12_QUERY_TYPE_TIMESTAMP, 0);
    }
    for (std::size_t i = 0; i < count; ++i) {
        s.list->SetComputeRootConstantBufferView(
            0, s.params->GetGPUVirtualAddress() + 512 + 256 * i);
        s.list->SetComputeRootShaderResourceView(1, quants[i]->GetGPUVirtualAddress());
        s.list->SetComputeRootShaderResourceView(2, scales[i]);
        s.list->SetComputeRootShaderResourceView(3, s.xbuf->GetGPUVirtualAddress());
        s.list->SetComputeRootUnorderedAccessView(4, s.ybuf->GetGPUVirtualAddress() + offsets[i]);
        s.list->Dispatch(static_cast<UINT>((tasks[i].rows + kRowsPerGroup - 1) / kRowsPerGroup), 1,
                         1);
    }
    if (s.trace) {
        s.list->EndQuery(s.ts_heap.Get(), D3D12_QUERY_TYPE_TIMESTAMP, 1);
    }

    D3D12_RESOURCE_BARRIER barrier{};
    barrier.Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
    barrier.Transition.pResource = s.ybuf.Get();
    barrier.Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
    barrier.Transition.StateBefore = D3D12_RESOURCE_STATE_UNORDERED_ACCESS;
    barrier.Transition.StateAfter = D3D12_RESOURCE_STATE_COPY_SOURCE;
    s.list->ResourceBarrier(1, &barrier);
    s.list->CopyBufferRegion(s.yread.Get(), 0, s.ybuf.Get(), 0, span);
    barrier.Transition.StateBefore = D3D12_RESOURCE_STATE_COPY_SOURCE;
    barrier.Transition.StateAfter = D3D12_RESOURCE_STATE_UNORDERED_ACCESS;
    s.list->ResourceBarrier(1, &barrier);
    if (s.trace) {
        s.list->EndQuery(s.ts_heap.Get(), D3D12_QUERY_TYPE_TIMESTAMP, 2);
        s.list->ResolveQueryData(s.ts_heap.Get(), D3D12_QUERY_TYPE_TIMESTAMP, 0, 3,
                                 s.ts_read.Get(), 0);
    }
    s.list->Close();

    const std::uint64_t qkv_mark = s.stats.wait_us;
    if (!execute_and_wait(s)) {
        return false;
    }
    s.stats.qkv_wait_us += s.stats.wait_us - qkv_mark;
    accumulate_gpu_us(s, s.stats.qkv_gpu_us, 0, 1);
    accumulate_gpu_us(s, s.stats.qkv_copy_us, 1, 2);
    {
        std::uint64_t dev = 0;
        accumulate_gpu_us(s, dev, 0, 1);
        note_dev(s, Comp::Projections, dev);
    }

    void* mapped = nullptr;
    const D3D12_RANGE read_range{0, span};
    if (FAILED(s.yread->Map(0, &read_range, &mapped))) {
        return false;
    }
    const auto* base = static_cast<const std::uint8_t*>(mapped);
    for (std::size_t i = 0; i < count; ++i) {
        std::memcpy(tasks[i].y, base + offsets[i], tasks[i].rows * sizeof(float));
    }
    const D3D12_RANGE write_range{0, 0};
    s.yread->Unmap(0, &write_range);
    s.stats.dispatches += count;
    ++s.stats.batches;
    return true;
}

bool gemv_locked(State& s, const std::uint8_t* weights, const float* x, float* y,
                 std::size_t rows, std::size_t columns) {
    using clock = std::chrono::steady_clock;
    auto us_since = [](clock::time_point start) {
        return static_cast<std::uint64_t>(
            std::chrono::duration_cast<std::chrono::microseconds>(clock::now() - start).count());
    };

    if (columns % kElemsPerBlock != 0) {
        return false;
    }
    WeightEntry* entry = lookup_weights(s, weights, rows, columns);
    if (!entry) {
        return false;
    }

    auto mark = clock::now();
    const std::size_t blocks_per_row = columns / kElemsPerBlock;
    if (!reserve_scratch(s, columns * sizeof(float), rows * sizeof(float))) {
        return false;
    }
    std::memcpy(s.x_cpu, x, columns * sizeof(float));

    auto* params = static_cast<GemvParams*>(s.params_cpu);
    params->rows = static_cast<std::uint32_t>(rows);
    params->blocks_per_row = static_cast<std::uint32_t>(blocks_per_row);
    params->rows_per_group = kRowsPerGroup;
    params->reserved = 0;
    s.stats.prep_us += us_since(mark);

    mark = clock::now();
    s.allocator->Reset();
    s.list->Reset(s.allocator.Get(), s.pso_gemv.Get());
    s.stats.reset_us += us_since(mark);

    mark = clock::now();
    s.list->SetComputeRootSignature(s.root.Get());
    s.list->SetComputeRootConstantBufferView(0, s.params->GetGPUVirtualAddress());
    s.list->SetComputeRootShaderResourceView(1, entry->quants->GetGPUVirtualAddress());
    s.list->SetComputeRootShaderResourceView(2, entry->scales_va);
    s.list->SetComputeRootShaderResourceView(3, s.xbuf->GetGPUVirtualAddress());
    s.list->SetComputeRootUnorderedAccessView(4, s.ybuf->GetGPUVirtualAddress());

    mark = clock::now();
    if (s.trace) {
        s.list->EndQuery(s.ts_heap.Get(), D3D12_QUERY_TYPE_TIMESTAMP, 0);
    }
    s.list->Dispatch(static_cast<UINT>((rows + kRowsPerGroup - 1) / kRowsPerGroup), 1, 1);
    if (s.trace) {
        s.list->EndQuery(s.ts_heap.Get(), D3D12_QUERY_TYPE_TIMESTAMP, 1);
    }

    if (!s.no_readback) {
        D3D12_RESOURCE_BARRIER barrier{};
        barrier.Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
        barrier.Transition.pResource = s.ybuf.Get();
        barrier.Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
        barrier.Transition.StateBefore = D3D12_RESOURCE_STATE_UNORDERED_ACCESS;
        barrier.Transition.StateAfter = D3D12_RESOURCE_STATE_COPY_SOURCE;
        s.list->ResourceBarrier(1, &barrier);
        s.list->CopyBufferRegion(s.yread.Get(), 0, s.ybuf.Get(), 0, rows * sizeof(float));
        barrier.Transition.StateBefore = D3D12_RESOURCE_STATE_COPY_SOURCE;
        barrier.Transition.StateAfter = D3D12_RESOURCE_STATE_UNORDERED_ACCESS;
        s.list->ResourceBarrier(1, &barrier);
    }
    if (s.trace) {
        s.list->ResolveQueryData(s.ts_heap.Get(), D3D12_QUERY_TYPE_TIMESTAMP, 0, 2,
                                 s.ts_read.Get(), 0);
    }
    s.list->Close();
    s.stats.record_us += us_since(mark);

    mark = clock::now();
    ID3D12CommandList* lists[] = {s.list.Get()};
    s.queue->ExecuteCommandLists(1, lists);
    if (!wait_gpu(s)) {
        return false;
    }
    s.stats.wait_us += us_since(mark);

    mark = clock::now();
    if (!s.no_readback) {
        void* mapped = nullptr;
        const D3D12_RANGE read_range{0, rows * sizeof(float)};
        if (FAILED(s.yread->Map(0, &read_range, &mapped))) {
            return false;
        }
        std::memcpy(y, mapped, rows * sizeof(float));
        const D3D12_RANGE write_range{0, 0};
        s.yread->Unmap(0, &write_range);
    }

    if (s.trace) {
        std::uint64_t* stamps = nullptr;
        const D3D12_RANGE stamp_range{0, 2 * sizeof(std::uint64_t)};
        if (SUCCEEDED(s.ts_read->Map(0, &stamp_range, reinterpret_cast<void**>(&stamps)))) {
            if (stamps[1] > stamps[0]) {
                s.stats.gpu_us += static_cast<std::uint64_t>(
                    static_cast<double>(stamps[1] - stamps[0]) * 1000000.0 /
                    static_cast<double>(s.ts_freq));
            }
            const D3D12_RANGE none{0, 0};
            s.ts_read->Unmap(0, &none);
        }
    }
    s.stats.readback_us += us_since(mark);
    ++s.stats.dispatches;
    return true;
}

bool gemm_locked(State& s, const std::uint8_t* weights, const float* input, float* output,
                 std::size_t tokens, std::size_t rows, std::size_t columns) {
    if (columns % kElemsPerBlock != 0) {
        return false;
    }
    WeightEntry* entry = lookup_weights(s, weights, rows, columns);
    if (!entry) {
        return false;
    }

    const std::size_t blocks_per_row = columns / kElemsPerBlock;
    const std::size_t padded_tokens =
        (tokens + kTokensPerTile - 1) / kTokensPerTile * kTokensPerTile;
    const std::size_t x_bytes = padded_tokens * columns * sizeof(float);
    const std::size_t y_bytes = tokens * rows * sizeof(float);
    if (!reserve_scratch(s, x_bytes, y_bytes)) {
        return false;
    }
    std::memcpy(s.x_cpu, input, tokens * columns * sizeof(float));
    if (padded_tokens > tokens) {
        std::memset(static_cast<std::uint8_t*>(s.x_cpu) + tokens * columns * sizeof(float), 0,
                    (padded_tokens - tokens) * columns * sizeof(float));
    }

    auto* params = reinterpret_cast<GemmParams*>(static_cast<std::uint8_t*>(s.params_cpu) + 256);
    params->rows = static_cast<std::uint32_t>(rows);
    params->blocks_per_row = static_cast<std::uint32_t>(blocks_per_row);
    params->token_count = static_cast<std::uint32_t>(tokens);
    params->tokens_per_tile = kTokensPerTile;

    s.allocator->Reset();
    s.list->Reset(s.allocator.Get(), s.pso_gemm.Get());
    s.list->SetComputeRootSignature(s.root.Get());
    s.list->SetComputeRootConstantBufferView(0, s.params->GetGPUVirtualAddress() + 256);
    s.list->SetComputeRootShaderResourceView(1, entry->quants->GetGPUVirtualAddress());
    s.list->SetComputeRootShaderResourceView(2, entry->scales_va);
    s.list->SetComputeRootShaderResourceView(3, s.xbuf->GetGPUVirtualAddress());
    s.list->SetComputeRootUnorderedAccessView(4, s.ybuf->GetGPUVirtualAddress());

    // One workgroup per 8-row block; the shader walks every token tile itself, so the
    // dispatch covers rows only. Without this call the kernel never ran and the
    // readback handed back ybuf's zero-initialised DEFAULT-heap contents, which the
    // caller treated as a successful all-zero prefill.
    if (s.trace) {
        s.list->EndQuery(s.ts_heap.Get(), D3D12_QUERY_TYPE_TIMESTAMP, 0);
    }
    s.list->Dispatch(
        static_cast<UINT>((rows + kGemmRowsPerGroup - 1) / kGemmRowsPerGroup), 1, 1);
    if (s.trace) {
        s.list->EndQuery(s.ts_heap.Get(), D3D12_QUERY_TYPE_TIMESTAMP, 1);
    }

    if (!s.no_readback) {
        D3D12_RESOURCE_BARRIER barrier{};
        barrier.Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
        barrier.Transition.pResource = s.ybuf.Get();
        barrier.Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
        barrier.Transition.StateBefore = D3D12_RESOURCE_STATE_UNORDERED_ACCESS;
        barrier.Transition.StateAfter = D3D12_RESOURCE_STATE_COPY_SOURCE;
        s.list->ResourceBarrier(1, &barrier);
        s.list->CopyBufferRegion(s.yread.Get(), 0, s.ybuf.Get(), 0, y_bytes);
        barrier.Transition.StateBefore = D3D12_RESOURCE_STATE_COPY_SOURCE;
        barrier.Transition.StateAfter = D3D12_RESOURCE_STATE_UNORDERED_ACCESS;
        s.list->ResourceBarrier(1, &barrier);
    }
    // Stamp 2 closes the copy region: 0..1 is the dispatch, 1..2 the readback copy.
    // Without it prefill had no GPU timing at all, and NO_READBACK was silently
    // ignored here, so an earlier "readback ruled out" test proved nothing.
    if (s.trace) {
        s.list->EndQuery(s.ts_heap.Get(), D3D12_QUERY_TYPE_TIMESTAMP, 2);
        s.list->ResolveQueryData(s.ts_heap.Get(), D3D12_QUERY_TYPE_TIMESTAMP, 0, 3,
                                 s.ts_read.Get(), 0);
    }
    s.list->Close();

    const auto start = std::chrono::steady_clock::now();
    ID3D12CommandList* lists[] = {s.list.Get()};
    ++s.stats.submits;
    s.queue->ExecuteCommandLists(1, lists);
    if (!wait_gpu(s)) {
        return false;
    }
    s.stats.wait_us += static_cast<std::uint64_t>(
        std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now() - start)
            .count());

    if (!s.no_readback) {
        void* mapped = nullptr;
        const D3D12_RANGE read_range{0, y_bytes};
        if (FAILED(s.yread->Map(0, &read_range, &mapped))) {
            return false;
        }
        std::memcpy(output, mapped, y_bytes);
        const D3D12_RANGE write_range{0, y_bytes};
        s.yread->Unmap(0, &write_range);
    }

    if (s.trace) {
        std::uint64_t* stamps = nullptr;
        const D3D12_RANGE stamp_range{0, 3 * sizeof(std::uint64_t)};
        if (SUCCEEDED(s.ts_read->Map(0, &stamp_range, reinterpret_cast<void**>(&stamps)))) {
            if (stamps[1] > stamps[0]) {
                s.stats.gpu_us += static_cast<std::uint64_t>(
                    static_cast<double>(stamps[1] - stamps[0]) * 1000000.0 /
                    static_cast<double>(s.ts_freq));
            }
            if (stamps[2] > stamps[1]) {
                s.stats.gpu_copy_us += static_cast<std::uint64_t>(
                    static_cast<double>(stamps[2] - stamps[1]) * 1000000.0 /
                    static_cast<double>(s.ts_freq));
            }
            const D3D12_RANGE none{0, 0};
            s.ts_read->Unmap(0, &none);
        }
    }
    ++s.stats.dispatches;
    return true;
}

// Batched prefill GEMM: N tasks share one input payload, one command list, one
// fence wait, one packed readback. Measured on RDNA4 (warm): a lone submit costs
// ~1.1 ms round trip after ~0.4 ms of actual kernel, so collapsing 3 Q|K|V or
// 2 gate|up submissions into one each cuts ~0.7-0.8 ms of queue latency per
// removed submit. Results are bit-identical to the unbatched gemm_locked path:
// same PSO, same parameter layout, only the execution wrapper differs.
bool gemm_batch_locked(State& s, const float* x, const GemmTask* tasks,
                       std::size_t count, std::size_t tokens,
                       std::size_t columns) {
    if (count == 0 || count > kMaxBatch) {
        return false;
    }
    if (columns % kElemsPerBlock != 0) {
        return false;
    }
    for (std::size_t i = 0; i < count; ++i) {
        if (!tasks[i].weights || !tasks[i].y || !tasks[i].rows) {
            return false;
        }
    }

    // Refcount the weight buffers before recording: a lookup_weights() call in
    // this loop may trip the VRAM budget and clear residency, which would free
    // an entry already captured but not yet bound (F-09, same as gemv_batch).
    ComPtr<ID3D12Resource> quants[kMaxBatch];
    std::uint64_t scales[kMaxBatch];
    for (std::size_t i = 0; i < count; ++i) {
        WeightEntry* entry = lookup_weights(s, tasks[i].weights, tasks[i].rows, columns);
        if (!entry) {
            return false;
        }
        quants[i] = entry->quants;
        scales[i] = entry->scales_va;
    }

    const std::size_t blocks_per_row = columns / kElemsPerBlock;
    const std::size_t padded_tokens =
        (tokens + kTokensPerTile - 1) / kTokensPerTile * kTokensPerTile;
    const std::size_t x_bytes = padded_tokens * columns * sizeof(float);
    // Outputs packed back-to-back in the shared UAV buffer at 256-byte offsets,
    // mirroring gemv_batch_locked - EXCEPT the region size: the gemm shader
    // writes y[t*rows + r] for every token, so each task's region is
    // tokens*rows floats (the gemv vector case would be rows floats only).
    // Getting this wrong made later dispatches overwrite earlier outputs.
    std::uint64_t offsets[kMaxBatch];
    std::uint64_t span = 0;
    for (std::size_t i = 0; i < count; ++i) {
        offsets[i] = span;
        const std::uint64_t y_bytes =
            static_cast<std::uint64_t>(tokens) * tasks[i].rows * sizeof(float);
        span = (span + y_bytes + 255u) & ~static_cast<std::uint64_t>(255u);
    }
    if (!reserve_scratch(s, x_bytes, span)) {
        return false;
    }
    std::memcpy(s.x_cpu, x, tokens * columns * sizeof(float));
    if (padded_tokens > tokens) {
        std::memset(static_cast<std::uint8_t*>(s.x_cpu) + tokens * columns * sizeof(float), 0,
                    (padded_tokens - tokens) * columns * sizeof(float));
    }
    for (std::size_t i = 0; i < count; ++i) {
        auto* params = reinterpret_cast<GemmParams*>(
            static_cast<std::uint8_t*>(s.params_cpu) + 1024 + 256 * i);
        params->rows = static_cast<std::uint32_t>(tasks[i].rows);
        params->blocks_per_row = static_cast<std::uint32_t>(blocks_per_row);
        params->token_count = static_cast<std::uint32_t>(tokens);
        params->tokens_per_tile = kTokensPerTile;
    }

    s.allocator->Reset();
    s.list->Reset(s.allocator.Get(), s.pso_gemm.Get());
    s.list->SetComputeRootSignature(s.root.Get());
    if (s.trace) {
        s.list->EndQuery(s.ts_heap.Get(), D3D12_QUERY_TYPE_TIMESTAMP, 0);
    }
    // Each dispatch writes a disjoint y region, so no UAV barrier is needed
    // between them (same reasoning as gemv_batch_locked).
    for (std::size_t i = 0; i < count; ++i) {
        s.list->SetComputeRootConstantBufferView(
            0, s.params->GetGPUVirtualAddress() + 1024 + 256 * i);
        s.list->SetComputeRootShaderResourceView(1, quants[i]->GetGPUVirtualAddress());
        s.list->SetComputeRootShaderResourceView(2, scales[i]);
        s.list->SetComputeRootShaderResourceView(3, s.xbuf->GetGPUVirtualAddress());
        s.list->SetComputeRootUnorderedAccessView(4, s.ybuf->GetGPUVirtualAddress() + offsets[i]);
        s.list->Dispatch(
            static_cast<UINT>((tasks[i].rows + kGemmRowsPerGroup - 1) / kGemmRowsPerGroup), 1, 1);
    }
    if (s.trace) {
        s.list->EndQuery(s.ts_heap.Get(), D3D12_QUERY_TYPE_TIMESTAMP, 1);
    }

    if (!s.no_readback) {
        D3D12_RESOURCE_BARRIER barrier{};
        barrier.Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
        barrier.Transition.pResource = s.ybuf.Get();
        barrier.Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
        barrier.Transition.StateBefore = D3D12_RESOURCE_STATE_UNORDERED_ACCESS;
        barrier.Transition.StateAfter = D3D12_RESOURCE_STATE_COPY_SOURCE;
        s.list->ResourceBarrier(1, &barrier);
        s.list->CopyBufferRegion(s.yread.Get(), 0, s.ybuf.Get(), 0, span);
        barrier.Transition.StateBefore = D3D12_RESOURCE_STATE_COPY_SOURCE;
        barrier.Transition.StateAfter = D3D12_RESOURCE_STATE_UNORDERED_ACCESS;
        s.list->ResourceBarrier(1, &barrier);
    }
    if (s.trace) {
        s.list->EndQuery(s.ts_heap.Get(), D3D12_QUERY_TYPE_TIMESTAMP, 2);
        s.list->ResolveQueryData(s.ts_heap.Get(), D3D12_QUERY_TYPE_TIMESTAMP, 0, 3,
                                 s.ts_read.Get(), 0);
    }
    s.list->Close();

    if (!execute_and_wait(s)) {
        return false;
    }

    if (!s.no_readback) {
        void* mapped = nullptr;
        const D3D12_RANGE read_range{0, span};
        if (FAILED(s.yread->Map(0, &read_range, &mapped))) {
            return false;
        }
        const auto* base = static_cast<const std::uint8_t*>(mapped);
        for (std::size_t i = 0; i < count; ++i) {
            std::memcpy(tasks[i].y, base + offsets[i],
                        tokens * tasks[i].rows * sizeof(float));
        }
        const D3D12_RANGE write_range{0, 0};
        s.yread->Unmap(0, &write_range);
    }
    s.stats.dispatches += count;
    ++s.stats.batches;
    return true;
}

// Public entry for batched prefill GEMM.
bool gemm_q8_0_batch(const float* x, const GemmTask* tasks, std::size_t count,
                     std::size_t tokens, std::size_t columns) noexcept {
    if (count == 0 || count > kMaxBatch) {
        return false;
    }
    if (columns % kElemsPerBlock != 0) {
        return false;
    }
    for (std::size_t i = 0; i < count; ++i) {
        if (!tasks[i].weights || !tasks[i].y || !tasks[i].rows) {
            return false;
        }
    }
    State& s = state();
    std::lock_guard<std::mutex> lock(s.mutex);
    if (!init_locked(s)) {
        return false;
    }
    return gemm_batch_locked(s, x, tasks, count, tokens, columns);
}

// FlashAttention for prefill with KV cache: computes multi-head attention for all tokens in parallel
// on GPU. Input Q is [tokens, heads, head_dim], K/V come from device KV cache.
// Output is [tokens, heads, head_dim].
// Uses tiled FlashAttention algorithm with causal masking and KV cache.
// Returns false if not supported (falls back to CPU attention).
bool flash_attention_prefill(const float* q, const float* k, const float* v, float* out,
                             std::size_t tokens, std::size_t heads, std::size_t kv_heads,
                             std::size_t head_dim, float inv_scale,
                             std::size_t layer, std::size_t start_pos,
                             std::size_t kv_context, std::size_t k_cache_heads, std::size_t k_cache_head_dim) noexcept {
    (void)k; (void)v; // K/V from host not used; read from device KV cache
    if (!q || !out || tokens == 0 || heads == 0 || kv_heads == 0 || head_dim == 0) {
        if (s.trace) std::printf("[d3d12] flash_attention: FAIL - null ptr or zero dims\n");
        return false;
    }
    // Only support head_dim up to 128 (shared memory limit)
    if (head_dim > 128) {
        if (s.trace) std::printf("[d3d12] flash_attention: FAIL - head_dim > 128\n");
        return false;
    }
    // Only support up to 16 kv_heads (shared memory limit)
    if (kv_heads > 16) {
        if (s.trace) std::printf("[d3d12] flash_attention: FAIL - kv_heads > 16\n");
        return false;
    }
    // Only support up to 64 heads
    if (heads > 64) {
        if (s.trace) std::printf("[d3d12] flash_attention: FAIL - heads > 64\n");
        return false;
    }
    // Only support tokens that are reasonable for BLOCK_Q=32
    if (tokens > 2048) {
        if (s.trace) std::printf("[d3d12] flash_attention: FAIL - tokens > 2048\n");
        return false;
    }

    State& s = state();
    std::lock_guard<std::mutex> lock(s.mutex);
    std::lock_guard<std::mutex> lock(s.mutex);
    if (!init_locked(s)) {
        return false;
    }
    if (!s.pso_flash_attn) {
        if (s.trace) std::printf("[d3d12] flash_attention: FAIL - pso_flash_attn null\n");
        return false;
    }
    if (!s.kcache || !s.vcache) {
        if (s.trace) std::printf("[d3d12] flash_attention: FAIL - kcache/vcache null\n");
        return false; // KV cache not configured
    }

    if (s.trace) std::printf("[d3d12] flash_attention: START tokens=%zu heads=%zu kv_heads=%zu head_dim=%zu layer=%zu start_pos=%zu\n",
                         tokens, heads, kv_heads, head_dim, layer, start_pos);

    // Upload Q to device (K/V are already in KV cache)
    const std::size_t q_bytes = tokens * heads * head_dim * sizeof(float);
    const std::size_t out_bytes = tokens * heads * head_dim * sizeof(float);

    ComPtr<ID3D12Resource> qbuf, outbuf;
    qbuf = create_buffer(s.device.Get(), q_bytes, D3D12_HEAP_TYPE_DEFAULT, D3D12_RESOURCE_STATE_COPY_DEST);
    outbuf = create_buffer(s.device.Get(), out_bytes, D3D12_HEAP_TYPE_DEFAULT, D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
    if (!qbuf || !outbuf) {
        if (s.trace) std::printf("[d3d12] flash_attention: FAIL - qbuf/outbuf create\n");
        return false;
    }

    // Upload Q data
    ComPtr<ID3D12Resource> q_upload;
    q_upload = create_buffer(s.device.Get(), q_bytes, D3D12_HEAP_TYPE_UPLOAD, D3D12_RESOURCE_STATE_GENERIC_READ);
    if (!q_upload) {
        if (s.trace) std::printf("[d3d12] flash_attention: FAIL - q_upload create\n");
        return false;
    }
    void* q_map = nullptr;
    if (FAILED(q_upload->Map(0, nullptr, &q_map))) {
        if (s.trace) std::printf("[d3d12] flash_attention: FAIL - q_upload Map\n");
        return false;
    }
    std::memcpy(q_map, q, q_bytes);
    q_upload->Unmap(0, nullptr);

    s.allocator->Reset();
    s.list->Reset(s.allocator.Get(), nullptr);
    s.list->CopyBufferRegion(qbuf.Get(), 0, q_upload.Get(), 0, q_bytes);

    // Transition Q to shader resource
    D3D12_RESOURCE_BARRIER q_barrier{};
    q_barrier.Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
    q_barrier.Flags = D3D12_RESOURCE_BARRIER_FLAG_NONE;
    q_barrier.Transition.pResource = qbuf.Get();
    q_barrier.Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
    q_barrier.Transition.StateBefore = D3D12_RESOURCE_STATE_COPY_DEST;
    q_barrier.Transition.StateAfter = D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE;
    s.list->ResourceBarrier(1, &q_barrier);

    // Set up constant buffer for FlashAttentionWithCache
    struct FlashAttnParamsCB {
        uint32_t tokens;
        uint32_t heads;
        uint32_t kv_heads;
        uint32_t head_dim;
        float inv_scale;
        uint32_t kv_cache_base;
        uint32_t kv_cache_stride;
        uint32_t valid_kv_tokens;
        uint32_t pad0;
    };
    FlashAttnParamsCB cb{};
    cb.tokens = static_cast<uint32_t>(tokens);
    cb.heads = static_cast<uint32_t>(heads);
    cb.kv_heads = static_cast<uint32_t>(kv_heads);
    cb.head_dim = static_cast<uint32_t>(head_dim);
    cb.inv_scale = inv_scale;
    cb.kv_cache_base = static_cast<uint32_t>(layer * kv_context * kv_heads * head_dim);
    cb.kv_cache_stride = static_cast<uint32_t>(kv_heads * head_dim);
    cb.valid_kv_tokens = static_cast<uint32_t>(start_pos + tokens);
    cb.pad0 = 0;
    
    // Use params buffer for constant data
    std::memcpy(s.params_cpu, &cb, sizeof(cb));
    
    // Set up root signature and pipeline
    s.list->SetComputeRootSignature(s.root.Get());
    s.list->SetPipelineState(s.pso_flash_attn.Get());
    s.list->SetComputeRootConstantBufferView(0, s.params->GetGPUVirtualAddress());
    s.list->SetComputeRootShaderResourceView(1, qbuf->GetGPUVirtualAddress());
    s.list->SetComputeRootShaderResourceView(2, s.kcache->GetGPUVirtualAddress());
    s.list->SetComputeRootShaderResourceView(3, s.vcache->GetGPUVirtualAddress());
    s.list->SetComputeRootUnorderedAccessView(4, outbuf->GetGPUVirtualAddress());

    // Dispatch: one thread block per Q block (BLOCK_Q=32 tokens)
    const uint32_t q_blocks = static_cast<uint32_t>((tokens + 31) / 32);
    s.list->Dispatch(q_blocks, 1, 1);

    // Transition output to copy source
    D3D12_RESOURCE_BARRIER out_barrier{};
    out_barrier.Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
    out_barrier.Flags = D3D12_RESOURCE_BARRIER_FLAG_NONE;
    out_barrier.Transition.pResource = outbuf.Get();
    out_barrier.Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
    out_barrier.Transition.StateBefore = D3D12_RESOURCE_STATE_UNORDERED_ACCESS;
    out_barrier.Transition.StateAfter = D3D12_RESOURCE_STATE_COPY_SOURCE;
    s.list->ResourceBarrier(1, &out_barrier);

    // Readback output
    ComPtr<ID3D12Resource> out_readback = create_buffer(s.device.Get(), out_bytes, D3D12_HEAP_TYPE_READBACK, D3D12_RESOURCE_STATE_COPY_DEST);
    if (!out_readback) {
        if (s.trace) std::printf("[d3d12] flash_attention: FAIL - out_readback create\n");
        return false;
    }
    s.list->CopyBufferRegion(out_readback.Get(), 0, outbuf.Get(), 0, out_bytes);
    s.list->Close();

    if (!execute_and_wait(s)) {
        if (s.trace) std::printf("[d3d12] flash_attention: FAIL - execute_and_wait\n");
        return false;
    }

    // Map and copy output
    void* mapped = nullptr;
    const D3D12_RANGE read_range{0, out_bytes};
    if (FAILED(out_readback->Map(0, &read_range, &mapped))) {
        if (s.trace) std::printf("[d3d12] flash_attention: FAIL - out_readback Map\n");
        return false;
    }
    std::memcpy(out, mapped, out_bytes);
    const D3D12_RANGE write_range{0, 0};
    out_readback->Unmap(0, &write_range);

    if (s.trace) std::printf("[d3d12] flash_attention: SUCCESS\n");
    return true;
}

// Public API functions in zen::d3d12 namespace
bool enabled() noexcept {
    if (!opted_in()) {
        return false;
    }
    State& s = state();
    std::lock_guard<std::mutex> lock(s.mutex);
    return s.ready;
}

const AdapterInfo* info() noexcept {
    State& s = state();
    std::lock_guard<std::mutex> lock(s.mutex);
    if (!s.ready) {
        return nullptr;
    }
    return &s.adapter;
}

const Stats& stats() noexcept { return state().stats; }

void trace_report() {
    print_trace_report();
}

// Public wrapper for pipelined multi-layer decode
bool layer_decode_pipeline(const LayerDecodeParams* layers, std::size_t num_layers,
                           const float* input, float* output,
                           const float* cos, const float* sin, std::size_t pairs,
                           std::size_t hidden, std::size_t heads, std::size_t kv_heads,
                           std::size_t head_dim, std::size_t ffn_rows, float epsilon) noexcept {
    if (!layers || !input || !output || num_layers == 0 || num_layers > 64) {
        return false;
    }
    State& s = state();
    std::lock_guard<std::mutex> lock(s.mutex);
    if (!init_locked(s)) {
        return false;
    }
    return layer_decode_pipeline(layers, num_layers, input, output,
                                 cos, sin, pairs, hidden, heads, kv_heads,
                                 head_dim, ffn_rows, epsilon);
}

bool init() noexcept {
    if (!opted_in()) {
        return false;
    }
    State& s = state();
    std::lock_guard<std::mutex> lock(s.mutex);
    const char* trace = std::getenv("ZEN_D3D12_TRACE");
    s.trace = trace && trace[0] == '1';
    // The timestamp calibration bench needs the query heap that only the trace flag
    // creates. Implying trace here keeps it from silently reporting zero samples.
    if (const char* gputs = std::getenv("ZEN_D3D12_BENCH_GPUTS"); gputs && gputs[0] == '1') {
        s.trace = true;
    }
    const char* no_readback = std::getenv("ZEN_D3D12_NO_READBACK");
    s.no_readback = no_readback && no_readback[0] == '1';
    return init_locked(s);
}

void shutdown() noexcept {
    State& s = state();
    std::lock_guard<std::mutex> lock(s.mutex);
    if (s.ready) {
        wait_gpu(s);
    }
    s.weights.clear();
    s.weight_bytes = 0;
    s.ybuf.Reset();
    s.yread.Reset();
    s.stage.Reset();
    s.stage_cpu = nullptr;
    s.stage_cap = 0;
    s.xbuf.Reset();
    s.x_cap = 0;
    s.y_cap = 0;
    s.params.Reset();
    s.params_cpu = nullptr;
    s.nbuf.Reset();
    s.n_cpu = nullptr;
    s.n_cap = 0;
    // Every device-created object must go, and every cached size must go with it:
    // leaving f_cap/w_cap set while the buffer is released would let a later init
    // reuse a scratch buffer that belongs to the destroyed device.
    s.pso_gemv.Reset();
    s.pso_gemm.Reset();
    s.pso_silu.Reset();
    s.pso_rms.Reset();
    s.pso_addn.Reset();
    s.pso_flash_attn.Reset();
    s.fbuf.Reset();
    s.f_cap = 0;
    s.wbuf.Reset();
    s.w_cap = 0;
    s.w_cpu = nullptr;
    s.ts_heap.Reset();
    s.ts_read.Reset();
    s.ts_freq = 0;
    s.root.Reset();
    if (s.copy_fence_event) {
        CloseHandle(s.copy_fence_event);
        s.copy_fence_event = nullptr;
    }
    s.copy_fence.Reset();
    s.copy_list.Reset();
    s.copy_allocator.Reset();
    s.copy_queue.Reset();
    if (s.fence_event) {
        CloseHandle(s.fence_event);
        s.fence_event = nullptr;
    }
    s.fence.Reset();
    s.list.Reset();
    s.allocator.Reset();
    s.queue.Reset();
    s.device.Reset();
    s.ready = false;
    // A failed init latches this; clearing it here is what makes shutdown() a real
    // reset instead of a one-way trip into permanent failure.
    s.failed = false;
    s.trace = false;
    s.no_readback = false;
}

struct SiluParams {
    std::uint32_t count;
    std::uint32_t pad0;
    std::uint32_t pad1;
    std::uint32_t pad2;
};

// gate -> up -> SiLU -> down, all in one command list. The activation never leaves
// the device, so this replaces two submissions (each carrying ~70us of fixed cost)
// with one.
bool gemv_ffn_locked(State& s, const std::uint8_t* gate_w, const std::uint8_t* up_w,
                     const std::uint8_t* down_w, const float* x, float* y,
                     std::size_t ffn_rows, std::size_t columns, std::size_t out_rows) {
    if (ffn_rows == 0 || out_rows == 0 || columns % kElemsPerBlock != 0) {
        return false;
    }
    // Same F-09 reasoning as the batched path: each lookup may evict what the previous
    // one just inserted, so keep refcounted handles instead of raw entry pointers.
    ComPtr<ID3D12Resource> gate_q, up_q, down_q;
    std::uint64_t gate_s{}, up_s{}, down_s{};
    if (WeightEntry* e = lookup_weights(s, gate_w, ffn_rows, columns)) {
        gate_q = e->quants;
        gate_s = e->scales_va;
    } else {
        return false;
    }
    if (WeightEntry* e = lookup_weights(s, up_w, ffn_rows, columns)) {
        up_q = e->quants;
        up_s = e->scales_va;
    } else {
        return false;
    }
    if (WeightEntry* e = lookup_weights(s, down_w, out_rows, ffn_rows)) {
        down_q = e->quants;
        down_s = e->scales_va;
    } else {
        return false;
    }

    const std::uint64_t align = 256u;
    const std::uint64_t row_span = (ffn_rows * sizeof(float) + align - 1) & ~(align - 1);
    const std::uint64_t out_span = (out_rows * sizeof(float) + align - 1) & ~(align - 1);
    const std::uint64_t off_up = row_span;
    const std::uint64_t off_down = row_span + row_span;
    if (!reserve_scratch(s, columns * sizeof(float), off_down + out_span)) {
        return false;
    }

    const std::size_t f_bytes = ffn_rows * sizeof(float);
    if (f_bytes > s.f_cap) {
        s.fbuf.Reset();
        s.fbuf = create_buffer(s.device.Get(), f_bytes, D3D12_HEAP_TYPE_DEFAULT,
                               D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
                               D3D12_RESOURCE_FLAG_ALLOW_UNORDERED_ACCESS);
        if (!s.fbuf) {
            s.f_cap = 0;
            return false;
        }
        s.f_cap = f_bytes;
    }

    std::memcpy(s.x_cpu, x, columns * sizeof(float));

    auto* base = static_cast<std::uint8_t*>(s.params_cpu);
    auto write_gemv = [&](std::size_t slot, std::size_t rows, std::size_t cols) {
        auto* params = reinterpret_cast<GemvParams*>(base + 512 + 256 * slot);
        params->rows = static_cast<std::uint32_t>(rows);
        params->blocks_per_row = static_cast<std::uint32_t>(cols / kElemsPerBlock);
        params->rows_per_group = kRowsPerGroup;
        params->reserved = 0;
    };
    write_gemv(0, ffn_rows, columns);
    write_gemv(1, ffn_rows, columns);
    write_gemv(2, out_rows, ffn_rows);
    auto* silu = reinterpret_cast<SiluParams*>(base + 512 + 256 * 3);
    silu->count = static_cast<std::uint32_t>(ffn_rows);
    silu->pad0 = silu->pad1 = silu->pad2 = 0;

    const UINT ffn_groups = static_cast<UINT>((ffn_rows + kRowsPerGroup - 1) / kRowsPerGroup);
    const UINT out_groups = static_cast<UINT>((out_rows + kRowsPerGroup - 1) / kRowsPerGroup);
    const UINT silu_groups = static_cast<UINT>((ffn_rows + 255) / 256);
    const std::uint64_t params_base = s.params->GetGPUVirtualAddress();
    const std::uint64_t y_base = s.ybuf->GetGPUVirtualAddress();

    s.allocator->Reset();
    s.list->Reset(s.allocator.Get(), s.pso_gemv.Get());
    s.list->SetComputeRootSignature(s.root.Get());
    if (s.trace) {
        s.list->EndQuery(s.ts_heap.Get(), D3D12_QUERY_TYPE_TIMESTAMP, 0);
    }

    s.list->SetComputeRootConstantBufferView(0, params_base + 512);
    s.list->SetComputeRootShaderResourceView(1, gate_q->GetGPUVirtualAddress());
    s.list->SetComputeRootShaderResourceView(2, gate_s);
    s.list->SetComputeRootShaderResourceView(3, s.xbuf->GetGPUVirtualAddress());
    s.list->SetComputeRootUnorderedAccessView(4, y_base);
    s.list->Dispatch(ffn_groups, 1, 1);

    s.list->SetComputeRootConstantBufferView(0, params_base + 512 + 256);
    s.list->SetComputeRootShaderResourceView(1, up_q->GetGPUVirtualAddress());
    s.current_comp = Comp::FfnUpDown;
    s.list->SetComputeRootShaderResourceView(2, up_s);
    s.list->SetComputeRootUnorderedAccessView(4, y_base + off_up);
    s.list->Dispatch(ffn_groups, 1, 1);

    // The SiLU kernel reads the two matvec results as shader resources.
    transition(s, s.ybuf.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
               D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
    s.list->SetPipelineState(s.pso_silu.Get());
    s.list->SetComputeRootConstantBufferView(0, params_base + 512 + 256 * 3);
    s.list->SetComputeRootShaderResourceView(1, y_base);
    s.list->SetComputeRootShaderResourceView(2, y_base + off_up);
    s.list->SetComputeRootUnorderedAccessView(4, s.fbuf->GetGPUVirtualAddress());
    s.list->Dispatch(silu_groups, 1, 1);
    transition(s, s.fbuf.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
               D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
    transition(s, s.ybuf.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
               D3D12_RESOURCE_STATE_UNORDERED_ACCESS);

    s.list->SetPipelineState(s.pso_gemv.Get());
    s.list->SetComputeRootConstantBufferView(0, params_base + 512 + 256 * 2);
    s.list->SetComputeRootShaderResourceView(1, down_q->GetGPUVirtualAddress());
    s.list->SetComputeRootShaderResourceView(2, down_s);
    s.list->SetComputeRootShaderResourceView(3, s.fbuf->GetGPUVirtualAddress());
    s.list->SetComputeRootUnorderedAccessView(4, y_base + off_down);
    s.list->Dispatch(out_groups, 1, 1);
    if (s.trace) {
        s.list->EndQuery(s.ts_heap.Get(), D3D12_QUERY_TYPE_TIMESTAMP, 1);
    }

    transition(s, s.ybuf.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
               D3D12_RESOURCE_STATE_COPY_SOURCE);
    s.list->CopyBufferRegion(s.yread.Get(), 0, s.ybuf.Get(), off_down, out_rows * sizeof(float));
    transition(s, s.ybuf.Get(), D3D12_RESOURCE_STATE_COPY_SOURCE,
               D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
    if (s.trace) {
        s.list->EndQuery(s.ts_heap.Get(), D3D12_QUERY_TYPE_TIMESTAMP, 2);
        s.list->ResolveQueryData(s.ts_heap.Get(), D3D12_QUERY_TYPE_TIMESTAMP, 0, 3,
                                 s.ts_read.Get(), 0);
    }
    s.list->Close();

    const std::uint64_t ffn_mark = s.stats.wait_us;
    if (!execute_and_wait(s)) {
        return false;
    }
    s.stats.ffn_wait_us += s.stats.wait_us - ffn_mark;
    accumulate_gpu_us(s, s.stats.ffn_gpu_us, 0, 1);
    accumulate_gpu_us(s, s.stats.ffn_copy_us, 1, 2);
    {
        std::uint64_t dev = 0;
        accumulate_gpu_us(s, dev, 0, 1);
        note_dev(s, Comp::FfnUpDown, dev);
    }

    void* mapped = nullptr;
    const D3D12_RANGE read_range{0, out_rows * sizeof(float)};
    if (FAILED(s.yread->Map(0, &read_range, &mapped))) {
        return false;
    }
    std::memcpy(y, mapped, out_rows * sizeof(float));
    const D3D12_RANGE written{0, 0};
    s.yread->Unmap(0, &written);
    s.stats.dispatches += 4;
    ++s.stats.batches;
    return true;
}

bool gemv_q8_0_batch(const float* x, const GemvTask* tasks, std::size_t count) noexcept {
    if (count < 2) {
        return false;
    }
    std::size_t work = 0;
    for (std::size_t i = 0; i < count; ++i) {
        work += tasks[i].rows * tasks[i].columns;
    }
    if (work < kMinElements) {
        return false;
    }
    State& s = state();
    std::lock_guard<std::mutex> lock(s.mutex);
    if (!init_locked(s)) {
        return false;
    }
    if (!gemv_batch_locked(s, x, tasks, count)) {
        ++s.stats.fallbacks;
        return false;
    }
    return true;
}

struct AddnParams {
    std::uint32_t count;
    std::uint32_t pad0;
    std::uint32_t pad1;
    std::uint32_t pad2;
};

// Element-wise out = a + b. The two operands arrive through the two upload buffers
// already used for activations and small vectors, so no new residency is needed.
bool addn_locked(State& s, const float* a, const float* b, float* out, std::size_t count) {
    if (!count) {
        return false;
    }
    const std::size_t bytes = count * sizeof(float);
    if (!reserve_scratch(s, bytes, bytes)) {
        return false;
    }
    std::memcpy(s.x_cpu, a, bytes);

    if (bytes > s.w_cap) {
        s.wbuf.Reset();
        s.wbuf = create_buffer(s.device.Get(), bytes, upload_heap_type(),
                               upload_heap_state());
        if (!s.wbuf || FAILED(s.wbuf->Map(0, nullptr, &s.w_cpu))) {
            s.w_cap = 0;
            return false;
        }
        s.w_cap = bytes;
    }
    std::memcpy(s.w_cpu, b, bytes);

    // Offset 768 is outside both the lone-matvec slot (0) and the gemm/rms slot (256),
    // so a residual add never aliases parameters of another in-flight shape.
    s.current_comp = Comp::Residual;
    constexpr std::uint64_t kAddnParamOffset = 768;
    auto* params =
        reinterpret_cast<AddnParams*>(static_cast<std::uint8_t*>(s.params_cpu) + kAddnParamOffset);
    params->count = static_cast<std::uint32_t>(count);
    params->pad0 = params->pad1 = params->pad2 = 0;

    const UINT groups = static_cast<UINT>((count + 255) / 256);

    s.allocator->Reset();
    s.list->Reset(s.allocator.Get(), s.pso_addn.Get());
    s.list->SetComputeRootSignature(s.root.Get());
    s.list->SetComputeRootConstantBufferView(0, s.params->GetGPUVirtualAddress() + kAddnParamOffset);
    s.list->SetComputeRootShaderResourceView(1, s.xbuf->GetGPUVirtualAddress());
    s.list->SetComputeRootShaderResourceView(2, s.wbuf->GetGPUVirtualAddress());
    s.list->SetComputeRootUnorderedAccessView(4, s.ybuf->GetGPUVirtualAddress());
    s.list->Dispatch(groups, 1, 1);

    transition(s, s.ybuf.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
               D3D12_RESOURCE_STATE_COPY_SOURCE);
    s.list->CopyBufferRegion(s.yread.Get(), 0, s.ybuf.Get(), 0, bytes);
    transition(s, s.ybuf.Get(), D3D12_RESOURCE_STATE_COPY_SOURCE,
               D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
    s.list->Close();

    if (!execute_and_wait(s)) {
        return false;
    }

    void* mapped = nullptr;
    const D3D12_RANGE read_range{0, bytes};
    if (FAILED(s.yread->Map(0, &read_range, &mapped))) {
        return false;
    }
    std::memcpy(out, mapped, bytes);
    const D3D12_RANGE written{0, 0};
    s.yread->Unmap(0, &written);
    ++s.stats.dispatches;
    return true;
}

struct RmsParams {
    std::uint32_t count;
    std::uint32_t rows;
    float epsilon;
    std::uint32_t pad;
};

// Matches rope.hlsl's cbuffer. `pairs` is rotary_dim/2; the field is not called
// `half` because that is a reserved HLSL type and shadowing it breaks the shader.
struct RopeParams {
    std::uint32_t heads;
    std::uint32_t head_dim;
    std::uint32_t pairs;
    std::uint32_t pad0;
};

namespace {
// Parameter slots. 1024/1280 sit clear of the lone-matvec slot (0), the gemm/rms slot
// (256), the addn slot (768) and both fused-FFN slots (>= 2560), so no two in-flight
// shapes ever alias the same bytes of the parameter buffer.
constexpr std::uint64_t kRopeParamOffset = 1024;
constexpr std::uint64_t kRopeParamOffset2 = 1536;  // second rope dispatch (k)
}  // namespace

// Rotary position embedding applied on the device to q or k.
//
// The cos/sin table is evaluated on the host and uploaded. The CPU path builds it with
// std::pow/cos/sin in double-promoted arithmetic; recomputing it with powf/cosf here
// would differ in the last bits and could flip a sampled id, so the kernel only
// rotates. Both tables share one upload buffer, with the sin table pushed to a
// 256-byte boundary because that is what a root SRV wants for its base address.
bool rope_locked(State& s, const float* x, const float* cos, const float* sin, float* out,
                 std::size_t heads, std::size_t head_dim, std::size_t pairs) {
    if (!heads || !head_dim || !pairs || pairs * 2 > head_dim) {
        return false;
    }
    const std::size_t bytes = heads * head_dim * sizeof(float);
    if (!reserve_scratch(s, bytes, bytes)) {
        return false;
    }
    std::memcpy(s.x_cpu, x, bytes);

    const std::size_t tab_bytes = pairs * sizeof(float);
    const std::size_t sin_off = (tab_bytes + 255u) & ~std::size_t{255u};
    const std::size_t w_bytes = sin_off + tab_bytes;
    if (w_bytes > s.w_cap) {
        s.wbuf.Reset();
        s.wbuf = create_buffer(s.device.Get(), w_bytes, upload_heap_type(),
                               upload_heap_state());
        if (!s.wbuf || FAILED(s.wbuf->Map(0, nullptr, &s.w_cpu))) {
            s.w_cap = 0;
            return false;
        }
        s.w_cap = w_bytes;
    }
    std::memcpy(s.w_cpu, cos, tab_bytes);
    std::memcpy(static_cast<std::uint8_t*>(s.w_cpu) + sin_off, sin, tab_bytes);

    auto* params =
        reinterpret_cast<RopeParams*>(static_cast<std::uint8_t*>(s.params_cpu) + kRopeParamOffset);
    params->heads = static_cast<std::uint32_t>(heads);
    params->head_dim = static_cast<std::uint32_t>(head_dim);
    params->pairs = static_cast<std::uint32_t>(pairs);
    params->pad0 = 0;

    // One thread per output element: the kernel covers the whole head and copies the
    // dimensions past rotary_dim through, so the grid is heads * head_dim.
    const UINT groups = static_cast<UINT>((heads * head_dim + 255) / 256);

    s.allocator->Reset();
    s.list->Reset(s.allocator.Get(), s.pso_rope.Get());
    s.list->SetComputeRootSignature(s.root.Get());
    s.list->SetComputeRootConstantBufferView(0, s.params->GetGPUVirtualAddress() +
                                                    kRopeParamOffset);
    s.list->SetComputeRootShaderResourceView(1, s.xbuf->GetGPUVirtualAddress());
    s.list->SetComputeRootShaderResourceView(2, s.wbuf->GetGPUVirtualAddress());
    s.list->SetComputeRootShaderResourceView(3, s.wbuf->GetGPUVirtualAddress() + sin_off);
    s.list->SetComputeRootUnorderedAccessView(4, s.ybuf->GetGPUVirtualAddress());

    s.current_comp = Comp::Norms;
    s.list->Dispatch(groups, 1, 1);

    transition(s, s.ybuf.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
               D3D12_RESOURCE_STATE_COPY_SOURCE);
    s.list->CopyBufferRegion(s.yread.Get(), 0, s.ybuf.Get(), 0, bytes);
    transition(s, s.ybuf.Get(), D3D12_RESOURCE_STATE_COPY_SOURCE,
               D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
    s.list->Close();

    if (!execute_and_wait(s)) {
        return false;
    }

    void* mapped = nullptr;
    const D3D12_RANGE read_range{0, bytes};
    if (FAILED(s.yread->Map(0, &read_range, &mapped))) {
        return false;
    }
    std::memcpy(out, mapped, bytes);
    const D3D12_RANGE written{0, 0};
    s.yread->Unmap(0, &written);
    ++s.stats.dispatches;
    return true;
}

bool rope_apply(const float* x, const float* cos, const float* sin, float* out,
                std::size_t heads, std::size_t head_dim, std::size_t pairs) noexcept {
    State& s = state();
    std::lock_guard<std::mutex> lock(s.mutex);
    if (!init_locked(s)) {
        return false;
    }
    if (!rope_locked(s, x, cos, sin, out, heads, head_dim, pairs)) {
        ++s.stats.fallbacks;
        return false;
    }
    return true;
}

// Matches attention.hlsl's cbuffer exactly: 8 uints then floats, 12 dwords in total.
struct AttnParams {
    std::uint32_t heads;
    std::uint32_t kv_heads;
    std::uint32_t head_dim;
    std::uint32_t context;
    std::uint32_t first_pos;
    std::uint32_t pos;
    std::uint32_t scores_off;
    std::uint32_t out_off;
    float inv_scale;
    float pad0, pad1, pad2;
};

namespace {
constexpr std::uint64_t kAttnParamOffset = 1280;
}

// (Re)creates a CPU-visible buffer and maps it. Upload-heap resources are used for
// q/k/v and the cos/sin table because those are only ever read as SRVs on the GPU, and
// staying CPU-visible avoids a staging copy for a few kilobytes per layer.
bool attn_upload(State& s, ComPtr<ID3D12Resource>& buf, void*& cpu, std::size_t& cap,
                 std::size_t bytes) {
    if (bytes <= cap && buf) {
        return true;
    }
    buf.Reset();
    cpu = nullptr;
    cap = 0;
    buf = create_buffer(s.device.Get(), bytes, upload_heap_type(), upload_heap_state());
    if (!buf || FAILED(buf->Map(0, nullptr, &cpu))) {
        buf.Reset();
        cpu = nullptr;
        return false;
    }
    cap = bytes;
    return true;
}

// Creates a VRAM buffer whose state the caller manages explicitly. COMMON as the
// initial state keeps the first barrier honest whatever heap the caller picked.
bool attn_device(State& s, ComPtr<ID3D12Resource>& buf, std::size_t& cap, std::size_t bytes) {
    if (bytes <= cap && buf) {
        return true;
    }
    buf.Reset();
    cap = 0;
    D3D12_HEAP_PROPERTIES heap{};
    heap.Type = D3D12_HEAP_TYPE_DEFAULT;
    D3D12_RESOURCE_DESC desc{};
    desc.Dimension = D3D12_RESOURCE_DIMENSION_BUFFER;
    desc.Width = bytes;
    desc.Height = 1;
    desc.DepthOrArraySize = 1;
    desc.MipLevels = 1;
    desc.SampleDesc.Count = 1;
    desc.Layout = D3D12_TEXTURE_LAYOUT_ROW_MAJOR;
    // Without this flag every use as a UAV is an invalid call that removes the device,
    // which is what made the first attention_block submission poison every allocation
    // after it. reserve_scratch sets it for ybuf for exactly this reason.
    desc.Flags = D3D12_RESOURCE_FLAG_ALLOW_UNORDERED_ACCESS;
    if (FAILED(s.device->CreateCommittedResource(&heap, D3D12_HEAP_FLAG_NONE, &desc,
                                                 D3D12_RESOURCE_STATE_COMMON, nullptr,
                                                 IID_PPV_ARGS(&buf)))) {
        buf.Reset();
        return false;
    }
    cap = bytes;
    return true;
}

bool kv_cache_configure(std::size_t layers, std::size_t context, std::size_t kv_heads,
                        std::size_t head_dim) noexcept {
    if (!layers || !context || !kv_heads || !head_dim) {
        return false;
    }
    State& s = state();
    std::lock_guard<std::mutex> lock(s.mutex);
    if (!init_locked(s)) {
        return false;
    }
    if (s.kcache && s.kv_layers == layers && s.kv_context == context &&
        s.kv_heads == kv_heads && s.kv_head_dim == head_dim) {
        return true;
    }
    const std::size_t bytes = layers * kv_heads * context * head_dim * sizeof(float);
    s.kcache.Reset();
    s.vcache.Reset();
    D3D12_HEAP_PROPERTIES heap{};
    heap.Type = D3D12_HEAP_TYPE_DEFAULT;
    D3D12_RESOURCE_DESC desc{};
    desc.Dimension = D3D12_RESOURCE_DIMENSION_BUFFER;
    desc.Width = bytes;
    desc.Height = 1;
    desc.DepthOrArraySize = 1;
    desc.MipLevels = 1;
    desc.SampleDesc.Count = 1;
    desc.Layout = D3D12_TEXTURE_LAYOUT_ROW_MAJOR;
    if (FAILED(s.device->CreateCommittedResource(&heap, D3D12_HEAP_FLAG_NONE, &desc,
                                                 D3D12_RESOURCE_STATE_COMMON, nullptr,
                                                 IID_PPV_ARGS(&s.kcache)))) {
        std::fprintf(stderr, "kv: kcache create %zu bytes failed\n", bytes);
        return false;
    }
    if (FAILED(s.device->CreateCommittedResource(&heap, D3D12_HEAP_FLAG_NONE, &desc,
                                                 D3D12_RESOURCE_STATE_COMMON, nullptr,
                                                 IID_PPV_ARGS(&s.vcache)))) {
        std::fprintf(stderr, "kv: vcache create %zu bytes failed\n", bytes);
        s.kcache.Reset();
        return false;
    }
    s.kv_layers = layers;
    s.kv_context = context;
    s.kv_heads = kv_heads;
    s.kv_head_dim = head_dim;

    // Move both caches out of COMMON once, so the per-token path can assume they are
    // already readable and only needs the copy-destination round trip.
    s.allocator->Reset();
    s.list->Reset(s.allocator.Get(), nullptr);
    transition(s, s.kcache.Get(), D3D12_RESOURCE_STATE_COMMON,
               D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
    transition(s, s.vcache.Get(), D3D12_RESOURCE_STATE_COMMON,
               D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
    s.list->Close();
    if (!execute_and_wait(s)) {
        std::fprintf(stderr, "kv: initial transition submit failed\n");
        return false;
    }
    return true;
}

void kv_cache_reset() noexcept {
    State& s = state();
    std::lock_guard<std::mutex> lock(s.mutex);
    if (!s.kcache) {
        return;
    }
    s.kcache.Reset();
    s.vcache.Reset();
    s.kv_layers = s.kv_context = s.kv_heads = s.kv_head_dim = 0;
}

// Whole attention block of one decode step on the device:
//   qr = rope(q);  kr = rope(k);  cache[..][pos] = kr / v;
//   att = softmax(qr . cache_k / sqrt(d)) . cache_v
// One submission, one readback of `att`. The cache never leaves VRAM, which is the
// point of tasks 4 and 6 in docs/d3d12_full_backend_todo.md.
bool attn_block_locked(State& s, const float* q, const float* k, const float* v,
                       const float* cos, const float* sin, std::size_t heads,
                       std::size_t kv_heads, std::size_t head_dim, std::size_t pairs,
                       std::size_t layer, std::size_t pos, std::size_t first_pos,
                       float* out) {
    if (!heads || !kv_heads || !head_dim || !pairs || pairs * 2 > head_dim) {
        return false;
    }
    if (!s.kcache || layer >= s.kv_layers || pos >= s.kv_context) {
        return false;
    }
    if (s.kv_heads != kv_heads || s.kv_head_dim != head_dim) {
        return false;
    }

    const std::size_t q_bytes = heads * head_dim * sizeof(float);
    const std::size_t kv_bytes = kv_heads * head_dim * sizeof(float);
    const std::size_t tab_bytes = pairs * sizeof(float);
    // Scores and the block output are disjoint regions of one UAV, because the root
    // signature exposes a single UAV slot. See attention.hlsl.
    const std::size_t scores_floats = heads * s.kv_context;
    const std::size_t att_floats = heads * head_dim;
    const std::size_t datt_bytes = (scores_floats + att_floats) * sizeof(float);

    if (!attn_upload(s, s.dq, s.dq_cpu, s.dq_cap, q_bytes)) {
        std::fprintf(stderr, "attn: dq upload %zu bytes failed\n", q_bytes);
        return false;
    }
    if (!attn_upload(s, s.dk, s.dk_cpu, s.dk_cap, kv_bytes)) {
        std::fprintf(stderr, "attn: dk upload %zu bytes failed\n", kv_bytes);
        return false;
    }
    if (!attn_upload(s, s.dv, s.dv_cpu, s.dv_cap, kv_bytes)) {
        std::fprintf(stderr, "attn: dv upload %zu bytes failed\n", kv_bytes);
        return false;
    }
    if (!attn_upload(s, s.dcos, s.dcos_cpu, s.dcos_cap, tab_bytes)) {
        std::fprintf(stderr, "attn: dcos upload %zu bytes failed\n", tab_bytes);
        return false;
    }
    if (!attn_upload(s, s.dsin, s.dsin_cpu, s.dsin_cap, tab_bytes)) {
        std::fprintf(stderr, "attn: dsin upload %zu bytes failed\n", tab_bytes);
        return false;
    }
    if (!attn_device(s, s.dqr, s.dqr_cap, q_bytes)) {
        std::fprintf(stderr, "attn: dqr device %zu bytes failed\n", q_bytes);
        return false;
    }
    if (!attn_device(s, s.dkr, s.dkr_cap, kv_bytes)) {
        std::fprintf(stderr, "attn: dkr device %zu bytes failed\n", kv_bytes);
        return false;
    }
    if (!attn_device(s, s.datt, s.datt_cap, datt_bytes)) {
        std::fprintf(stderr, "attn: datt device %zu bytes failed\n", datt_bytes);
        return false;
    }
    if (!reserve_scratch(s, q_bytes, q_bytes)) {
        std::fprintf(stderr, "attn: reserve_scratch %zu bytes failed\n", q_bytes);
        return false;
    }

    std::memcpy(s.dq_cpu, q, q_bytes);
    std::memcpy(s.dk_cpu, k, kv_bytes);
    std::memcpy(s.dv_cpu, v, kv_bytes);
    std::memcpy(s.dcos_cpu, cos, tab_bytes);
    std::memcpy(s.dsin_cpu, sin, tab_bytes);

    auto* rp = reinterpret_cast<RopeParams*>(static_cast<std::uint8_t*>(s.params_cpu) +
                                             kRopeParamOffset);
    auto* ap = reinterpret_cast<AttnParams*>(static_cast<std::uint8_t*>(s.params_cpu) +
                                             kAttnParamOffset);

    s.allocator->Reset();
    s.list->Reset(s.allocator.Get(), s.pso_rope.Get());
    s.list->SetComputeRootSignature(s.root.Get());
    s.current_comp = Comp::Norms;

    // 1/2. RoPE on q and k. Both write VRAM buffers that attention then reads.
    transition(s, s.dqr.Get(), D3D12_RESOURCE_STATE_COMMON,
               D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
    transition(s, s.dkr.Get(), D3D12_RESOURCE_STATE_COMMON,
               D3D12_RESOURCE_STATE_UNORDERED_ACCESS);

    const UINT rope_groups = static_cast<UINT>((heads * head_dim + 255) / 256);
    rp->heads = static_cast<std::uint32_t>(heads);
    rp->head_dim = static_cast<std::uint32_t>(head_dim);
    rp->pairs = static_cast<std::uint32_t>(pairs);
    rp->pad0 = 0;
    s.list->SetComputeRootConstantBufferView(0, s.params->GetGPUVirtualAddress() +
                                                    kRopeParamOffset);
    s.list->SetComputeRootShaderResourceView(1, s.dq->GetGPUVirtualAddress());
    s.list->SetComputeRootShaderResourceView(2, s.dcos->GetGPUVirtualAddress());
    s.list->SetComputeRootShaderResourceView(3, s.dsin->GetGPUVirtualAddress());
    s.list->SetComputeRootUnorderedAccessView(4, s.dqr->GetGPUVirtualAddress());
    s.list->Dispatch(rope_groups, 1, 1);

    // Separate parameter slot: both rope dispatches used to share one cbuffer, and the
    // GPU reads the slot at execution time, so the q dispatch would have run with the
    // k dispatch's head count.
    const UINT krope_groups = static_cast<UINT>((kv_heads * head_dim + 255) / 256);
    auto* krp = reinterpret_cast<RopeParams*>(static_cast<std::uint8_t*>(s.params_cpu) +
                                              kRopeParamOffset2);
    krp->heads = static_cast<std::uint32_t>(kv_heads);
    krp->head_dim = static_cast<std::uint32_t>(head_dim);
    krp->pairs = static_cast<std::uint32_t>(pairs);
    krp->pad0 = 0;
    s.list->SetComputeRootConstantBufferView(0, s.params->GetGPUVirtualAddress() +
                                                    kRopeParamOffset2);
    s.list->SetComputeRootShaderResourceView(1, s.dk->GetGPUVirtualAddress());
    s.list->SetComputeRootUnorderedAccessView(4, s.dkr->GetGPUVirtualAddress());
    s.list->Dispatch(krope_groups, 1, 1);

    // 3. Append k and v at this position. Device-to-device, no host round trip.
    transition(s, s.dqr.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
               D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
    transition(s, s.dkr.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
               D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
    transition(s, s.kcache.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
               D3D12_RESOURCE_STATE_COPY_DEST);
    transition(s, s.vcache.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
               D3D12_RESOURCE_STATE_COPY_DEST);

    const std::size_t stride = s.kv_heads * s.kv_context * s.kv_head_dim * sizeof(float);
    const std::size_t kv_width = kv_heads * head_dim * sizeof(float);
    // One contiguous copy per tensor: the cache is [context][kv_head][head_dim], so a
    // whole token's row for every KV head is adjacent.
    const std::size_t dst = layer * stride + pos * kv_width;
    s.list->CopyBufferRegion(s.kcache.Get(), dst, s.dkr.Get(), 0, kv_bytes);
    s.list->CopyBufferRegion(s.vcache.Get(), dst, s.dv.Get(), 0, kv_bytes);

    transition(s, s.kcache.Get(), D3D12_RESOURCE_STATE_COPY_DEST,
               D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
    transition(s, s.vcache.Get(), D3D12_RESOURCE_STATE_COPY_DEST,
               D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);

    // 4. Attention over the whole visible window.
    transition(s, s.datt.Get(), D3D12_RESOURCE_STATE_COMMON,
               D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
    s.list->SetPipelineState(s.pso_attn.Get());
    ap->heads = static_cast<std::uint32_t>(heads);
    ap->kv_heads = static_cast<std::uint32_t>(kv_heads);
    ap->head_dim = static_cast<std::uint32_t>(head_dim);
    ap->context = static_cast<std::uint32_t>(s.kv_context);
    ap->first_pos = static_cast<std::uint32_t>(first_pos);
    ap->pos = static_cast<std::uint32_t>(pos);
    ap->scores_off = 0;
    ap->out_off = static_cast<std::uint32_t>(scores_floats);
    ap->inv_scale = 1.0f / std::sqrt(static_cast<float>(head_dim));
    ap->pad0 = ap->pad1 = ap->pad2 = 0.0f;
    s.list->SetComputeRootConstantBufferView(0, s.params->GetGPUVirtualAddress() +
                                                    kAttnParamOffset);
    s.list->SetComputeRootShaderResourceView(1, s.dqr->GetGPUVirtualAddress());
    s.list->SetComputeRootShaderResourceView(2, s.kcache->GetGPUVirtualAddress() +
                                                    layer * stride);
    s.list->SetComputeRootShaderResourceView(3, s.vcache->GetGPUVirtualAddress() +
                                                    layer * stride);
    s.list->SetComputeRootUnorderedAccessView(4, s.datt->GetGPUVirtualAddress());
    s.current_comp = Comp::Projections;
    // One 32-thread group per head, so the grid width is exactly `heads`.
    s.list->Dispatch(static_cast<UINT>(heads), 1, 1);

    // 5. Read back only the attention output region.
    transition(s, s.datt.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
               D3D12_RESOURCE_STATE_COPY_SOURCE);
    s.list->CopyBufferRegion(s.yread.Get(), 0, s.datt.Get(), scores_floats * sizeof(float),
                             q_bytes);
    // Return every scratch buffer to COMMON so the next call can assume that state.
    // Leaving them in UAV/SRV made the second position transition from a stale state,
    // which is an invalid barrier and removes the device.
    transition(s, s.datt.Get(), D3D12_RESOURCE_STATE_COPY_SOURCE,
               D3D12_RESOURCE_STATE_COMMON);
    transition(s, s.dqr.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
               D3D12_RESOURCE_STATE_COMMON);
    transition(s, s.dkr.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
               D3D12_RESOURCE_STATE_COMMON);
    s.list->Close();

    if (!execute_and_wait(s)) {
        std::fprintf(stderr, "attn: execute_and_wait failed (pos=%zu)\n", pos);
        return false;
    }

    void* mapped = nullptr;
    const D3D12_RANGE read_range{0, q_bytes};
    if (FAILED(s.yread->Map(0, &read_range, &mapped))) {
        std::fprintf(stderr, "attn: readback Map failed pos=%zu removed_reason=0x%08lx\n", pos,
                     static_cast<unsigned long>(s.device->GetDeviceRemovedReason()));
        return false;
    }
    std::memcpy(out, mapped, q_bytes);
    const D3D12_RANGE written{0, 0};
    s.yread->Unmap(0, &written);
    s.stats.dispatches += 3;
    return true;
}

// Appends one token's k and v to the device cache during prefill.
//
// Prefill computes its attention on the host, but decode reads the device cache, so the
// prompt positions have to land there too. Without this the device cache holds nothing
// but decoded positions and decode attends over a window starting at the prompt end.
// This is a pure copy - no dispatch - so it costs two CopyBufferRegion calls.
bool kv_cache_append_locked(State& s, std::size_t layer, std::size_t pos, const float* k,
                            const float* v, std::size_t kv_heads, std::size_t head_dim) {
    if (!s.kcache || layer >= s.kv_layers || pos >= s.kv_context) {
        return false;
    }
    if (s.kv_heads != kv_heads || s.kv_head_dim != head_dim) {
        return false;
    }
    const std::size_t kv_bytes = kv_heads * head_dim * sizeof(float);
    if (!reserve_scratch(s, kv_bytes * 2, kv_bytes * 2)) {
        return false;
    }
    std::memcpy(s.x_cpu, k, kv_bytes);
    std::memcpy(static_cast<std::uint8_t*>(s.x_cpu) + kv_bytes, v, kv_bytes);

    const std::size_t stride = s.kv_heads * s.kv_context * s.kv_head_dim * sizeof(float);
    const std::size_t dst = layer * stride + pos * kv_bytes;

    // Use async copy queue for KV cache append to overlap with compute
    s.copy_allocator->Reset();
    s.copy_list->Reset(s.copy_allocator.Get(), nullptr);
    transition(s, s.kcache.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
               D3D12_RESOURCE_STATE_COPY_DEST);
    transition(s, s.vcache.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
               D3D12_RESOURCE_STATE_COPY_DEST);
    s.copy_list->CopyBufferRegion(s.kcache.Get(), dst, s.xbuf.Get(), 0, kv_bytes);
    s.copy_list->CopyBufferRegion(s.vcache.Get(), dst, s.xbuf.Get(), kv_bytes, kv_bytes);
    transition(s, s.kcache.Get(), D3D12_RESOURCE_STATE_COPY_DEST,
               D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
    transition(s, s.vcache.Get(), D3D12_RESOURCE_STATE_COPY_DEST,
               D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
    s.copy_list->Close();

    // Submit to copy queue and wait on copy fence
    ID3D12CommandList* copy_lists[] = {s.copy_list.Get()};
    s.copy_queue->ExecuteCommandLists(1, copy_lists);
    
    const std::uint64_t copy_fence_value = ++s.copy_fence_value;
    if (FAILED(s.copy_queue->Signal(s.copy_fence.Get(), copy_fence_value))) {
        return false;
    }
    if (s.copy_fence->GetCompletedValue() < copy_fence_value) {
        if (FAILED(s.copy_fence->SetEventOnCompletion(copy_fence_value, s.copy_fence_event))) {
            return false;
        }
        WaitForSingleObject(s.copy_fence_event, INFINITE);
    }
    return true;
}

bool kv_cache_append(std::size_t layer, std::size_t pos, const float* k, const float* v,
                     std::size_t kv_heads, std::size_t head_dim) noexcept {
    State& s = state();
    std::lock_guard<std::mutex> lock(s.mutex);
    if (!init_locked(s)) {
        return false;
    }
    if (!kv_cache_append_locked(s, layer, pos, k, v, kv_heads, head_dim)) {
        ++s.stats.fallbacks;
        return false;
    }
    return true;
}

// Batched KV cache append for prefill: appends multiple layers' K/V in one submission.
// layers/pos/ks/vs arrays must have the same length (num_layers).
bool kv_cache_append_batched_locked(State& s,
                                    const std::size_t* layers, std::size_t num_layers,
                                    const std::size_t* positions,
                                    const float** ks, const float** vs,
                                    std::size_t kv_heads, std::size_t head_dim) {
    if (const char* trace = std::getenv("ZEN_D3D12_TRACE"); trace && trace[0] == '1') {
        std::printf("[d3d12] batched kv append: num_layers=%zu\n", num_layers);
    }
    if (!s.kcache || num_layers == 0) return false;
    if (s.kv_heads != kv_heads || s.kv_head_dim != head_dim) return false;

    const std::size_t kv_bytes = kv_heads * head_dim * sizeof(float);
    const std::size_t total_bytes = num_layers * kv_bytes * 2;
    if (!reserve_scratch(s, total_bytes, total_bytes)) return false;

    // Pack all K/V into staging buffer
    std::uint8_t* dst = static_cast<std::uint8_t*>(s.x_cpu);
    for (std::size_t i = 0; i < num_layers; ++i) {
        std::memcpy(dst, ks[i], kv_bytes);
        dst += kv_bytes;
    }
    for (std::size_t i = 0; i < num_layers; ++i) {
        std::memcpy(dst, vs[i], kv_bytes);
        dst += kv_bytes;
    }

    const std::size_t stride = s.kv_heads * s.kv_context * s.kv_head_dim * sizeof(float);

    // Use async copy queue for KV cache appends to overlap with compute
    s.copy_allocator->Reset();
    s.copy_list->Reset(s.copy_allocator.Get(), nullptr);
    transition(s, s.kcache.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
               D3D12_RESOURCE_STATE_COPY_DEST);
    transition(s, s.vcache.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
               D3D12_RESOURCE_STATE_COPY_DEST);

    std::uint8_t* src_k = static_cast<std::uint8_t*>(s.x_cpu);
    std::uint8_t* src_v = src_k + num_layers * kv_bytes;
    for (std::size_t i = 0; i < num_layers; ++i) {
        const std::size_t layer = layers[i];
        const std::size_t pos = positions[i];
        const std::size_t dst_offset = layer * s.kv_heads * s.kv_context * s.kv_head_dim * sizeof(float) + positions[i] * kv_bytes;
        s.copy_list->CopyBufferRegion(s.kcache.Get(), dst_offset, s.xbuf.Get(), src_k - static_cast<std::uint8_t*>(s.x_cpu), kv_bytes);
        s.copy_list->CopyBufferRegion(s.vcache.Get(), dst_offset, s.xbuf.Get(), src_v - static_cast<std::uint8_t*>(s.x_cpu), kv_bytes);
        src_k += kv_bytes;
        src_v += kv_bytes;
    }

    transition(s, s.kcache.Get(), D3D12_RESOURCE_STATE_COPY_DEST,
               D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
    transition(s, s.vcache.Get(), D3D12_RESOURCE_STATE_COPY_DEST,
               D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
    s.copy_list->Close();

    // Submit to copy queue and wait on copy fence
    ID3D12CommandList* copy_lists[] = {s.copy_list.Get()};
    s.copy_queue->ExecuteCommandLists(1, copy_lists);
    
    const std::uint64_t copy_fence_value = ++s.copy_fence_value;
    if (FAILED(s.copy_queue->Signal(s.copy_fence.Get(), copy_fence_value))) {
        return false;
    }
    if (s.copy_fence->GetCompletedValue() < copy_fence_value) {
        if (FAILED(s.copy_fence->SetEventOnCompletion(copy_fence_value, s.copy_fence_event))) {
            return false;
        }
        WaitForSingleObject(s.copy_fence_event, INFINITE);
    }
    return true;
}

bool kv_cache_append_batched(const std::size_t* layers, std::size_t num_layers,
                             const std::size_t* positions,
                             const float** ks, const float** vs,
                             std::size_t kv_heads, std::size_t head_dim) noexcept {
    State& s = state();
    std::lock_guard<std::mutex> lock(s.mutex);
    if (!init_locked(s)) return false;
    if (!kv_cache_append_batched_locked(s, layers, num_layers, positions, ks, vs, kv_heads, head_dim)) {
        ++s.stats.fallbacks;
        return false;
    }
    return true;
}

bool attention_block(const float* q, const float* k, const float* v, const float* cos,
                     const float* sin, float* out, std::size_t heads, std::size_t kv_heads,
                     std::size_t head_dim, std::size_t pairs, std::size_t layer,
                     std::size_t pos, std::size_t first_pos) noexcept {
    State& s = state();
    std::lock_guard<std::mutex> lock(s.mutex);
    if (!init_locked(s)) {
        return false;
    }
    if (!attn_block_locked(s, q, k, v, cos, sin, heads, kv_heads, head_dim, pairs, layer, pos,
                           first_pos, out)) {
        ++s.stats.fallbacks;
        return false;
    }
    return true;
}

bool rms_norm_locked(State& s, const float* x, const float* weight, float* y, std::size_t rows,
                     std::size_t columns, float epsilon) {
    if (rows == 0 || columns == 0) {
        return false;
    }
    const std::size_t bytes = rows * columns * sizeof(float);
    if (!reserve_scratch(s, bytes, bytes)) {
        return false;
    }
    std::memcpy(s.x_cpu, x, bytes);

    const std::size_t weight_bytes = columns * sizeof(float);
    if (weight_bytes > s.w_cap) {
        s.wbuf.Reset();
        s.wbuf = create_buffer(s.device.Get(), weight_bytes, upload_heap_type(),
                               upload_heap_state());
        if (!s.wbuf || FAILED(s.wbuf->Map(0, nullptr, &s.w_cpu))) {
            s.w_cap = 0;
            return false;
        }
        s.w_cap = weight_bytes;
    }
    std::memcpy(s.w_cpu, weight, weight_bytes);

    auto* params = reinterpret_cast<RmsParams*>(static_cast<std::uint8_t*>(s.params_cpu) + 256);
    params->count = static_cast<std::uint32_t>(columns);
    params->rows = static_cast<std::uint32_t>(rows);
    params->epsilon = epsilon;
    params->pad = 0;

    s.allocator->Reset();
    s.list->Reset(s.allocator.Get(), s.pso_rms.Get());
    s.list->SetComputeRootSignature(s.root.Get());
    s.list->SetComputeRootConstantBufferView(0, s.params->GetGPUVirtualAddress() + 256);
    s.list->SetComputeRootShaderResourceView(1, s.xbuf->GetGPUVirtualAddress());
    s.list->SetComputeRootShaderResourceView(2, s.wbuf->GetGPUVirtualAddress());
    s.list->SetComputeRootUnorderedAccessView(4, s.ybuf->GetGPUVirtualAddress());

    // One workgroup per row, exactly as rmsnorm.hlsl assumes. Without this call the
    // kernel never ran and the readback returned the zero-initialised buffer.
    s.current_comp = Comp::Norms;
    s.list->Dispatch(static_cast<UINT>(rows), 1, 1);

    D3D12_RESOURCE_BARRIER barrier{};
    barrier.Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
    barrier.Transition.pResource = s.ybuf.Get();
    barrier.Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
    barrier.Transition.StateBefore = D3D12_RESOURCE_STATE_UNORDERED_ACCESS;
    barrier.Transition.StateAfter = D3D12_RESOURCE_STATE_COPY_SOURCE;
    s.list->ResourceBarrier(1, &barrier);
    s.list->CopyBufferRegion(s.yread.Get(), 0, s.ybuf.Get(), 0, bytes);
    barrier.Transition.StateBefore = D3D12_RESOURCE_STATE_COPY_SOURCE;
    barrier.Transition.StateAfter = D3D12_RESOURCE_STATE_UNORDERED_ACCESS;
    s.list->ResourceBarrier(1, &barrier);
    s.list->Close();

    if (!execute_and_wait(s)) {
        return false;
    }

    void* mapped = nullptr;
    const D3D12_RANGE read_range{0, bytes};
    if (FAILED(s.yread->Map(0, &read_range, &mapped))) {
        return false;
    }
    std::memcpy(y, mapped, bytes);
    const D3D12_RANGE written{0, 0};
    s.yread->Unmap(0, &written);
    ++s.stats.dispatches;
    return true;
}

bool rms_norm(const float* x, const float* weight, float* y, std::size_t rows,
              std::size_t columns, float epsilon) noexcept {
    State& s = state();
    std::lock_guard<std::mutex> lock(s.mutex);
    if (!init_locked(s)) {
        return false;
    }
    if (!rms_norm_locked(s, x, weight, y, rows, columns, epsilon)) {
        ++s.stats.fallbacks;
        return false;
    }
    return true;
}

bool gemv_q8_0_ffn(const std::uint8_t* gate, const std::uint8_t* up, const std::uint8_t* down,
                   const float* x, float* y, std::size_t ffn_rows, std::size_t columns,
                   std::size_t out_rows) noexcept {
    State& s = state();
    std::lock_guard<std::mutex> lock(s.mutex);
    if (!init_locked(s)) {
        return false;
    }
    if (!gemv_ffn_locked(s, gate, up, down, x, y, ffn_rows, columns, out_rows)) {
        ++s.stats.fallbacks;
        return false;
    }
    return true;
}

bool gemv_q8_0(const std::uint8_t* weights, const float* x, float* y, std::size_t rows,
               std::size_t columns) noexcept {
    if (rows * columns < kMinElements) {
        return false;
    }
    State& s = state();
    std::lock_guard<std::mutex> lock(s.mutex);
    if (!init_locked(s)) {
        return false;
    }
    if (!gemv_locked(s, weights, x, y, rows, columns)) {
        ++s.stats.fallbacks;
        return false;
    }
    return true;
}

bool gemm_q8_0(const std::uint8_t* weights, const float* input, float* output, std::size_t tokens,
               std::size_t rows, std::size_t columns) noexcept {
    if (tokens * rows * columns < kMinElements) {
        return false;
    }
    State& s = state();
    std::lock_guard<std::mutex> lock(s.mutex);
    if (!init_locked(s)) {
        return false;
    }
    if (!gemm_opted_in()) {
        // Prefill still runs on the CPU, but it is the right place to pay the
        // one-off residency cost: otherwise the first decoded token absorbs it.
        lookup_weights(s, weights, rows, columns);
        return false;
    }
    if (!gemm_locked(s, weights, input, output, tokens, rows, columns)) {
        ++s.stats.fallbacks;
        return false;
    }
    return true;
}

// ---------------------------------------------------------------------------
// Fused FFN half of a transformer layer.
//
// One command list performs: attn_output matvec, residual add, FFN RMSNorm,
// gate|up matvecs, SiLU multiply, down matvec, residual add, then one readback.
// That replaces a matvec submission, a host-side add, a host-side norm, an FFN
// submission and another host-side add.
//
// Two device buffers alternate roles so that no dispatch both reads and writes the
// same resource: a dispatch that consumes a buffer needs it in
// NON_PIXEL_SHADER_RESOURCE, while the one it writes to stays UNORDERED_ACCESS.
// A and B swap roles at every step, and each swap is an explicit full-resource
// transition between dispatches.
namespace {

bool ensure_upload(ComPtr<ID3D12Resource>& buf, void*& cpu, std::size_t& cap,
                   ID3D12Device* device, std::size_t bytes) {
    if (buf && bytes <= cap) {
        return true;
    }
    buf.Reset();
    buf = create_buffer(device, bytes, upload_heap_type(), upload_heap_state());
    if (!buf || FAILED(buf->Map(0, nullptr, &cpu))) {
        cap = 0;
        return false;
    }
    cap = bytes;
    return true;
}

}  // namespace

bool ffn_residual_fused_locked(State& s, const std::uint8_t* attn_out_w, const std::uint8_t* gate_w,
                               const std::uint8_t* up_w, const std::uint8_t* down_w,
                               const float* norm_weight, const float* x, const float* attn_out,
                               float* out, std::size_t hidden, std::size_t attn_width,
                               std::size_t ffn_rows, float epsilon) {
    if (!hidden || !attn_width || !ffn_rows) {
        return false;
    }
    if (attn_width % kElemsPerBlock || hidden % kElemsPerBlock || ffn_rows % kElemsPerBlock) {
        return false;
    }

    // Resolve every tensor first so a residency eviction cannot invalidate a buffer
    // that an already-recorded dispatch is still reading.
    ComPtr<ID3D12Resource> ao_q, g_q, u_q, d_q;
    std::uint64_t ao_s = 0, g_s = 0, u_s = 0, d_s = 0;
    if (WeightEntry* e = lookup_weights(s, attn_out_w, hidden, attn_width)) {
        ao_q = e->quants;
        ao_s = e->scales_va;
    } else {
        return false;
    }
    if (WeightEntry* e = lookup_weights(s, gate_w, ffn_rows, hidden)) {
        g_q = e->quants;
        g_s = e->scales_va;
    } else {
        return false;
    }
    if (WeightEntry* e = lookup_weights(s, up_w, ffn_rows, hidden)) {
        u_q = e->quants;
        u_s = e->scales_va;
    } else {
        return false;
    }
    if (WeightEntry* e = lookup_weights(s, down_w, hidden, ffn_rows)) {
        d_q = e->quants;
        d_s = e->scales_va;
    } else {
        return false;
    }

    constexpr std::uint64_t kAlign = 256u;
    auto span = [](std::uint64_t bytes) { return (bytes + kAlign - 1) & ~(kAlign - 1); };
    const std::uint64_t hidden_span = span(hidden * sizeof(float));
    const std::uint64_t ffn_span = span(ffn_rows * sizeof(float));

    // A (ybuf): attn projection, normed activation, SiLU result, final output.
    const std::uint64_t a_t0 = 0;
    const std::uint64_t a_h2 = hidden_span;
    const std::uint64_t a_f = a_h2 + hidden_span;
    const std::uint64_t a_fin = a_f + ffn_span;
    const std::uint64_t a_total = a_fin + hidden_span;

    // B (fbuf): residual base, gate, up, down projection.
    const std::uint64_t b_h1 = 0;
    const std::uint64_t b_g = hidden_span;
    const std::uint64_t b_u = b_g + ffn_span;
    const std::uint64_t b_d = b_u + ffn_span;
    const std::uint64_t b_total = b_d + hidden_span;

    if (!reserve_scratch(s, attn_width * sizeof(float), a_total)) {
        return false;
    }
    if (!s.fbuf || b_total > s.f_cap) {
        s.fbuf.Reset();
        s.fbuf = create_buffer(s.device.Get(), b_total, D3D12_HEAP_TYPE_DEFAULT,
                               D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
                               D3D12_RESOURCE_FLAG_ALLOW_UNORDERED_ACCESS);
        if (!s.fbuf) {
            s.f_cap = 0;
            return false;
        }
        s.f_cap = static_cast<std::size_t>(b_total);
    }

    const std::size_t hidden_bytes = hidden * sizeof(float);
    if (!ensure_upload(s.wbuf, s.w_cpu, s.w_cap, s.device.Get(), hidden_bytes) ||
        !ensure_upload(s.nbuf, s.n_cpu, s.n_cap, s.device.Get(), hidden_bytes)) {
        return false;
    }
    std::memcpy(s.x_cpu, attn_out, attn_width * sizeof(float));
    std::memcpy(s.w_cpu, x, hidden_bytes);
    std::memcpy(s.n_cpu, norm_weight, hidden_bytes);

    constexpr std::uint64_t kParamOffset = 512;
    const std::uint64_t addn0 = 512 + 256 * kMaxBatch;
    const std::uint64_t addn1 = addn0 + 256;
    auto* base = static_cast<std::uint8_t*>(s.params_cpu);
    auto write_gemv = [&](std::uint64_t slot, std::size_t rows, std::size_t cols) {
        auto* params = reinterpret_cast<GemvParams*>(base + slot);
        params->rows = static_cast<std::uint32_t>(rows);
        params->blocks_per_row = static_cast<std::uint32_t>(cols / kElemsPerBlock);
        params->rows_per_group = kRowsPerGroup;
        params->reserved = 0;
    };
    auto write_addn = [&](std::uint64_t slot, std::size_t count) {
        auto* params = reinterpret_cast<AddnParams*>(base + slot);
        params->count = static_cast<std::uint32_t>(count);
        params->pad0 = params->pad1 = params->pad2 = 0;
    };

    write_gemv(0, hidden, attn_width);
    write_gemv(kParamOffset, ffn_rows, hidden);
    write_gemv(kParamOffset + 256, ffn_rows, hidden);
    write_gemv(kParamOffset + 768, hidden, ffn_rows);
    write_addn(addn0, hidden);
    write_addn(addn1, hidden);
    auto* rms = reinterpret_cast<RmsParams*>(base + 256);
    rms->count = static_cast<std::uint32_t>(hidden);
    rms->rows = 1;
    rms->epsilon = epsilon;
    rms->pad = 0;
    auto* silu = reinterpret_cast<SiluParams*>(base + kParamOffset + 512);
    silu->count = static_cast<std::uint32_t>(ffn_rows);
    silu->pad0 = silu->pad1 = silu->pad2 = 0;

    const std::uint64_t params_base = s.params->GetGPUVirtualAddress();
    const std::uint64_t a_base = s.ybuf->GetGPUVirtualAddress();
    const std::uint64_t b_base = s.fbuf->GetGPUVirtualAddress();

    const UINT attn_groups = static_cast<UINT>((hidden + kRowsPerGroup - 1) / kRowsPerGroup);
    const UINT ffn_groups = static_cast<UINT>((ffn_rows + kRowsPerGroup - 1) / kRowsPerGroup);
    const UINT down_groups = static_cast<UINT>((hidden + kRowsPerGroup - 1) / kRowsPerGroup);
    const UINT silu_groups = static_cast<UINT>((ffn_rows + 255) / 256);

    s.allocator->Reset();
    s.list->Reset(s.allocator.Get(), s.pso_gemv.Get());
    s.list->SetComputeRootSignature(s.root.Get());
    // Stamp 0 brackets the whole 8-dispatch run so the trace can tell real device
    // work from fence latency; stamp 1 closes before the readback copy.
    if (s.trace) {
        s.list->EndQuery(s.ts_heap.Get(), D3D12_QUERY_TYPE_TIMESTAMP, 0);
    }

    // 1. attn_output matvec: A.t0 = W @ att
    s.list->SetComputeRootConstantBufferView(0, params_base);
    s.list->SetComputeRootShaderResourceView(1, ao_q->GetGPUVirtualAddress());
    s.list->SetComputeRootShaderResourceView(2, ao_s);
    s.list->SetComputeRootShaderResourceView(3, s.xbuf->GetGPUVirtualAddress());
    s.list->SetComputeRootUnorderedAccessView(4, a_base + a_t0);
    s.list->Dispatch(attn_groups, 1, 1);

    // 2. residual: B.h1 = A.t0 + x  (addn reads A.t0, so A becomes an SRV)
    transition(s, s.ybuf.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
               D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
    s.list->SetPipelineState(s.pso_addn.Get());
    s.list->SetComputeRootConstantBufferView(0, params_base + addn0);
    s.list->SetComputeRootShaderResourceView(1, a_base + a_t0);
    s.list->SetComputeRootShaderResourceView(2, s.wbuf->GetGPUVirtualAddress());
    s.list->SetComputeRootUnorderedAccessView(4, b_base + b_h1);
    s.list->Dispatch(static_cast<UINT>((hidden + 255) / 256), 1, 1);

    // 3. FFN norm: A.h2 = rmsnorm(B.h1) * w  (B becomes the SRV, A the writer)
    transition(s, s.fbuf.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
               D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
    transition(s, s.ybuf.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
               D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
    s.list->SetPipelineState(s.pso_rms.Get());
    s.list->SetComputeRootConstantBufferView(0, params_base + 256);
    s.list->SetComputeRootShaderResourceView(1, b_base + b_h1);
    s.list->SetComputeRootShaderResourceView(2, s.nbuf->GetGPUVirtualAddress());
    s.list->SetComputeRootUnorderedAccessView(4, a_base + a_h2);
    s.list->Dispatch(1, 1, 1);

    // 4/5. gate and up matvecs from the normed activation into B.
    transition(s, s.ybuf.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
               D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
    transition(s, s.fbuf.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
               D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
    s.list->SetPipelineState(s.pso_gemv.Get());
    s.list->SetComputeRootConstantBufferView(0, params_base + kParamOffset);
    s.list->SetComputeRootShaderResourceView(1, g_q->GetGPUVirtualAddress());
    s.list->SetComputeRootShaderResourceView(2, g_s);
    s.list->SetComputeRootShaderResourceView(3, a_base + a_h2);
    s.list->SetComputeRootUnorderedAccessView(4, b_base + b_g);
    s.list->Dispatch(ffn_groups, 1, 1);

    s.list->SetComputeRootConstantBufferView(0, params_base + kParamOffset + 256);
    s.list->SetComputeRootShaderResourceView(1, u_q->GetGPUVirtualAddress());
    s.list->SetComputeRootShaderResourceView(2, u_s);
    s.list->SetComputeRootUnorderedAccessView(4, b_base + b_u);
    s.list->Dispatch(ffn_groups, 1, 1);

    // 6. SiLU(gate)*up into A.f  (B becomes the SRV again)
    transition(s, s.fbuf.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
               D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
    transition(s, s.ybuf.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
               D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
    s.list->SetPipelineState(s.pso_silu.Get());
    s.list->SetComputeRootConstantBufferView(0, params_base + kParamOffset + 512);
    s.list->SetComputeRootShaderResourceView(1, b_base + b_g);
    s.list->SetComputeRootShaderResourceView(2, b_base + b_u);
    s.list->SetComputeRootUnorderedAccessView(4, a_base + a_f);
    s.list->Dispatch(silu_groups, 1, 1);

    // 7. down matvec: B.d = W_down @ A.f
    transition(s, s.ybuf.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
               D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
    transition(s, s.fbuf.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
               D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
    s.list->SetPipelineState(s.pso_gemv.Get());
    s.list->SetComputeRootConstantBufferView(0, params_base + kParamOffset + 768);
    s.list->SetComputeRootShaderResourceView(1, d_q->GetGPUVirtualAddress());
    s.list->SetComputeRootShaderResourceView(2, d_s);
    s.list->SetComputeRootShaderResourceView(3, a_base + a_f);
    s.list->SetComputeRootUnorderedAccessView(4, b_base + b_d);
    s.list->Dispatch(down_groups, 1, 1);

    // 8. final residual: A.fin = B.h1 + B.d
    transition(s, s.fbuf.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
               D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
    transition(s, s.ybuf.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
               D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
    s.list->SetPipelineState(s.pso_addn.Get());
    s.list->SetComputeRootConstantBufferView(0, params_base + addn1);
    s.current_comp = Comp::FfnFused;
    s.list->SetComputeRootShaderResourceView(1, b_base + b_d);
    s.list->SetComputeRootShaderResourceView(2, b_base + b_h1);
    s.list->SetComputeRootUnorderedAccessView(4, a_base + a_fin);
    s.list->Dispatch(static_cast<UINT>((hidden + 255) / 256), 1, 1);

    if (s.trace) {
        s.list->EndQuery(s.ts_heap.Get(), D3D12_QUERY_TYPE_TIMESTAMP, 1);
    }
    transition(s, s.ybuf.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
               D3D12_RESOURCE_STATE_COPY_SOURCE);
    s.list->CopyBufferRegion(s.yread.Get(), 0, s.ybuf.Get(), a_fin, hidden_bytes);
    transition(s, s.ybuf.Get(), D3D12_RESOURCE_STATE_COPY_SOURCE,
               D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
    if (s.trace) {
        s.list->EndQuery(s.ts_heap.Get(), D3D12_QUERY_TYPE_TIMESTAMP, 2);
        s.list->ResolveQueryData(s.ts_heap.Get(), D3D12_QUERY_TYPE_TIMESTAMP, 0, 3,
                                 s.ts_read.Get(), 0);
    }
    s.list->Close();

    if (!execute_and_wait(s)) {
        return false;
    }

    void* mapped = nullptr;
    const D3D12_RANGE read_range{0, hidden_bytes};
    if (FAILED(s.yread->Map(0, &read_range, &mapped))) {
        return false;
    }
    {
        std::uint64_t dev = 0;
        accumulate_gpu_us(s, dev, 0, 1);
        note_dev(s, Comp::FfnFused, dev);
    }
    std::memcpy(out, mapped, hidden_bytes);
    const D3D12_RANGE written{0, 0};
    s.yread->Unmap(0, &written);
    s.stats.dispatches += 8;
    ++s.stats.batches;
    return true;
}

// ---------------------------------------------------------------------------
// Pipelined layer decode: GPU-to-GPU, no readback between layers.
// Caller chains these: layer 0 input from host, layers 1-N input from prev output,
// final layer reads back to host. Returns the command list for batch submission.
bool layer_decode_gpu(State& s, const std::uint8_t* q_w, const std::uint8_t* k_w,
                      const std::uint8_t* v_w, const std::uint8_t* o_w,
                      const std::uint8_t* gate_w, const std::uint8_t* up_w,
                      const std::uint8_t* down_w, const float* attn_norm_w,
                      const float* ffn_norm_w, const float* cos, const float* sin,
                      std::size_t pairs, ID3D12Resource* input_buf, // GPU buffer
                      ID3D12Resource* output_buf,  // GPU buffer
                      std::size_t layer, std::size_t pos, std::size_t first_pos,
                      std::size_t hidden, std::size_t heads, std::size_t kv_heads,
                      std::size_t head_dim, std::size_t ffn_rows, float epsilon) {
    const std::size_t q_width = heads * head_dim;
    const std::size_t kv_width = kv_heads * head_dim;
    if (!hidden || !q_width || !kv_width || !ffn_rows || !pairs) {
        return false;
    }
    if (hidden % kElemsPerBlock || ffn_rows % kElemsPerBlock || q_width % kElemsPerBlock ||
        kv_width % kElemsPerBlock) {
        return false;
    }
    if (!s.kcache || layer >= s.kv_layers || pos >= s.kv_context || s.kv_heads != kv_heads ||
        s.kv_head_dim != head_dim) {
        return false;
    }

    // Resolve weights (same as layer_decode)
    ComPtr<ID3D12Resource> qq, kq, vq, oq, gq, uq, dq_;
    std::uint64_t qs = 0, ks = 0, vs = 0, os_ = 0, gs = 0, us = 0, ds = 0;
    auto bind = [&](const std::uint8_t* w, std::size_t rows, std::size_t cols,
                    ComPtr<ID3D12Resource>& q, std::uint64_t& sc) {
        WeightEntry* e = lookup_weights(s, w, rows, cols);
        if (!e) return false;
        q = e->quants;
        sc = e->scales_va;
        return true;
    };
    if (!bind(q_w, q_width, hidden, qq, qs) || !bind(k_w, kv_width, hidden, kq, ks) ||
        !bind(v_w, kv_width, hidden, vq, vs) || !bind(o_w, hidden, q_width, oq, os_) ||
        !bind(gate_w, ffn_rows, hidden, gq, gs) || !bind(up_w, ffn_rows, hidden, uq, us) ||
        !bind(down_w, hidden, ffn_rows, dq_, ds)) {
        return false;
    }

    constexpr std::uint64_t kAlign = 256u;
    auto span = [](std::uint64_t bytes) { return (bytes + kAlign - 1) & ~(kAlign - 1); };
    const std::uint64_t hidden_span = span(hidden * sizeof(float));
    const std::uint64_t ffn_span = span(ffn_rows * sizeof(float));
    const std::uint64_t q_span = span(q_width * sizeof(float));
    const std::uint64_t kv_span = span(kv_width * sizeof(float));

    const std::uint64_t a_h = 0;
    const std::uint64_t a_qr = a_h + hidden_span;
    const std::uint64_t a_kr = a_qr + q_span;
    const std::uint64_t a_t0 = a_kr + kv_span;
    const std::uint64_t a_h2 = a_t0 + hidden_span;
    const std::uint64_t a_f = a_h2 + hidden_span;
    const std::uint64_t a_fin = a_f + ffn_span;
    const std::uint64_t a_total = a_fin + hidden_span;

    const std::uint64_t b_q = 0;
    const std::uint64_t b_k = b_q + q_span;
    const std::uint64_t b_v = b_k + kv_span;
    const std::uint64_t b_g = b_v + kv_span;
    const std::uint64_t b_u = b_g + ffn_span;
    const std::uint64_t b_d = b_u + ffn_span;
    const std::uint64_t b_total = b_d + hidden_span;

    const std::size_t hidden_bytes = hidden * sizeof(float);
    const std::size_t kv_bytes = kv_width * sizeof(float);
    const std::size_t tab_bytes = pairs * sizeof(float);
    const std::size_t scores_floats = heads * s.kv_context;
    const std::size_t att_floats = heads * head_dim;
    const std::size_t datt_bytes = (scores_floats + att_floats) * sizeof(float);

    if (!reserve_scratch(s, hidden_bytes, a_total)) return false;
    if (!s.fbuf || b_total > s.f_cap) {
        s.fbuf.Reset();
        s.fbuf = create_buffer(s.device.Get(), b_total, D3D12_HEAP_TYPE_DEFAULT,
                               D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
                               D3D12_RESOURCE_FLAG_ALLOW_UNORDERED_ACCESS);
        if (!s.fbuf) { s.f_cap = 0; return false; }
        s.f_cap = static_cast<std::size_t>(b_total);
    }
    if (!s.hbuf || hidden_span > s.h_cap) {
        s.hbuf.Reset();
        s.hbuf = create_buffer(s.device.Get(), hidden_span, D3D12_HEAP_TYPE_DEFAULT,
                               D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
                               D3D12_RESOURCE_FLAG_ALLOW_UNORDERED_ACCESS);
        if (!s.hbuf) { s.h_cap = 0; return false; }
        s.h_cap = static_cast<std::size_t>(hidden_span);
    }
    if (!attn_upload(s, s.dcos, s.dcos_cpu, s.dcos_cap, tab_bytes) ||
        !attn_upload(s, s.dsin, s.dsin_cpu, s.dsin_cap, tab_bytes) ||
        !attn_device(s, s.datt, s.datt_cap, datt_bytes)) {
        return false;
    }

    // Copy input from GPU buffer to xbuf (instead of host memcpy)
    s.allocator->Reset();
    s.list->Reset(s.allocator.Get(), nullptr);
    transition(s, input_buf, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
               D3D12_RESOURCE_STATE_COPY_SOURCE);
    transition(s, s.xbuf.Get(), D3D12_RESOURCE_STATE_GENERIC_READ,
               D3D12_RESOURCE_STATE_COPY_DEST);
    s.list->CopyBufferRegion(s.xbuf.Get(), 0, input_buf, 0, hidden_bytes);
    transition(s, s.xbuf.Get(), D3D12_RESOURCE_STATE_COPY_DEST,
               D3D12_RESOURCE_STATE_GENERIC_READ);
    // Upload cos/sin and norm weights (still from host)
    std::memcpy(s.dcos_cpu, cos, tab_bytes);
    std::memcpy(s.dsin_cpu, sin, tab_bytes);
    // Upload norm weights to upload buffers
    if (!ensure_upload(s.wbuf, s.w_cpu, s.w_cap, s.device.Get(), hidden_bytes) ||
        !ensure_upload(s.nbuf, s.n_cpu, s.n_cap, s.device.Get(), hidden_bytes)) {
        return false;
    }
    std::memcpy(s.w_cpu, ffn_norm_w, hidden_bytes);
    std::memcpy(s.n_cpu, attn_norm_w, hidden_bytes);

    // ... rest of layer_decode setup (params, dispatch recording)
    // [Same parameter setup as layer_decode - abbreviated for brevity]
    // This would duplicate the param setup and dispatch recording from layer_decode
    // but write final output to output_buf instead of ybuf, and NOT read back.
    // For now, return false to indicate not fully implemented.
    return false;
}

// ---------------------------------------------------------------------------
// Pipelined multi-layer decode: records all layers into command lists, submits
// them as a batch, then waits once. Keeps intermediate activations in VRAM.
// GPU-to-GPU for intermediate layers, only final output read back to host.
// Returns false on any failure (caller falls back to per-layer path).
bool layer_decode_pipeline(const LayerDecodeParams* layers, std::size_t num_layers,
                           const float* input, float* output,
                           std::size_t hidden, std::size_t heads, std::size_t kv_heads,
                           std::size_t head_dim, std::size_t ffn_rows, float epsilon) noexcept {
    if (num_layers == 0 || num_layers > 64) return false;
    
    State& s = state();
    std::lock_guard<std::mutex> lock(s.mutex);
    if (!init_locked(s)) return false;

    const std::size_t q_width = heads * head_dim;
    const std::size_t kv_width = kv_heads * head_dim;
    if (!hidden || !q_width || !kv_width || !ffn_rows) return false;
    if (hidden % kElemsPerBlock || ffn_rows % kElemsPerBlock || q_width % kElemsPerBlock ||
        kv_width % kElemsPerBlock) return false;
    if (!s.kcache || layers[0].layer >= s.kv_layers || layers[0].pos >= s.kv_context ||
        s.kv_heads != kv_heads || s.kv_head_dim != head_dim) {
        if (const char* trace = std::getenv("ZEN_D3D12_TRACE"); trace && trace[0] == '1') {
            std::printf("[d3d12] pipeline: early fail - kcache=%p layer0.layer=%zu kv_layers=%zu pos=%zu kv_ctx=%zu kv_heads=%zu/%zu head_dim=%zu/%zu\n",
                (void*)s.kcache.Get(), layers[0].layer, s.kv_layers, layers[0].pos, s.kv_context,
                s.kv_heads, kv_heads, s.kv_head_dim, head_dim);
        }
        return false;
    }

    // Verify all layers have consistent parameters
    for (std::size_t i = 1; i < num_layers; ++i) {
        if (layers[i].layer != layers[0].layer + i ||
            layers[i].pos != layers[0].pos ||
            layers[i].first_pos != layers[0].first_pos) {
            if (const char* trace = std::getenv("ZEN_D3D12_TRACE"); trace && trace[0] == '1') {
                std::printf("[d3d12] pipeline: param mismatch at layer %zu: layer=%zu pos=%zu first_pos=%zu vs layer0 layer=%zu pos=%zu first_pos=%zu\n",
                    i, layers[i].layer, layers[i].pos, layers[i].first_pos,
                    layers[0].layer, layers[0].pos, layers[0].first_pos);
            }
            return false;
        }
    }

    if (const char* trace = std::getenv("ZEN_D3D12_TRACE"); trace && trace[0] == '1') {
        std::printf("[d3d12] pipeline: START num_layers=%zu hidden=%zu heads=%zu kv_heads=%zu head_dim=%zu ffn_rows=%zu\n",
            num_layers, hidden, heads, kv_heads, head_dim, ffn_rows);
    }

    // Resolve all weights upfront (prevents residency eviction during recording)
    struct LayerWeights {
        ComPtr<ID3D12Resource> qq, kq, vq, oq, gq, uq, dq_;
        std::uint64_t qs=0, ks=0, vs=0, os_=0, gs=0, us=0, ds=0;
    };
    std::vector<LayerWeights> lw(num_layers);
    auto bind = [&](const std::uint8_t* w, std::size_t rows, std::size_t cols,
                    ComPtr<ID3D12Resource>& q, std::uint64_t& sc) {
        WeightEntry* e = lookup_weights(s, w, rows, cols);
        if (!e) return false;
        q = e->quants;
        sc = e->scales_va;
        return true;
    };
    for (std::size_t li = 0; li < num_layers; ++li) {
        const auto& p = layers[li];
        if (!bind(p.q_w, q_width, hidden, lw[li].qq, lw[li].qs) ||
            !bind(p.k_w, kv_width, hidden, lw[li].kq, lw[li].ks) ||
            !bind(p.v_w, kv_width, hidden, lw[li].vq, lw[li].vs) ||
            !bind(p.o_w, hidden, q_width, lw[li].oq, lw[li].os_) ||
            !bind(p.gate_w, ffn_rows, hidden, lw[li].gq, lw[li].gs) ||
            !bind(p.up_w, ffn_rows, hidden, lw[li].uq, lw[li].us) ||
            !bind(p.down_w, hidden, ffn_rows, lw[li].dq_, lw[li].ds)) {
            if (const char* trace = std::getenv("ZEN_D3D12_TRACE"); trace && trace[0] == '1') {
                std::printf("[d3d12] pipeline: bind failed at layer %zu\n", li);
            }
            return false;
        }
    }

    constexpr std::uint64_t kAlign = 256u;
    auto span = [](std::uint64_t bytes) { return (bytes + kAlign - 1) & ~(kAlign - 1); };
    const std::uint64_t hidden_span = span(hidden * sizeof(float));
    const std::uint64_t ffn_span = span(ffn_rows * sizeof(float));
    const std::uint64_t q_span = span(q_width * sizeof(float));
    const std::uint64_t kv_span = span(kv_width * sizeof(float));
    const std::size_t hidden_bytes = hidden * sizeof(float);
    const std::size_t kv_bytes = kv_width * sizeof(float);
    const std::size_t tab_bytes = layers[0].pairs * sizeof(float);
    const std::size_t scores_floats = heads * s.kv_context;
    const std::size_t att_floats = heads * head_dim;
    const std::size_t datt_bytes = (scores_floats + att_floats) * sizeof(float);

    // Arena A: h, qr, kr, t0, h2, f, fin
    const std::uint64_t a_h = 0;
    const std::uint64_t a_qr = a_h + hidden_span;
    const std::uint64_t a_kr = a_qr + q_span;
    const std::uint64_t a_t0 = a_kr + kv_span;
    const std::uint64_t a_h2 = a_t0 + hidden_span;
    const std::uint64_t a_f = a_h2 + hidden_span;
    const std::uint64_t a_fin = a_f + ffn_span;
    const std::uint64_t a_total = a_fin + hidden_span;

    // Arena B: q, k, v, g, u, d
    const std::uint64_t b_q = 0;
    const std::uint64_t b_k = b_q + q_span;
    const std::uint64_t b_v = b_k + kv_span;
    const std::uint64_t b_g = b_v + kv_span;
    const std::uint64_t b_u = b_g + ffn_span;
    const std::uint64_t b_d = b_u + ffn_span;
    const std::uint64_t b_total = b_d + hidden_span;

    // Arena C: h1 (residual base)
    if (!s.hbuf || hidden_span > s.h_cap) {
        s.hbuf.Reset();
        s.hbuf = create_buffer(s.device.Get(), hidden_span, D3D12_HEAP_TYPE_DEFAULT,
                               D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
                               D3D12_RESOURCE_FLAG_ALLOW_UNORDERED_ACCESS);
        if (!s.hbuf) { s.h_cap = 0; return false; }
        s.h_cap = static_cast<std::size_t>(hidden_span);
    }
    if (!s.fbuf || b_total > s.f_cap) {
        s.fbuf.Reset();
        s.fbuf = create_buffer(s.device.Get(), b_total, D3D12_HEAP_TYPE_DEFAULT,
                               D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
                               D3D12_RESOURCE_FLAG_ALLOW_UNORDERED_ACCESS);
        if (!s.fbuf) { s.f_cap = 0; return false; }
        s.f_cap = static_cast<std::size_t>(b_total);
    }
    if (!reserve_scratch(s, hidden_bytes, a_total)) return false;
    if (!attn_upload(s, s.dcos, s.dcos_cpu, s.dcos_cap, tab_bytes) ||
        !attn_upload(s, s.dsin, s.dsin_cpu, s.dsin_cap, tab_bytes) ||
        !attn_device(s, s.datt, s.datt_cap, datt_bytes)) {
        return false;
    }
    if (!ensure_upload(s.wbuf, s.w_cpu, s.w_cap, s.device.Get(), hidden_bytes) ||
        !ensure_upload(s.nbuf, s.n_cpu, s.n_cap, s.device.Get(), hidden_bytes)) {
        return false;
    }

    // Upload first layer's input
    std::memcpy(s.x_cpu, input, hidden_bytes);

    // Upload all cos/sin and norm weights
    for (std::size_t li = 0; li < num_layers; ++li) {
        std::memcpy(static_cast<std::uint8_t*>(s.dcos_cpu) + li * tab_bytes, layers[li].cos, tab_bytes);
        std::memcpy(static_cast<std::uint8_t*>(s.dsin_cpu) + li * tab_bytes, layers[li].sin, tab_bytes);
    }
    // We'll upload norm weights per-layer during recording

    // Parameter slots for each layer
    auto write_gemv = [&](std::uint64_t slot, std::size_t rows, std::size_t cols) {
        auto* p = reinterpret_cast<GemvParams*>(static_cast<std::uint8_t*>(s.params_cpu) + slot);
        p->rows = static_cast<std::uint32_t>(rows);
        p->blocks_per_row = static_cast<std::uint32_t>(cols / kElemsPerBlock);
        p->rows_per_group = kRowsPerGroup;
        p->reserved = 0;
    };
    auto write_rms = [&](std::uint64_t slot) {
        auto* p = reinterpret_cast<RmsParams*>(static_cast<std::uint8_t*>(s.params_cpu) + slot);
        p->count = static_cast<std::uint32_t>(hidden);
        p->rows = 1;
        p->epsilon = epsilon;
        p->pad = 0;
    };
    auto write_addn = [&](std::uint64_t slot) {
        auto* p = reinterpret_cast<AddnParams*>(static_cast<std::uint8_t*>(s.params_cpu) + slot);
        p->count = static_cast<std::uint32_t>(hidden);
        p->pad0 = p->pad1 = p->pad2 = 0;
    };
    auto write_silu = [&](std::uint64_t slot) {
        auto* p = reinterpret_cast<SiluParams*>(static_cast<std::uint8_t*>(s.params_cpu) + slot);
        p->count = static_cast<std::uint32_t>(ffn_rows);
        p->pad0 = p->pad1 = p->pad2 = 0;
    };
    auto write_rope = [&](std::uint64_t slot, std::size_t h, std::size_t hd, std::size_t pr) {
        auto* p = reinterpret_cast<RopeParams*>(static_cast<std::uint8_t*>(s.params_cpu) + slot);
        p->heads = static_cast<std::uint32_t>(h);
        p->head_dim = static_cast<std::uint32_t>(hd);
        p->pairs = static_cast<std::uint32_t>(pr);
        p->pad0 = 0;
    };
    auto write_attn = [&](std::uint64_t slot, std::size_t h, std::size_t kh, std::size_t hd,
                          std::size_t ctx, std::size_t fp, std::size_t pos, float inv_sc,
                          std::size_t sc_off, std::size_t out_off) {
        auto* ap = reinterpret_cast<AttnParams*>(static_cast<std::uint8_t*>(s.params_cpu) + slot);
        ap->heads = static_cast<std::uint32_t>(h);
        ap->kv_heads = static_cast<std::uint32_t>(kh);
        ap->head_dim = static_cast<std::uint32_t>(hd);
        ap->context = static_cast<std::uint32_t>(ctx);
        ap->first_pos = static_cast<std::uint32_t>(fp);
        ap->pos = static_cast<std::uint32_t>(pos);
        ap->scores_off = static_cast<std::uint32_t>(sc_off);
        ap->out_off = static_cast<std::uint32_t>(out_off);
        ap->inv_scale = inv_sc;
        ap->pad0 = ap->pad1 = ap->pad2 = 0.0f;
    };

    // Record each layer into its own command list
    std::vector<ComPtr<ID3D12GraphicsCommandList>> cmd_lists;
    cmd_lists.reserve(num_layers);

    for (std::size_t li = 0; li < num_layers; ++li) {
        const auto& p = layers[li];
        const auto& w = lw[li];
        const std::size_t layer_idx = p.layer;
        const std::size_t pos = p.pos;
        const std::size_t first_pos = p.first_pos;
        const std::size_t pairs = p.pairs;
        const std::size_t stride = s.kv_heads * s.kv_context * s.kv_head_dim * sizeof(float);
        const std::size_t dst = layer_idx * stride + pos * kv_bytes;
        const float inv_scale = 1.0f / std::sqrt(static_cast<float>(head_dim));

        // Allocate command allocator and list for this layer
        ComPtr<ID3D12CommandAllocator> alloc;
        if (FAILED(s.device->CreateCommandAllocator(D3D12_COMMAND_LIST_TYPE_COMPUTE, IID_PPV_ARGS(&alloc)))) return false;
        ComPtr<ID3D12GraphicsCommandList4> list;
        if (FAILED(s.device->CreateCommandList(0, D3D12_COMMAND_LIST_TYPE_COMPUTE, alloc.Get(), nullptr, IID_PPV_ARGS(&list)))) return false;

        // Per-layer parameter offsets (use same base, different slots)
        const std::uint64_t kGemvBase = 4096;
        const std::uint64_t kRms1 = 5888;
        const std::uint64_t kRms2 = 6144;
        const std::uint64_t kAdd1 = 6400;
        const std::uint64_t kAdd2 = 6656;
        const std::uint64_t kSilu = 6912;
        const std::uint64_t kRopeParamOffset = 1024;
        const std::uint64_t kRopeParamOffset2 = 1536;
        const std::uint64_t kAttnParamOffset = 1280;

        write_gemv(kGemvBase + 0, q_width, hidden);
        write_gemv(kGemvBase + 256, kv_width, hidden);
        write_gemv(kGemvBase + 512, kv_width, hidden);
        write_gemv(kGemvBase + 768, hidden, q_width);
        write_gemv(kGemvBase + 1024, ffn_rows, hidden);
        write_gemv(kGemvBase + 1280, ffn_rows, hidden);
        write_gemv(kGemvBase + 1536, hidden, ffn_rows);
        write_rms(kRms1);
        write_rms(kRms2);
        write_addn(kAdd1);
        write_addn(kAdd2);
        write_silu(kSilu);
        write_rope(kRopeParamOffset, heads, head_dim, pairs);
        write_rope(kRopeParamOffset2, kv_heads, head_dim, pairs);
        write_attn(kAttnParamOffset, heads, kv_heads, head_dim, s.kv_context, first_pos, pos, inv_scale, 0, scores_floats);

        // Upload norm weights for this layer
        std::memcpy(s.n_cpu, p.attn_norm_w, hidden_bytes);
        std::memcpy(s.w_cpu, p.ffn_norm_w, hidden_bytes);

        const std::uint64_t pb = s.params->GetGPUVirtualAddress();
        const std::uint64_t a_base = s.ybuf->GetGPUVirtualAddress();
        const std::uint64_t b_base = s.fbuf->GetGPUVirtualAddress();
        const std::uint64_t c_base = s.hbuf->GetGPUVirtualAddress();
        const std::uint64_t x_gva = s.xbuf->GetGPUVirtualAddress();

        auto groups = [](std::size_t rows) { return static_cast<UINT>((rows + kRowsPerGroup - 1) / kRowsPerGroup); };

        auto gemv = [&](std::uint64_t slot, ID3D12Resource* wq, std::uint64_t ws,
                        std::uint64_t in_gva, std::uint64_t out_gva, std::size_t rows) {
            list->SetPipelineState(s.pso_gemv.Get());
            list->SetComputeRootConstantBufferView(0, pb + slot);
            list->SetComputeRootShaderResourceView(1, wq->GetGPUVirtualAddress());
            list->SetComputeRootShaderResourceView(2, ws);
            list->SetComputeRootShaderResourceView(3, in_gva);
            list->SetComputeRootUnorderedAccessView(4, out_gva);
            list->Dispatch(groups(rows), 1, 1);
        };

        list->SetComputeRootSignature(s.root.Get());

        // 1. A.h = rmsnorm(x, attn_norm)
        list->SetPipelineState(s.pso_rms.Get());
        list->SetComputeRootConstantBufferView(0, pb + kRms1);
        list->SetComputeRootShaderResourceView(1, x_gva);
        list->SetComputeRootShaderResourceView(2, s.nbuf->GetGPUVirtualAddress());
        list->SetComputeRootUnorderedAccessView(4, a_base + a_h);
        list->Dispatch(1, 1, 1);

        // 2-4. Q|K|V matvecs
        transition(s, s.ybuf.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
        gemv(kGemvBase + 0, w.qq.Get(), w.qs, a_base + a_h, b_base + b_q, q_width);
        gemv(kGemvBase + 256, w.kq.Get(), w.ks, a_base + a_h, b_base + b_k, kv_width);
        gemv(kGemvBase + 512, w.vq.Get(), w.vs, a_base + a_h, b_base + b_v, kv_width);

        // 5/6. RoPE on q and k
        transition(s, s.fbuf.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
        transition(s, s.ybuf.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE, D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
        list->SetPipelineState(s.pso_rope.Get());
        list->SetComputeRootConstantBufferView(0, pb + kRopeParamOffset);
        list->SetComputeRootShaderResourceView(1, b_base + b_q);
        list->SetComputeRootShaderResourceView(2, s.dcos->GetGPUVirtualAddress() + li * tab_bytes);
        list->SetComputeRootShaderResourceView(3, s.dsin->GetGPUVirtualAddress() + li * tab_bytes);
        list->SetComputeRootUnorderedAccessView(4, a_base + a_qr);
        list->Dispatch(static_cast<UINT>((q_width + 255) / 256), 1, 1);

        list->SetComputeRootConstantBufferView(0, pb + kRopeParamOffset2);
        list->SetComputeRootShaderResourceView(1, b_base + b_k);
        list->SetComputeRootUnorderedAccessView(4, a_base + a_kr);
        list->Dispatch(static_cast<UINT>((kv_width + 255) / 256), 1, 1);

        // 7. Append k and v
        transition(s, s.ybuf.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS, D3D12_RESOURCE_STATE_COPY_SOURCE);
        transition(s, s.fbuf.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE, D3D12_RESOURCE_STATE_COPY_SOURCE);
        transition(s, s.kcache.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE, D3D12_RESOURCE_STATE_COPY_DEST);
        transition(s, s.vcache.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE, D3D12_RESOURCE_STATE_COPY_DEST);
        list->CopyBufferRegion(s.kcache.Get(), dst, s.ybuf.Get(), a_kr, kv_bytes);
        list->CopyBufferRegion(s.vcache.Get(), dst, s.fbuf.Get(), b_v, kv_bytes);
        transition(s, s.kcache.Get(), D3D12_RESOURCE_STATE_COPY_DEST, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
        transition(s, s.vcache.Get(), D3D12_RESOURCE_STATE_COPY_DEST, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
        transition(s, s.ybuf.Get(), D3D12_RESOURCE_STATE_COPY_SOURCE, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);

        // 8. Attention
        transition(s, s.datt.Get(), D3D12_RESOURCE_STATE_COMMON, D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
        list->SetPipelineState(s.pso_attn.Get());
        list->SetComputeRootConstantBufferView(0, pb + kAttnParamOffset);
        list->SetComputeRootShaderResourceView(1, a_base + a_qr);
        list->SetComputeRootShaderResourceView(2, s.kcache->GetGPUVirtualAddress() + layer_idx * stride);
        list->SetComputeRootShaderResourceView(3, s.vcache->GetGPUVirtualAddress() + layer_idx * stride);
        list->SetComputeRootUnorderedAccessView(4, s.datt->GetGPUVirtualAddress());
        list->Dispatch(static_cast<UINT>(heads), 1, 1);

        // 9. attn_output matvec
        transition(s, s.datt.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
        transition(s, s.ybuf.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE, D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
        gemv(kGemvBase + 768, w.oq.Get(), w.os_, s.datt->GetGPUVirtualAddress() + scores_floats * sizeof(float), a_base + a_t0, hidden);
        transition(s, s.datt.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE, D3D12_RESOURCE_STATE_COMMON);

        // 10. C.h1 = A.t0 + x
        transition(s, s.ybuf.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
        list->SetPipelineState(s.pso_addn.Get());
        list->SetComputeRootConstantBufferView(0, pb + kAdd1);
        list->SetComputeRootShaderResourceView(1, a_base + a_t0);
        list->SetComputeRootShaderResourceView(2, x_gva);
        list->SetComputeRootUnorderedAccessView(4, c_base);
        list->Dispatch(static_cast<UINT>((hidden + 255) / 256), 1, 1);

        // 11. A.h2 = rmsnorm(C.h1, ffn_norm)
        transition(s, s.hbuf.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
        transition(s, s.ybuf.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE, D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
        list->SetPipelineState(s.pso_rms.Get());
        list->SetComputeRootConstantBufferView(0, pb + kRms2);
        list->SetComputeRootShaderResourceView(1, c_base);
        list->SetComputeRootShaderResourceView(2, s.wbuf->GetGPUVirtualAddress());
        list->SetComputeRootUnorderedAccessView(4, a_base + a_h2);
        list->Dispatch(1, 1, 1);

        // 12/13. gate|up from A.h2 into B
        transition(s, s.ybuf.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
        transition(s, s.fbuf.Get(), D3D12_RESOURCE_STATE_COPY_SOURCE, D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
        gemv(kGemvBase + 1024, w.gq.Get(), w.gs, a_base + a_h2, b_base + b_g, ffn_rows);
        gemv(kGemvBase + 1280, w.uq.Get(), w.us, a_base + a_h2, b_base + b_u, ffn_rows);

        // 14. A.f = silu(B.g) * B.u
        transition(s, s.fbuf.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
        transition(s, s.ybuf.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE, D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
        list->SetPipelineState(s.pso_silu.Get());
        list->SetComputeRootConstantBufferView(0, pb + kSilu);
        list->SetComputeRootShaderResourceView(1, b_base + b_g);
        list->SetComputeRootShaderResourceView(2, b_base + b_u);
        list->SetComputeRootUnorderedAccessView(4, a_base + a_f);
        list->Dispatch(static_cast<UINT>((ffn_rows + 255) / 256), 1, 1);

        // 15. B.d = down @ A.f
        transition(s, s.ybuf.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
        transition(s, s.fbuf.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE, D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
        gemv(kGemvBase + 1536, w.dq_.Get(), w.ds, a_base + a_f, b_base + b_d, hidden);

        // 16. A.fin = C.h1 + B.d
        transition(s, s.fbuf.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
        transition(s, s.ybuf.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE, D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
        list->SetPipelineState(s.pso_addn.Get());
        list->SetComputeRootConstantBufferView(0, pb + kAdd2);
        list->SetComputeRootShaderResourceView(1, c_base);
        list->SetComputeRootShaderResourceView(2, b_base + b_d);
        list->SetComputeRootUnorderedAccessView(4, a_base + a_fin);
        list->Dispatch(static_cast<UINT>((hidden + 255) / 256), 1, 1);

        // Final layer: read back to host, others: copy to xbuf for next layer
        if (li == num_layers - 1) {
            transition(s, s.ybuf.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS, D3D12_RESOURCE_STATE_COPY_SOURCE);
            list->CopyBufferRegion(s.yread.Get(), 0, s.ybuf.Get(), a_fin, hidden_bytes);
            transition(s, s.ybuf.Get(), D3D12_RESOURCE_STATE_COPY_SOURCE, D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
        } else {
            // Copy output to xbuf for next layer's input
            transition(s, s.ybuf.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS, D3D12_RESOURCE_STATE_COPY_SOURCE);
            transition(s, s.xbuf.Get(), D3D12_RESOURCE_STATE_GENERIC_READ, D3D12_RESOURCE_STATE_COPY_DEST);
            list->CopyBufferRegion(s.xbuf.Get(), 0, s.ybuf.Get(), a_fin, hidden_bytes);
            transition(s, s.ybuf.Get(), D3D12_RESOURCE_STATE_COPY_SOURCE, D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
            transition(s, s.xbuf.Get(), D3D12_RESOURCE_STATE_COPY_DEST, D3D12_RESOURCE_STATE_GENERIC_READ);
        }

        // Restore buffers to expected states for next layer
        transition(s, s.fbuf.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE, D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
        transition(s, s.hbuf.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE, D3D12_RESOURCE_STATE_UNORDERED_ACCESS);

        list->Close();
        cmd_lists.push_back(list);
    }

    // Submit all command lists at once, then single wait
    if (!cmd_lists.empty()) {
        std::vector<ID3D12CommandList*> lists;
        lists.reserve(cmd_lists.size());
        for (auto& cl : cmd_lists) lists.push_back(cl.Get());
        
        s.queue->ExecuteCommandLists(static_cast<UINT>(lists.size()), lists.data());
        ++s.stats.submits;
        s.stats.batches += static_cast<std::uint64_t>(cmd_lists.size());
        s.stats.dispatches += static_cast<std::uint64_t>(cmd_lists.size() * 13); // ~13 dispatches per layer
        
        if (!wait_gpu(s)) return false;
    }

    // Read back final output
    void* mapped = nullptr;
    const D3D12_RANGE read_range{0, hidden_bytes};
    if (FAILED(s.yread->Map(0, &read_range, &mapped))) return false;
    std::memcpy(output, mapped, hidden_bytes);
    const D3D12_RANGE written{0, 0};
    s.yread->Unmap(0, &written);

    if (const char* trace = std::getenv("ZEN_D3D12_TRACE"); trace && trace[0] == '1') {
        std::printf("[d3d12] pipeline: SUCCESS num_layers=%zu\n", num_layers);
    }

    return true;
}
//
// norm -> QKV matvecs -> rope(q) -> rope(k) -> KV append -> GQA attention ->
// attn_output matvec -> residual -> FFN norm -> gate|up -> SiLU -> down -> residual,
// then one readback. q, k and v never leave VRAM, which is what removes the two
// extra submissions (and their ~130us each of fixed fence latency) that the split
// path pays per layer.
//
// Three activation arenas are needed, not two. A dispatch cannot read and write the
// same resource, and the residual base h1 has to stay readable through the whole
// FFN half while both other arenas are being written; with only A and B the final
// residual would need B.h1 and B.d in two different states at once.
//
//   A: h, qr, kr, t0, h2, f, fin      B: q, k, v, g, u, d      C: h1
//
// Every role swap is an explicit full-resource transition, and every buffer is
// returned to the state its owner expects so the next call can assume it.
bool layer_decode(const std::uint8_t* q_w, const std::uint8_t* k_w, const std::uint8_t* v_w,
                  const std::uint8_t* o_w, const std::uint8_t* gate_w, const std::uint8_t* up_w,
                  const std::uint8_t* down_w, const float* attn_norm_w, const float* ffn_norm_w,
                  const float* cos, const float* sin, std::size_t pairs, const float* x,
                  float* out, std::size_t layer, std::size_t pos, std::size_t first_pos,
                  std::size_t hidden, std::size_t heads, std::size_t kv_heads,
                  std::size_t head_dim, std::size_t ffn_rows, float epsilon) noexcept {
    State& s = state();
    std::lock_guard<std::mutex> lock(s.mutex);
    if (!init_locked(s)) {
        return false;
    }

    

    const std::size_t q_width = heads * head_dim;
    const std::size_t kv_width = kv_heads * head_dim;
    if (!hidden || !q_width || !kv_width || !ffn_rows || !pairs) {
        ++s.stats.fallbacks;
        return false;
    }
    if (hidden % kElemsPerBlock || ffn_rows % kElemsPerBlock || q_width % kElemsPerBlock ||
        kv_width % kElemsPerBlock) {
        ++s.stats.fallbacks;
        return false;
    }
    if (!s.kcache || layer >= s.kv_layers || pos >= s.kv_context || s.kv_heads != kv_heads ||
        s.kv_head_dim != head_dim) {
        ++s.stats.fallbacks;
        return false;
    }

    // Resolve all seven weights before recording anything, so a residency eviction
    // cannot invalidate a buffer an already-recorded dispatch is reading.
    ComPtr<ID3D12Resource> qq, kq, vq, oq, gq, uq, dq_;
    std::uint64_t qs = 0, ks = 0, vs = 0, os_ = 0, gs = 0, us = 0, ds = 0;
    auto bind = [&](const std::uint8_t* w, std::size_t rows, std::size_t cols,
                    ComPtr<ID3D12Resource>& q, std::uint64_t& sc) {
        WeightEntry* e = lookup_weights(s, w, rows, cols);
        if (!e) {
            return false;
        }
        q = e->quants;
        sc = e->scales_va;
        return true;
    };
    if (!bind(q_w, q_width, hidden, qq, qs) || !bind(k_w, kv_width, hidden, kq, ks) ||
        !bind(v_w, kv_width, hidden, vq, vs) || !bind(o_w, hidden, q_width, oq, os_) ||
        !bind(gate_w, ffn_rows, hidden, gq, gs) || !bind(up_w, ffn_rows, hidden, uq, us) ||
        !bind(down_w, hidden, ffn_rows, dq_, ds)) {
        ++s.stats.fallbacks;
        return false;
    }

    constexpr std::uint64_t kAlign = 256u;
    auto span = [](std::uint64_t bytes) { return (bytes + kAlign - 1) & ~(kAlign - 1); };
    const std::uint64_t hidden_span = span(hidden * sizeof(float));
    const std::uint64_t ffn_span = span(ffn_rows * sizeof(float));
    const std::uint64_t q_span = span(q_width * sizeof(float));
    const std::uint64_t kv_span = span(kv_width * sizeof(float));

    const std::uint64_t a_h = 0;
    const std::uint64_t a_qr = a_h + hidden_span;
    const std::uint64_t a_kr = a_qr + q_span;
    const std::uint64_t a_t0 = a_kr + kv_span;
    const std::uint64_t a_h2 = a_t0 + hidden_span;
    const std::uint64_t a_f = a_h2 + hidden_span;
    const std::uint64_t a_fin = a_f + ffn_span;
    const std::uint64_t a_total = a_fin + hidden_span;

    const std::uint64_t b_q = 0;
    const std::uint64_t b_k = b_q + q_span;
    const std::uint64_t b_v = b_k + kv_span;
    const std::uint64_t b_g = b_v + kv_span;
    const std::uint64_t b_u = b_g + ffn_span;
    const std::uint64_t b_d = b_u + ffn_span;
    const std::uint64_t b_total = b_d + hidden_span;

    const std::size_t hidden_bytes = hidden * sizeof(float);
    const std::size_t kv_bytes = kv_width * sizeof(float);
    const std::size_t tab_bytes = pairs * sizeof(float);
    const std::size_t scores_floats = heads * s.kv_context;
    const std::size_t att_floats = heads * head_dim;
    const std::size_t datt_bytes = (scores_floats + att_floats) * sizeof(float);

    if (!reserve_scratch(s, hidden_bytes, a_total)) {
        ++s.stats.fallbacks;
        return false;
    }
    if (!s.fbuf || b_total > s.f_cap) {
        s.fbuf.Reset();
        s.fbuf = create_buffer(s.device.Get(), b_total, D3D12_HEAP_TYPE_DEFAULT,
                               D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
                               D3D12_RESOURCE_FLAG_ALLOW_UNORDERED_ACCESS);
        if (!s.fbuf) {
            s.f_cap = 0;
            ++s.stats.fallbacks;
            return false;
        }
        s.f_cap = static_cast<std::size_t>(b_total);
    }
    if (!s.hbuf || hidden_span > s.h_cap) {
        s.hbuf.Reset();
        s.hbuf = create_buffer(s.device.Get(), hidden_span, D3D12_HEAP_TYPE_DEFAULT,
                               D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
                               D3D12_RESOURCE_FLAG_ALLOW_UNORDERED_ACCESS);
        if (!s.hbuf) {
            s.h_cap = 0;
            ++s.stats.fallbacks;
            return false;
        }
        s.h_cap = static_cast<std::size_t>(hidden_span);
    }
    if (!ensure_upload(s.wbuf, s.w_cpu, s.w_cap, s.device.Get(), hidden_bytes) ||
        !ensure_upload(s.nbuf, s.n_cpu, s.n_cap, s.device.Get(), hidden_bytes)) {
        ++s.stats.fallbacks;
        return false;
    }
    if (!attn_upload(s, s.dcos, s.dcos_cpu, s.dcos_cap, tab_bytes) ||
        !attn_upload(s, s.dsin, s.dsin_cpu, s.dsin_cap, tab_bytes) ||
        !attn_device(s, s.datt, s.datt_cap, datt_bytes)) {
        ++s.stats.fallbacks;
        return false;
    }

    std::memcpy(s.x_cpu, x, hidden_bytes);      // residual base and norm input
    std::memcpy(s.w_cpu, ffn_norm_w, hidden_bytes);
    std::memcpy(s.n_cpu, attn_norm_w, hidden_bytes);
    std::memcpy(s.dcos_cpu, cos, tab_bytes);
    std::memcpy(s.dsin_cpu, sin, tab_bytes);

    auto* base = static_cast<std::uint8_t*>(s.params_cpu);
    constexpr std::uint64_t kGemvBase = 4096;
    constexpr std::uint64_t kRms1 = 5888;
    constexpr std::uint64_t kRms2 = 6144;
    constexpr std::uint64_t kAdd1 = 6400;
    constexpr std::uint64_t kAdd2 = 6656;
    constexpr std::uint64_t kSilu = 6912;
    auto write_gemv = [&](std::uint64_t slot, std::size_t rows, std::size_t cols) {
        auto* p = reinterpret_cast<GemvParams*>(base + slot);
        p->rows = static_cast<std::uint32_t>(rows);
        p->blocks_per_row = static_cast<std::uint32_t>(cols / kElemsPerBlock);
        p->rows_per_group = kRowsPerGroup;
        p->reserved = 0;
    };
    auto write_rms = [&](std::uint64_t slot) {
        auto* p = reinterpret_cast<RmsParams*>(base + slot);
        p->count = static_cast<std::uint32_t>(hidden);
        p->rows = 1;
        p->epsilon = epsilon;
        p->pad = 0;
    };
    auto write_addn = [&](std::uint64_t slot) {
        auto* p = reinterpret_cast<AddnParams*>(base + slot);
        p->count = static_cast<std::uint32_t>(hidden);
        p->pad0 = p->pad1 = p->pad2 = 0;
    };
    write_gemv(kGemvBase + 0, q_width, hidden);
    write_gemv(kGemvBase + 256, kv_width, hidden);
    write_gemv(kGemvBase + 512, kv_width, hidden);
    write_gemv(kGemvBase + 768, hidden, q_width);
    write_gemv(kGemvBase + 1024, ffn_rows, hidden);
    write_gemv(kGemvBase + 1280, ffn_rows, hidden);
    write_gemv(kGemvBase + 1536, hidden, ffn_rows);
    write_rms(kRms1);
    write_rms(kRms2);
    write_addn(kAdd1);
    write_addn(kAdd2);
    auto* silu = reinterpret_cast<SiluParams*>(base + kSilu);
    silu->count = static_cast<std::uint32_t>(ffn_rows);
    silu->pad0 = silu->pad1 = silu->pad2 = 0;
    auto* rp = reinterpret_cast<RopeParams*>(base + kRopeParamOffset);
    rp->heads = static_cast<std::uint32_t>(heads);
    rp->head_dim = static_cast<std::uint32_t>(head_dim);
    rp->pairs = static_cast<std::uint32_t>(pairs);
    rp->pad0 = 0;
    auto* krp = reinterpret_cast<RopeParams*>(base + kRopeParamOffset2);
    krp->heads = static_cast<std::uint32_t>(kv_heads);
    krp->head_dim = static_cast<std::uint32_t>(head_dim);
    krp->pairs = static_cast<std::uint32_t>(pairs);
    krp->pad0 = 0;
    auto* ap = reinterpret_cast<AttnParams*>(base + kAttnParamOffset);
    ap->heads = static_cast<std::uint32_t>(heads);
    ap->kv_heads = static_cast<std::uint32_t>(kv_heads);
    ap->head_dim = static_cast<std::uint32_t>(head_dim);
    ap->context = static_cast<std::uint32_t>(s.kv_context);
    ap->first_pos = static_cast<std::uint32_t>(first_pos);
    ap->pos = static_cast<std::uint32_t>(pos);
    ap->scores_off = 0;
    ap->out_off = static_cast<std::uint32_t>(scores_floats);
    ap->inv_scale = 1.0f / std::sqrt(static_cast<float>(head_dim));
    ap->pad0 = ap->pad1 = ap->pad2 = 0.0f;

    const std::uint64_t pb = s.params->GetGPUVirtualAddress();
    const std::uint64_t a_base = s.ybuf->GetGPUVirtualAddress();
    const std::uint64_t b_base = s.fbuf->GetGPUVirtualAddress();
    const std::uint64_t c_base = s.hbuf->GetGPUVirtualAddress();
    const std::uint64_t x_gva = s.xbuf->GetGPUVirtualAddress();

    auto groups = [](std::size_t rows) {
        return static_cast<UINT>((rows + kRowsPerGroup - 1) / kRowsPerGroup);
    };
    // out_gva is absolute: the QKV and FFN matvecs write into arena B, the
    // attention-output matvec into arena A, so a single fixed base would be wrong.
    auto gemv = [&](std::uint64_t slot, ID3D12Resource* wq, std::uint64_t ws,
                    std::uint64_t in_gva, std::uint64_t out_gva, std::size_t rows) {
        s.list->SetPipelineState(s.pso_gemv.Get());
        s.list->SetComputeRootConstantBufferView(0, pb + slot);
        s.list->SetComputeRootShaderResourceView(1, wq->GetGPUVirtualAddress());
        s.list->SetComputeRootShaderResourceView(2, ws);
        s.list->SetComputeRootShaderResourceView(3, in_gva);
        s.list->SetComputeRootUnorderedAccessView(4, out_gva);
        s.list->Dispatch(groups(rows), 1, 1);
    };

    s.allocator->Reset();
    s.list->Reset(s.allocator.Get(), s.pso_rms.Get());
    s.list->SetComputeRootSignature(s.root.Get());
    s.current_comp = Comp::Projections;
    // Stamp 0 opens the layer, 1 closes the attention half (norm/QKV/rope/attention/
    // attn_output/residual), 2 closes the FFN half, 3 closes the readback copy, so the
    // trace can separate the two halves and the copy instead of billing the layer as one
    // block.
    if (s.trace) {
        s.list->EndQuery(s.ts_heap.Get(), D3D12_QUERY_TYPE_TIMESTAMP, 0);
    }

    // 1. A.h = rmsnorm(x, attn_norm). A starts UNORDERED_ACCESS.
    s.list->SetComputeRootConstantBufferView(0, pb + kRms1);
    s.list->SetComputeRootShaderResourceView(1, x_gva);
    s.list->SetComputeRootShaderResourceView(2, s.nbuf->GetGPUVirtualAddress());
    s.list->SetComputeRootUnorderedAccessView(4, a_base + a_h);
    s.list->Dispatch(1, 1, 1);

    // 2-4. Q|K|V matvecs read A.h, write B. A becomes SRV, B stays UAV.
    transition(s, s.ybuf.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
               D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
    gemv(kGemvBase + 0, qq.Get(), qs, a_base + a_h, b_base + b_q, q_width);
    gemv(kGemvBase + 256, kq.Get(), ks, a_base + a_h, b_base + b_k, kv_width);
    gemv(kGemvBase + 512, vq.Get(), vs, a_base + a_h, b_base + b_v, kv_width);

    // 5/6. RoPE on q and k: read B, write A.
    transition(s, s.fbuf.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
               D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
    transition(s, s.ybuf.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
               D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
    s.list->SetPipelineState(s.pso_rope.Get());
    s.list->SetComputeRootConstantBufferView(0, pb + kRopeParamOffset);
    s.list->SetComputeRootShaderResourceView(1, b_base + b_q);
    s.list->SetComputeRootShaderResourceView(2, s.dcos->GetGPUVirtualAddress());
    s.list->SetComputeRootShaderResourceView(3, s.dsin->GetGPUVirtualAddress());
    s.list->SetComputeRootUnorderedAccessView(4, a_base + a_qr);
    s.list->Dispatch(static_cast<UINT>((q_width + 255) / 256), 1, 1);

    s.list->SetComputeRootConstantBufferView(0, pb + kRopeParamOffset2);
    s.list->SetComputeRootShaderResourceView(1, b_base + b_k);
    s.list->SetComputeRootUnorderedAccessView(4, a_base + a_kr);
    s.list->Dispatch(static_cast<UINT>((kv_width + 255) / 256), 1, 1);

    // 7. Append k and v at this position.
    const std::size_t stride = s.kv_heads * s.kv_context * s.kv_head_dim * sizeof(float);
    const std::size_t dst = layer * stride + pos * kv_bytes;
    transition(s, s.ybuf.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
               D3D12_RESOURCE_STATE_COPY_SOURCE);
    transition(s, s.fbuf.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
               D3D12_RESOURCE_STATE_COPY_SOURCE);
    transition(s, s.kcache.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
               D3D12_RESOURCE_STATE_COPY_DEST);
    transition(s, s.vcache.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
               D3D12_RESOURCE_STATE_COPY_DEST);
    s.list->CopyBufferRegion(s.kcache.Get(), dst, s.ybuf.Get(), a_kr, kv_bytes);
    s.list->CopyBufferRegion(s.vcache.Get(), dst, s.fbuf.Get(), b_v, kv_bytes);
    transition(s, s.kcache.Get(), D3D12_RESOURCE_STATE_COPY_DEST,
               D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
    transition(s, s.vcache.Get(), D3D12_RESOURCE_STATE_COPY_DEST,
               D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
    transition(s, s.ybuf.Get(), D3D12_RESOURCE_STATE_COPY_SOURCE,
               D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);

    // 8. Attention: read A.qr and the caches, write the scratch UAV.
    transition(s, s.datt.Get(), D3D12_RESOURCE_STATE_COMMON,
               D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
    s.list->SetPipelineState(s.pso_attn.Get());
    s.list->SetComputeRootConstantBufferView(0, pb + kAttnParamOffset);
    s.list->SetComputeRootShaderResourceView(1, a_base + a_qr);
    s.list->SetComputeRootShaderResourceView(2, s.kcache->GetGPUVirtualAddress() + layer * stride);
    s.list->SetComputeRootShaderResourceView(3, s.vcache->GetGPUVirtualAddress() + layer * stride);
    s.list->SetComputeRootUnorderedAccessView(4, s.datt->GetGPUVirtualAddress());
    // One 32-thread group per head, so the grid width is exactly `heads`.
    s.list->Dispatch(static_cast<UINT>(heads), 1, 1);

    // 9. attn_output matvec: read the attention result, write A.t0.
    transition(s, s.datt.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
               D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
    transition(s, s.ybuf.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
               D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
    gemv(kGemvBase + 768, oq.Get(), os_, s.datt->GetGPUVirtualAddress() +
                                              scores_floats * sizeof(float),
         a_base + a_t0, hidden);
    transition(s, s.datt.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
               D3D12_RESOURCE_STATE_COMMON);

    // 10. C.h1 = A.t0 + x.
    transition(s, s.ybuf.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
               D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
    s.list->SetPipelineState(s.pso_addn.Get());
    s.list->SetComputeRootConstantBufferView(0, pb + kAdd1);
    s.list->SetComputeRootShaderResourceView(1, a_base + a_t0);
    s.list->SetComputeRootShaderResourceView(2, x_gva);
    s.list->SetComputeRootUnorderedAccessView(4, c_base);
    s.list->Dispatch(static_cast<UINT>((hidden + 255) / 256), 1, 1);

    if (s.trace) {
        s.list->EndQuery(s.ts_heap.Get(), D3D12_QUERY_TYPE_TIMESTAMP, 1);
    }

    // 11. A.h2 = rmsnorm(C.h1, ffn_norm).
    transition(s, s.hbuf.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
               D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
    transition(s, s.ybuf.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
               D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
    s.list->SetPipelineState(s.pso_rms.Get());
    s.list->SetComputeRootConstantBufferView(0, pb + kRms2);
    s.list->SetComputeRootShaderResourceView(1, c_base);
    s.list->SetComputeRootShaderResourceView(2, s.wbuf->GetGPUVirtualAddress());
    s.list->SetComputeRootUnorderedAccessView(4, a_base + a_h2);
    s.list->Dispatch(1, 1, 1);

    // 12/13. gate|up from A.h2 into B.
    transition(s, s.ybuf.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
               D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
    transition(s, s.fbuf.Get(), D3D12_RESOURCE_STATE_COPY_SOURCE,
               D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
    gemv(kGemvBase + 1024, gq.Get(), gs, a_base + a_h2, b_base + b_g, ffn_rows);
    gemv(kGemvBase + 1280, uq.Get(), us, a_base + a_h2, b_base + b_u, ffn_rows);

    // 14. A.f = silu(B.g) * B.u
    transition(s, s.fbuf.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
               D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
    transition(s, s.ybuf.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
               D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
    s.list->SetPipelineState(s.pso_silu.Get());
    s.list->SetComputeRootConstantBufferView(0, pb + kSilu);
    s.list->SetComputeRootShaderResourceView(1, b_base + b_g);
    s.list->SetComputeRootShaderResourceView(2, b_base + b_u);
    s.list->SetComputeRootUnorderedAccessView(4, a_base + a_f);
    s.list->Dispatch(static_cast<UINT>((ffn_rows + 255) / 256), 1, 1);

    // 15. B.d = down @ A.f
    transition(s, s.ybuf.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
               D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
    transition(s, s.fbuf.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
               D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
    gemv(kGemvBase + 1536, dq_.Get(), ds, a_base + a_f, b_base + b_d, hidden);

    // 16. A.fin = C.h1 + B.d
    transition(s, s.fbuf.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
               D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
    transition(s, s.ybuf.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
               D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
    s.list->SetPipelineState(s.pso_addn.Get());
    s.list->SetComputeRootConstantBufferView(0, pb + kAdd2);
    s.list->SetComputeRootShaderResourceView(1, c_base);
    s.list->SetComputeRootShaderResourceView(2, b_base + b_d);
    s.list->SetComputeRootUnorderedAccessView(4, a_base + a_fin);
    s.list->Dispatch(static_cast<UINT>((hidden + 255) / 256), 1, 1);

    // 17. Read back only the hidden state. Restore every buffer to the state its next
    // user assumes: A and B UNORDERED_ACCESS (their creation state), C likewise, and
    // the attention scratch to COMMON, which is where attn_block_locked expects it.
    if (s.trace) {
        s.list->EndQuery(s.ts_heap.Get(), D3D12_QUERY_TYPE_TIMESTAMP, 2);
    }
    transition(s, s.ybuf.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
               D3D12_RESOURCE_STATE_COPY_SOURCE);
    s.list->CopyBufferRegion(s.yread.Get(), 0, s.ybuf.Get(), a_fin, hidden_bytes);
    transition(s, s.ybuf.Get(), D3D12_RESOURCE_STATE_COPY_SOURCE,
               D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
    transition(s, s.fbuf.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
               D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
    transition(s, s.hbuf.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
               D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
    if (s.trace) {
        s.list->EndQuery(s.ts_heap.Get(), D3D12_QUERY_TYPE_TIMESTAMP, 3);
        s.list->ResolveQueryData(s.ts_heap.Get(), D3D12_QUERY_TYPE_TIMESTAMP, 0, 4,
                                 s.ts_read.Get(), 0);
    }
    s.list->Close();

    if (!execute_and_wait(s)) {
        ++s.stats.fallbacks;
        return false;
    }

    void* mapped = nullptr;
    const D3D12_RANGE read_range{0, hidden_bytes};
    if (FAILED(s.yread->Map(0, &read_range, &mapped))) {
        ++s.stats.fallbacks;
        return false;
    }
    if (s.trace) {
        std::uint64_t dev = 0;
        accumulate_gpu_us(s, dev, 0, 1);
        note_dev(s, Comp::Projections, dev);
        dev = 0;
        accumulate_gpu_us(s, dev, 1, 2);
        note_dev(s, Comp::FfnFused, dev);
    }
    std::memcpy(out, mapped, hidden_bytes);
    const D3D12_RANGE written{0, 0};
    s.yread->Unmap(0, &written);
    s.stats.dispatches += 13;
    ++s.stats.batches;
    return true;
}

bool ffn_residual_fused(const std::uint8_t* attn_out_w, const std::uint8_t* gate_w,
                        const std::uint8_t* up_w, const std::uint8_t* down_w,
                        const float* norm_weight, const float* x, const float* attn_out,
                        float* out, std::size_t hidden, std::size_t attn_width,
                        std::size_t ffn_rows, float epsilon) noexcept {
    if (!attn_out_w || !gate_w || !up_w || !down_w || !norm_weight || !x || !attn_out || !out) {
        return false;
    }
    State& s = state();
    std::lock_guard<std::mutex> lock(s.mutex);
    if (!init_locked(s)) {
        return false;
    }
    if (!ffn_residual_fused_locked(s, attn_out_w, gate_w, up_w, down_w, norm_weight, x, attn_out,
                                   out, hidden, attn_width, ffn_rows, epsilon)) {
        ++s.stats.fallbacks;
        return false;
    }
    return true;
}

bool residual_add(const float* a, const float* b, float* out, std::size_t count) noexcept {
    if (!a || !b || !out || !count) {
        return false;
    }
    State& s = state();
    std::lock_guard<std::mutex> lock(s.mutex);
    if (!init_locked(s)) {
        return false;
    }
    if (!addn_locked(s, a, b, out, count)) {
        ++s.stats.fallbacks;
        return false;
    }
    return true;
}

}  // namespace zen::d3d12

#endif  // ZEN_HAS_D3D12
