with open('include/zen/dense_transformer_runtime.h', 'r') as f:
    lines = f.readlines()

# Remove duplicate method declarations (keep first occurrence)
seen = set()
new_lines = []
for line in lines:
    stripped = line.strip()
    # Check for method declarations we want to deduplicate
    import re
    match = re.search(r'\bbool\s+(\w+)\s*\(', line)
    if match:
        method = match.group(1)
        if method in ['layer_is_recurrent', 'hadamard_folded', 'forward_q35_batch', 'forward_q35_token', 'forward_batch', 'forward']:
            if method in seen:
                print(f'Skipping duplicate: {line.strip()}')
                continue
            seen.add(method)
    new_lines.append(line)

with open('include/zen/dense_transformer_runtime.h', 'w') as f:
    f.writelines(new_lines)

print('Removed duplicates!')