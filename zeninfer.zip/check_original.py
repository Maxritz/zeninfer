with open('src/adapters/dense_transformer_runtime.cpp.bak', 'r') as f:
    lines = f.readlines()

# Find the duplicate scope_attn
for i, line in enumerate(lines):
    if line.strip().count('zen::diag::Scope scope_attn("transformer.prefill.attention"') == 2:
        print(f'Found duplicate at line {i+1}: {line.strip()[:100]}')
        break

# Find the printf line
for i, line in enumerate(lines):
    if 'num_tokens' in line and 'printf' in line:
        print(f'Line {i+1}: {repr(line[:120])}')
        break