with open('src/adapters/dense_transformer_runtime.cpp', 'r') as f:
    content = f.read()

start_idx = content.find('zen::diag::Scope scope_rope("transformer.prefill.rope",zen::diag::Phase::compute);', 75648)
end_idx = content.find('{zen::diag::Scope scope_attn("transformer.prefill.attention",zen::diag::Phase::compute);', start_idx)

print('Start:', start_idx)
print('End:', end_idx)

# The correct replacement - DOES NOT include scope_attn line (it's in content[end_idx:])
new_section = """{zen::diag::Scope scope_rope("transformer.prefill.rope",zen::diag::Phase::compute);
        for(std::size_t t=0;t<T;++t){
            const std::uint32_t pos = start_pos + static_cast<std::uint32_t>(t);
            if(qnorm){
                qk_rms_norm(q.data()+t*QW,H,D,qnorm->values.data(),config_.rms_epsilon);
                qk_rms_norm(k.data()+t*KW,KH,D,knorm->values.data(),config_.rms_epsilon);
            }
            if(!config_.use_alibi){
                rope(q.data()+t*QW,H,D,config_.rope_dim,pos,config_.rope_base,config_.rope_scaling_type,config_.rope_scaling_factor,config_.rope_original_context,config_.rope_low_freq_factor,config_.rope_high_freq_factor,config_.rope_yarn_beta_fast,config_.rope_yarn_beta_slow);
                rope(k.data()+t*KW,KH,D,config_.rope_dim,pos,config_.rope_base,config_.rope_scaling_type,config_.rope_scaling_factor,config_.rope_original_context,config_.rope_low_freq_factor,config_.rope_high_freq_factor,config_.rope_yarn_beta_fast,config_.rope_yarn_beta_slow);
            }
            std::copy_n(k.data()+t*KW,KW,kc[l].data()+std::size_t(pos)*KW);
            std::copy_n(v.data()+t*KW,KW,vc[l].data()+std::size_t(pos)*KW);
            // Keep the device cache in step with the host one: decode reads the device
            // cache, so without this the prompt positions are missing from it and decode
            // attends over the wrong window. Not fatal if it fails - decode then falls
            // back to the host path, which uses kc/vc.
#if defined(ZEN_HAS_D3D12)
            if(!config_.use_alibi && device_attention_available(config_.layers,kc[l].size()/KW,KH,D,config_.rms_epsilon)){
                zen::d3d12::kv_cache_append(l, pos, k.data()+t*KW, v.data()+t*KW, KH, D);
            }
#endif
        }}
        // Batched KV cache append for this layer (collect all tokens at once)
#if defined(ZEN_HAS_D3D12)
        if(!config_.use_alibi && device_attention_available(config_.layers,kc[l].size()/KW,KH,D,config_.rms_epsilon)){
            std::vector<std::size_t> kv_layers(T);
            std::vector<std::size_t> kv_positions(T);
            std::vector<const float*> kv_ks(T);
            std::vector<const float*> kv_vs(T);
            for(std::size_t t=0; t<T; ++t){
                const std::uint32_t pos = start_pos + static_cast<std::uint32_t>(t);
                kv_layers[t] = l;
                kv_positions[t] = pos;
                kv_ks[t] = k.data() + t*KW;
                kv_vs[t] = v.data() + t*KW;
            }
            if (const char* trace = std::getenv("ZEN_D3D12_TRACE"); trace && trace[0] == '1') {
                std::printf("[d3d12] batched kv append (runtime): layer=%zu num_tokens=%zu\\n", l, (size_t)T);
            }
            zen::d3d12::kv_cache_append_batched(
                (const std::size_t*)kv_layers.data(), T,
                (const std::size_t*)kv_positions.data(),
                (const float**)kv_ks.data(),
                (const float**)kv_vs.data(),
                KH, D
            );
        }
#endif"""

with open('src/adapters/dense_transformer_runtime.cpp', 'r') as f:
    content = f.read()

start_idx = content.find('zen::diag::Scope scope_rope("transformer.prefill.rope",zen::diag::Phase::compute);', 75648)
end_idx = content.find('{zen::diag::Scope scope_attn("transformer.prefill.attention",zen::diag::Phase::compute);', start_idx)

new_content = content[:start_idx] + new_section + content[end_idx:]

with open('src/adapters/dense_transformer_runtime.cpp', 'w') as f:
    f.write(new_content)

print('Replacement done!')