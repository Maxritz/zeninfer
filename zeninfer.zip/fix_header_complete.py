# Restore the header file to a clean state
with open('include/zen/dense_transformer_runtime.h', 'r') as f:
    content = f.read()

# The class definition should have these methods in order:
# load, loaded, tokenizer_available, config, architecture_name, chat_template
# generate, generate_speculative, tokenize, detokenize, generate_text
# layer_is_recurrent, hadamard_folded, forward_q35_batch, forward_q35_token, forward_batch, forward

# Let's rebuild the class definition properly
new_class = '''class DenseTransformerRuntime {
public:
    bool load(const std::filesystem::path& path, std::string* error=nullptr);
    bool loaded() const noexcept { return loaded_; }
    bool tokenizer_available() const noexcept { return tokenizer_loaded_; }
    const RuntimeConfig& config() const noexcept { return config_; }
    const std::string& architecture_name() const noexcept { return architecture_name_; }
    const std::string& chat_template() const noexcept { return chat_template_; }
    bool generate(const std::vector<std::uint32_t>& prompt, std::uint32_t max_new_tokens,
                  Generation& result, std::string* error=nullptr,
                  const std::function<void(const std::vector<std::uint32_t>&)>& on_tokens={},
                  const GenerationOptions& options={}, const std::atomic<bool>* cancelled=nullptr) const;
    bool generate_speculative(const std::vector<std::uint32_t>& prompt, std::uint32_t max_new, const DenseTransformerRuntime& draft, std::uint32_t draft_tokens, Generation& result, std::string* error=nullptr, const std::function<void(const std::vector<std::uint32_t>&)>& on_tokens={}, const GenerationOptions& options={}, const std::atomic<bool>* cancelled=nullptr) const;
    bool tokenize(const std::string& text, std::vector<std::uint32_t>& ids) const;
    bool detokenize(const std::vector<std::uint32_t>& ids, std::string& text) const;
    bool generate_text(const std::string& prompt, std::uint32_t max_new_tokens,
                       Generation& result, std::string& text, std::string* error=nullptr,
                       const std::function<void(const std::string&)>& on_text={},
                       const GenerationOptions& options={}, const std::atomic<bool>* cancelled=nullptr) const;

    // Additional methods for pipeline support
    bool layer_is_recurrent(std::uint32_t layer) const noexcept;
    bool hadamard_folded(const char* suffix, std::size_t layer) const noexcept;
    bool forward_q35_batch(const std::vector<std::uint32_t>& tokens,
                           std::vector<std::vector<float>>& kc,
                           std::vector<std::vector<float>>& vc,
                           std::vector<std::vector<float>>& convc,
                           std::vector<std::vector<float>>& ssmc,
                           std::vector<float>& logits,
                           std::uint32_t start_pos) const;
    bool forward_q35_token(std::uint32_t token, std::uint32_t position,
                           std::vector<std::vector<float>>& kc,
                           std::vector<std::vector<float>>& vc,
                           std::vector<std::vector<float>>& convc,
                           std::vector<std::vector<float>>& ssmc,
                           std::vector<float>& logits,
                           std::uint32_t start_pos) const;
    bool forward_batch(const std::vector<std::uint32_t>& tokens,
                       std::vector<std::vector<float>>& kc,
                       std::vector<std::vector<float>>& vc,
                       std::vector<float>& logits,
                       std::uint32_t start_pos,
                       std::size_t tail_count,
                       std::vector<float>* tail_logits) const;
    bool forward(std::uint32_t token, std::uint32_t pos,
                 std::vector<std::vector<float>>& kc,
                 std::vector<std::vector<float>>& vc,
                 std::vector<float>& logits) const;

public:
    struct Tensor { std::vector<std::uint64_t> dims; std::vector<float> values; const std::uint8_t* raw{}; std::size_t elements{}; std::string name; };
    // ... rest of class
};'''

with open('include/zen/dense_transformer_runtime.h', 'r') as f:
    content = f.read()

# Find the class definition and replace from 'class DenseTransformerRuntime' to '};'
import re
pattern = r'(class DenseTransformerRuntime \{.*?\n};)'
match = re.search(r'class DenseTransformerRuntime \{.*?\n\};', content, re.DOTALL)
if match:
    # Replace the entire class definition
    new_class = '''class DenseTransformerRuntime {
public:
    bool load(const std::filesystem::path& path, std::string* error=nullptr);
    bool loaded() const noexcept { return loaded_; }
    bool tokenizer_available() const noexcept { return tokenizer_loaded_; }
    const RuntimeConfig& config() const noexcept { return config_; }
    const std::string& architecture_name() const noexcept { return architecture_name_; }
    const std::string& chat_template() const noexcept { return chat_template_; }
    bool generate(const std::vector<std::uint32_t>& prompt, std::uint32_t max_new_tokens,
                  Generation& result, std::string* error=nullptr,
                  const std::function<void(const std::vector<std::uint32_t>&)>& on_tokens={},
                  const GenerationOptions& options={}, const std::atomic<bool>* cancelled=nullptr) const;
    bool generate_speculative(const std::vector<std::uint32_t>& prompt, std::uint32_t max_new, const DenseTransformerRuntime& draft, std::uint32_t draft_tokens, Generation& result, std::string* error=nullptr, const std::function<void(const std::vector<std::uint32_t>&)>& on_tokens={}, const GenerationOptions& options={}, const std::atomic<bool>* cancelled=nullptr) const;
    bool tokenize(const std::string& text, std::vector<std::uint32_t>& ids) const;
    bool detokenize(const std::vector<std::uint32_t>& ids, std::string& text) const;
    bool generate_text(const std::string& prompt, std::uint32_t max_new_tokens,
                       Generation& result, std::string& text, std::string* error=nullptr,
                       const std::function<void(const std::string&)>& on_text={},
                       const GenerationOptions& options={}, const std::atomic<bool>* cancelled=nullptr) const;

    // Additional methods for pipeline support
    bool layer_is_recurrent(std::uint32_t layer) const noexcept;
    bool hadamard_folded(const char* suffix, std::size_t layer) const noexcept;
    bool forward_q35_batch(const std::vector<std::uint32_t>& tokens,
                           std::vector<std::vector<float>>& kc,
                           std::vector<std::vector<float>>& vc,
                           std::vector<std::vector<float>>& convc,
                           std::vector<std::vector<float>>& ssmc,
                           std::vector<float>& logits,
                           std::uint32_t start_pos) const;
    bool forward_q35_token(std::uint32_t token, std::uint32_t position,
                           std::vector<std::vector<float>>& kc,
                           std::vector<std::vector<float>>& vc,
                           std::vector<std::vector<float>>& convc,
                           std::vector<std::vector<float>>& ssmc,
                           std::vector<float>& logits,
                           std::uint32_t start_pos) const;
    bool forward_batch(const std::vector<std::uint32_t>& tokens,
                       std::vector<std::vector<float>>& kc,
                       std::vector<std::vector<float>>& vc,
                       std::vector<float>& logits,
                       std::uint32_t start_pos,
                       std::size_t tail_count,
                       std::vector<float>* tail_logits) const;
    bool forward(std::uint32_t token, std::uint32_t pos,
                 std::vector<std::vector<float>>& kc,
                 std::vector<std::vector<float>>& vc,
                 std::vector<float>& logits) const;

public:
    struct Tensor { std::vector<std::uint64_t> dims; std::vector<float> values; const std::uint8_t* raw{}; std::size_t elements{}; std::string name; };
    std::shared_ptr<MappedFile> mapping_;
    const std::uint8_t* data_{};
    std::size_t size_{};
    RuntimeConfig config_;
    bool loaded_{false};
    bool tokenizer_loaded_{false};
    std::string architecture_name_;
    std::string chat_template_;
    std::vector<std::vector<float>> kc, vc, attn;
    std::vector<std::vector<std::vector<float>>> k_cache, v_cache;
    std::vector<std::vector<float>> attn_norm_weights, ffn_norm_weights;
    std::vector<const std::uint8_t*> attn_q_weights, attn_k_weights, attn_v_weights, attn_output_weights;
    std::vector<const std::uint8_t*> ffn_gate_weights, ffn_up_weights, ffn_down_weights;
    std::vector<const float*> ffn_gate_weights_fp, ffn_up_weights_fp, ffn_down_weights_fp;
    std::vector<const float*> attn_q_weights_fp, attn_k_weights_fp, attn_v_weights_fp, attn_output_weights_fp;
    std::vector<const float*> attn_norm_weights_fp, ffn_norm_weights_fp;
    std::vector<float> cos_cache, sin_cache;
    bool loaded_{false};
    bool tokenizer_loaded_{false};
    std::string architecture_name_;
    std::string chat_template_;
};
'''

with open('include/zen/dense_transformer_runtime.h', 'r') as f:
    content = f.read()

# Replace the entire class definition
import re
pattern = r'class DenseTransformerRuntime \{.*?\n\};'
new_class = '''class DenseTransformerRuntime {
public:
    bool load(const std::filesystem::path& path, std::string* error=nullptr);
    bool loaded() const noexcept { return loaded_; }
    bool tokenizer_available() const noexcept { return tokenizer_loaded_; }
    const RuntimeConfig& config() const noexcept { return config_; }
    const std::string& architecture_name() const noexcept { return architecture_name_; }
    const std::string& chat_template() const noexcept { return chat_template_; }
    bool generate(const std::vector<std::uint32_t>& prompt, std::uint32_t max_new_tokens,
                  Generation& result, std::string* error=nullptr,
                  const std::function<void(const std::vector<std::uint32_t>&)>& on_tokens={},
                  const GenerationOptions& options={}, const std::atomic<bool>* cancelled=nullptr) const;
    bool generate_speculative(const std::vector<std::uint32_t>& prompt, std::uint32_t max_new, const DenseTransformerRuntime& draft, std::uint32_t draft_tokens, Generation& result, std::string* error=nullptr, const std::function<void(const std::vector<std::uint32_t>&)>& on_tokens={}, const GenerationOptions& options={}, const std::atomic<bool>* cancelled=nullptr) const;
    bool tokenize(const std::string& text, std::vector<std::uint32_t>& ids) const;
    bool detokenize(const std::vector<std::uint32_t>& ids, std::string& text) const;
    bool generate_text(const std::string& prompt, std::uint32_t max_new_tokens,
                       Generation& result, std::string& text, std::string* error=nullptr,
                       const std::function<void(const std::string&)>& on_text={},
                       const GenerationOptions& options={}, const std::atomic<bool>* cancelled=nullptr) const;

    // Additional methods for pipeline support
    bool layer_is_recurrent(std::uint32_t layer) const noexcept;
    bool hadamard_folded(const char* suffix, std::size_t layer) const noexcept;
    bool forward_q35_batch(const std::vector<std::uint32_t>& tokens,
                           std::vector<std::vector<float>>& kc,
                           std::vector<std::vector<float>>& vc,
                           std::vector<std::vector<float>>& convc,
                           std::vector<std::vector<float>>& ssmc,
                           std::vector<float>& logits,
                           std::uint32_t start_pos) const;
    bool forward_q35_token(std::uint32_t token, std::uint32_t position,
                           std::vector<std::vector<float>>& kc,
                           std::vector<std::vector<float>>& vc,
                           std::vector<std::vector<float>>& convc,
                           std::vector<std::vector<float>>& ssmc,
                           std::vector<float>& logits,
                           std::uint32_t start_pos) const;
    bool forward_batch(const std::vector<std::uint32_t>& tokens,
                       std::vector<std::vector<float>>& kc,
                       std::vector<std::vector<float>>& vc,
                       std::vector<float>& logits,
                       std::uint32_t start_pos,
                       std::size_t tail_count,
                       std::vector<float>* tail_logits) const;
    bool forward(std::uint32_t token, std::uint32_t pos,
                 std::vector<std::vector<float>>& kc,
                 std::vector<std::vector<float>>& vc,
                 std::vector<float>& logits) const;

public:
    struct Tensor { std::vector<std::uint64_t> dims; std::vector<float> values; const std::uint8_t* raw{}; std::size_t elements{}; std::string name; };
    std::shared_ptr<MappedFile> mapping_;
    const std::uint8_t* data_{};
    std::size_t size_{};
    RuntimeConfig config_;
    bool loaded_{false};
    bool tokenizer_loaded_{false};
    std::string architecture_name_;
    std::string chat_template_;
    std::vector<std::vector<float>> kc, vc, attn;
    std::vector<std::vector<std::vector<float>>> k_cache, v_cache;
    std::vector<std::vector<float>> attn_norm_weights, ffn_norm_weights;
    std::vector<const std::uint8_t*> attn_q_weights, attn_k_weights, attn_v_weights, attn_output_weights;
    std::vector<const std::uint8_t*> ffn_gate_weights, ffn_up_weights, ffn_down_weights;
    std::vector<const std::uint8_t*> attn_q_weights_fp, attn_k_weights_fp, attn_v_weights_fp, attn_output_weights_fp;
    std::vector<const float*> attn_norm_weights_fp, ffn_norm_weights_fp;
    std::vector<float> cos_cache, sin_cache;
    bool loaded_{false};
    bool tokenizer_loaded_{false};
    std::string architecture_name_;
    std::string chat_template_;
};
'''

new_content = re.sub(r'class DenseTransformerRuntime \{.*?\n\};', new_class, content, flags=re.DOTALL)

with open('include/zen/dense_transformer_runtime.h', 'w') as f:
    f.write(new_content)

print('Header fixed!')