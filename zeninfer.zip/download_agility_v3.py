import urllib.request
import zipfile
import shutil
import subprocess
import tempfile
import os

# Try to download Agility SDK 1.620.1 or later which might include dxc with Work Graphs support
# The NuGet package Microsoft.Direct3D.D3D12 contains dxc in the build/native/bin folder

# Try version 1.620.1 (latest as of the NuGet page)
AGILITY_VERSIONS = [
    "1.620.1",
    "1.620.0",
    "1.619.6",
    "1.619.5",
    "1.619.4",
    "1.619.3",
    "1.619.2",
    "1.619.1",
    "1.619",
    "1.618.5",
    "1.618.4",
    "1.618.3",
    "1.618.2",
    "1.618.1",
    "1.618.0",
]

for version in AGILITY_VERSIONS:
    url = f"https://www.nuget.org/api/v2/package/Microsoft.Direct3D.D3D12/{version}"
    
    with tempfile.TemporaryDirectory() as tmpdir:
        nupkg_path = os.path.join(tmpdir, f"agility_{version}.nupkg")
        
        try:
            print(f"Trying Agility SDK {version}...")
            urllib.request.urlretrieve(f"https://www.nuget.org/api/v2/package/Microsoft.Direct3D.D3D12/{version}", 
                                       os.path.join(tmpdir, f"agility_{version}.nupkg"))
            print(f"  Downloaded {version}")
        except urllib.error.HTTPError as e:
            if e.code == 404:
                print(f"  Version {version} not found on NuGet")
                continue
            else:
                raise
        except Exception as e:
            print(f"  Download failed: {e}")
            continue
        
        # Extract and test
        extract_dir = os.path.join(tmpdir, "extract")
        os.makedirs(extract_dir)
        
        try:
            with zipfile.ZipFile(os.path.join(tmpdir, f"agility_{version}.nupkg"), 'r') as zf:
                zf.extractall(os.path.join(tmpdir, "extract"))
        except Exception as e:
            print(f"  Extract failed: {e}")
            continue
        
        # Find dxc.exe
        dxc_path = None
        for root, dirs, files in os.walk(extract_dir):
            for f in files:
                if f == "dxc.exe":
                    dxc_path = os.path.join(root, f)
                    break
            if dxc_path:
                break
        
        if dxc_path:
            print(f"  Found dxc.exe at: {dxc_path}")
            
            # Install
            install_dir = r"H:\llamadx\update\dxc_agility"
            if os.path.exists(install_dir):
                shutil.rmtree(install_dir)
            os.makedirs(install_dir, exist_ok=True)
            
            # Copy build/native folder
            native_dir = os.path.dirname(os.path.dirname(dxc_path))
            for root, dirs, files in os.walk(native_dir):
                for f in files:
                    src = os.path.join(root, f)
                    rel = os.path.relpath(src, extract_dir)
                    dst = os.path.join(install_dir, rel)
                    os.makedirs(os.path.dirname(dst), exist_ok=True)
                    shutil.copy2(src, dst)
            
            # Test
            dxc_exe = os.path.join(install_dir, "bin", "x64", "dxc.exe")
            if not os.path.exists(dxc_exe):
                for root, dirs, files in os.walk(install_dir):
                    if "dxc.exe" in files and "x64" in root:
                        dxc_exe = os.path.join(root, "dxc.exe")
                        break
            
            if os.path.exists(dxc_exe):
                result = subprocess.run([dxc_exe, "--version"], capture_output=True, text=True)
                print(f"  Version: {result.stdout.strip()}")
                
                result = subprocess.run([dxc_exe, "-help"], capture_output=True, text=True)
                if "enable-work-graph" in result.stdout:
                    print("  SUCCESS: -enable-work-graph flag found!")
                    print(f"  SUCCESS: Installed dxc with Work Graphs support from Agility SDK {version}")
                    exit(0)
                else:
                    print("  WARNING: -enable-work-graph flag NOT found")
                    print("  Help output sample:", result.stdout[:500])
        else:
            print("  dxc.exe not found in package")
        break