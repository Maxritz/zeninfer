with open('src/adapters/dense_transformer_runtime.cpp', 'r') as f:
    lines = f.readlines()

# Find the duplicate for loop (second occurrence)
first_for = -1
second_for = -1
for i, line in enumerate(lines):
    if 'for(std::uint32_t l=0;l<config_.layers;++l){' in line:
        if i+1 < len(lines) and 'const std::string p="blk."+std::to_string(l)+".";' in lines[i+1]:
            if first_for == -1:
                first_for = i
            else:
                second_for = i
                break

print(f'First for at line {first_for+1}, second at {second_for+1}')

# Find the end of the second for loop's else block (matching brace)
if second_for >= 0:
    brace = 0
    for i in range(second_for, len(lines)):
        for ch in lines[i]:
            if ch == '{':
                brace += 1
            elif ch == '}':
                brace -= 1
        if brace == 0:
            print(f'Second block ends at line {i+1}')
            # Delete from second_for to i (inclusive)
            new_lines = lines[:second_for] + lines[i+1:]
            with open('src/adapters/dense_transformer_runtime.cpp', 'w') as f:
                f.writelines(new_lines)
            print(f'Deleted lines {second_for+1} to {i+1}')
            break