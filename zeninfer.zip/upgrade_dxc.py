#!/usr/bin/env python3
"""
Download and install dxc 1.8.2411+ with Work Graphs and DP4a support.
This script downloads the Microsoft DirectXShaderCompiler release.
"""
import os
import sys
import urllib.request
import zipfile
import shutil
import subprocess
import tempfile

DXC_VERSION = "1.8.2411.5"  # Known version with Work Graphs support
# Alternative: v1.8.2411.5 or v1.8.2411.7
# Check https://github.com/microsoft/DirectXShaderCompiler/releases

DXC_URL = f"https://github.com/microsoft/DirectXShaderCompiler/releases/download/v{DXC_VERSION}/dxc_{DXC_VERSION}.zip"

def download_dxc():
    """Download and extract dxc with Work Graphs support."""
    print(f"Downloading dxc {DXC_VERSION}...")
    
    with tempfile.TemporaryDirectory() as tmpdir:
        zip_path = os.path.join(tmpdir, "dxc.zip")
        
        # Download
        print(f"Downloading from {DXC_URL}")
        urllib.request.urlretrieve(DXC_URL, zip_path)
        
        # Extract
        extract_dir = os.path.join(tmpdir, "dxc")
        with zipfile.ZipFile(zip_path, 'r') as zf:
            zf.extractall(extract_dir)
        
        # Find dxc.exe
        dxc_path = None
        for root, dirs, files in os.walk(extract_dir):
            for f in files:
                if f == "dxc.exe":
                    dxc_path = os.path.join(root, f)
                    break
            if dxc_path:
                break
        
        if not dxc_path:
            print("ERROR: dxc.exe not found in archive")
            return False
        
        # Install to H:\llamadx\dxc_new
        install_dir = r"H:\llamadx\dxc_new"
        os.makedirs(install_dir, exist_ok=True)
        
        # Copy all files
        for root, dirs, files in os.walk(extract_dir):
            for f in files:
                src = os.path.join(root, f)
                rel = os.path.relpath(src, extract_dir)
                dst = os.path.join(install_dir, rel)
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                shutil.copy2(src, dst)
        
        print(f"Installed dxc to {install_dir}")
        
        # Test
        result = subprocess.run([os.path.join(install_dir, "bin", "x64", "dxc.exe"), "--version"], 
                               capture_output=True, text=True)
        print(f"Version: {result.stdout.strip()}")
        
        # Test Work Graphs support
        result = subprocess.run([os.path.join(install_dir, "bin", "x64", "dxc.exe"), "-help"], 
                               capture_output=True, text=True)
        if "enable-work-graph" in result.stdout:
            print("SUCCESS: -enable-work-graph flag found!")
        else:
            print("WARNING: -enable-work-graph flag NOT found")
        
        return True

if __name__ == "__main__":
    if download_dxc():
        print("\nSUCCESS: dxc with Work Graphs support installed!")
        print("Add H:\\llamadx\\dxc_new\\bin\\x64 to PATH or set ZEN_DXC_DIR")
    else:
        print("FAILED")
        sys.exit(1)