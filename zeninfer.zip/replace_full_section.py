with open('src/adapters/dense_transformer_runtime.cpp', 'r') as f:
    content = f.read()

# Find the exact section to replace
# Start: "// Try to run all layers through the GPU pipeline (single submit+wait for all layers)"
# End: the closing of the else block that starts with "} else {" after "if(all_layers_qualify) {"

import re

# Find start
start_marker = "// Try to run all layers through the GPU pipeline (single submit+wait for all layers)"
start_idx = content.find(start_marker)
if start_idx == -1:
    print("Start marker not found!")
    exit(1)

# Find the end - look for "if(all_layers_qualify) {" then find its matching else block end
qualify_idx = content.find("if(all_layers_qualify) {", start_idx)
if qualify_idx == -1:
    print("Qualify block not found!")
    exit(1)

# Find the matching else block end
brace = 0
in_else = False
end_idx = -1
for i in range(qualify_idx, len(content)):
    ch = content[i]
    if ch == '{':
        brace += 1
    elif ch == '}':
        brace -= 1
        if brace == 0 and in_else:
            end_idx = i + 1
            break
    if not in_else and content[i:i+6] == "} else":
        in_else = True

if end_idx == -1:
    print("End not found!")
    exit(1)

print(f"Replacing from {start_idx} to {end_idx}")

# Read replacement
with open('pipeline_fix_segment.cpp', 'r') as f:
    replacement = f.read()

# The replacement should end with the per-layer for loop start
# But we need to keep the rest of the per-layer code
# Actually, the replacement already includes the for loop start
# So we replace from start_idx to end_idx

new_content = content[:start_idx] + replacement + content[end_idx:]

with open('src/adapters/dense_transformer_runtime.cpp', 'w') as f:
    f.write(new_content)

print("Replacement done!")

# Verify brace balance
open_braces = 0
for i, ch in enumerate(new_content):
    if ch == '{':
        open_braces += 1
    elif ch == '}':
        open_braces -= 1
        if open_braces < 0:
            print(f"ERROR: Extra }} at position {i}")
            break
print(f"Final open braces: {open_braces}")