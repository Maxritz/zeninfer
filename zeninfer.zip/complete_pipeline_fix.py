with open('src/adapters/dense_transformer_runtime.cpp', 'r') as f:
    lines = f.readlines()

# The exact structure to modify:
# Line 1188: pipeline_layers.reserve(config_.layers);
# Line 1190-1215: for loop with qualification
# Line 1218: if(all_layers_qualify && pipeline_layers.size() == config_.layers) {
# Line 1228-1247: pipeline execution with inner if/else
# Line 1248: }  // closes first if
# Line 1250: if(all_layers_qualify) {
# Line 1251: // Pipeline succeeded, skip per-layer path
# Line 1252: } else {
# Line 1253: for(...) {
# Line 1490: }  // closes for
# Line 1491: }  // closes else
# Line 1492: }  // closes if? No, the if at 1250 was closed at 1491

# Changes needed:
# 1. Add layer_qualifies vector after line 1188
# 2. In qualification loop (lines 1190-1215), set layer_qualifies[l] = true/false
# 3. Change line 1218 condition
# 4. Remove all_layers_qualify modifications inside pipeline block
# 4. Change line 1250 to run per-layer but skip qualifying layers
# 5. Remove the "else" at line 1252 (since we always run per-layer now)

# 1. Add layer_qualifies after pipeline_layers.reserve
for i, line in enumerate(lines):
    if 'pipeline_layers.reserve(config_.layers);' in line:
        lines.insert(i+1, '    std::vector<bool> layer_qualifies(config_.layers, false);\n')
        print(f"1. Added layer_qualifies at line {i+2}")
        break

# 2. Add layer_qualifies[l] = true in qualification success
for i, line in enumerate(lines):
    if 'pipeline_layers.push_back(std::move(lp));' in line and 'layer_qualifies' not in lines[i+1]:
        lines.insert(i+1, '            layer_qualifies[l] = true;\n')
        print(f"2. Added layer_qualifies[l]=true at line {i+2}")
        break

# 3. Add layer_qualifies[l] = false in qualification failure
for i, line in enumerate(lines):
    if 'all_layers_qualify = false;' in line and 'layer_qualifies' not in lines[i+1]:
        # Verify this is in qualification loop (check context)
        if i > 0 and lines[i-1].strip() == '} else {':
            # Check we're in the for loop by looking for the for loop start
            in_for = False
            for j in range(i, max(0, i-20), -1):
                if 'for(std::uint32_t l=0;l<config_.layers;++l){' in lines[j]:
                    in_for = True
                    break
            if in_for:
                lines[i] = '            all_layers_qualify = false;\n            layer_qualifies[l] = false;\n'
                print(f"3. Added layer_qualifies[l]=false at line {i+1}")
                break

# 4. Change pipeline condition at line 1218
for i, line in enumerate(lines):
    if 'if(all_layers_qualify && pipeline_layers.size() == config_.layers)' in line:
        lines[i] = '    // Run pipeline for any qualifying layers (not requiring all)\n    if(!pipeline_layers.empty()) {\n'
        print(f"4. Changed pipeline condition at line {i+1}")
        break

# 5. Remove all_layers_qualify = false inside pipeline block (line 1236)
for i, line in enumerate(lines):
    if 'all_layers_qualify = false;' in line and 'Pipeline failed' in lines[i+2]:
        lines[i] = '            // all_layers_qualify no longer used for pipeline gating\n'
        print(f"5. Removed all_layers_qualify=false at line {i+1}")
        break

# 6. Remove the "Also log when not all layers qualify" block (lines 1243-1247)
for i, line in enumerate(lines):
    if 'Also log when not all layers qualify' in line:
        # Delete lines i through i+4 (5 lines)
        for _ in range(5):
            if i < len(lines):
                lines.pop(i)
        print(f"6. Removed 'not all qualify' log block at line {i+1}")
        break

# 7. Change the second if (line 1250) to always run per-layer but skip qualifying
for i, line in enumerate(lines):
    if line.strip() == 'if(all_layers_qualify) {' and 'Pipeline succeeded' in lines[i+1]:
        lines[i] = '    // Per-layer path for non-qualifying layers\n    for(std::uint32_t l=0;l<config_.layers;++l){\n        if (layer_qualifies[l]) continue; // Skip layers already processed by pipeline\n'
        # Remove next line "// Pipeline succeeded, skip per-layer path"
        if 'Pipeline succeeded' in lines[i+1]:
            lines[i+1] = ''
        print(f"7. Modified per-layer loop at line {i+1}")
        break

# 8. Remove the "} else {" at line 1252 (now should be just "} else {")
# The old structure: if(all_layers_qualify) { } else { for... }
# New structure: for(...) { if(layer_qualifies) continue; ... }
# So we need to remove the "} else {" and the corresponding closing brace
for i, line in enumerate(lines):
    if line.strip() == '} else {' and 'Whole layer in one device submission' in lines[i+1]:
        lines[i] = ''  # Remove this line
        print(f"8. Removed }} else {{ at line {i+1}")
        break

# 9. The for loop now starts directly, but we need to remove one extra closing brace at the end
# The old structure had: } else { for(...) { ... } }  -> two closing braces
# New structure: for(...) { if(...) continue; ... }  -> one closing brace
# So we need to remove one extra closing brace
# Find the closing brace that matches the removed "else"
# It should be around line 1491 originally
# After our changes, there will be one extra }
# Let's find and remove one extra } that doesn't have matching {

# Actually, the structure now is:
# if(!pipeline_layers.empty()) { pipeline }  // closes at }
# for(layers) { if(layer_qualifies) continue; ... }  // closes at }
# So we need exactly two closing braces at the end of this section
# The original had three: } (pipeline if) + } (else) + } (for)
# Now we need two: } (pipeline if) + } (for)
# So we should be fine!

with open('src/adapters/dense_transformer_runtime.cpp', 'w') as f:
    f.writelines(lines)

print("All changes applied!")

# Verify brace balance
open_braces = 0
for i, line in enumerate(lines):
    for ch in line:
        if ch == '{':
            open_braces += 1
        elif ch == '}':
            open_braces -= 1
            if open_braces < 0:
                print(f"ERROR: Extra }} at line {i+1}: {line.strip()[:80]}")
                break
print(f"Final open braces: {open_braces}")