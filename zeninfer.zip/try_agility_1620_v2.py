import urllib.request
import zipfile
import shutil
import subprocess
import tempfile
import os

AGILITY_VERSION = "1.620.1"

with tempfile.TemporaryDirectory() as tmpdir:
    nupkg_path = os.path.join(tmpdir, f"agility_{AGILITY_VERSION}.nupkg")
    
    try:
        print(f"Downloading Agility SDK {AGILITY_VERSION} from NuGet...")
        urllib.request.urlretrieve(f"https://www.nuget.org/api/v2/package/Microsoft.Direct3D.D3D12/{AGILITY_VERSION}", 
                                   os.path.join(tmpdir, f"agility_{AGILITY_VERSION}.nupkg"))
        print("Downloaded successfully")
    except urllib.error.HTTPError as e:
        if e.code == 404:
            print(f"Version {AGILITY_VERSION} not found on NuGet")
        else:
            raise
    except Exception as e:
        print(f"Download failed: {e}")
        exit(1)
    
    # Extract and test
    extract_dir = os.path.join(tmpdir, "extract")
    os.makedirs(extract_dir)
    
    with zipfile.ZipFile(os.path.join(tmpdir, f"agility_{AGILITY_VERSION}.nupkg"), 'r') as zf:
        zf.extractall(extract_dir)
    
    # Find dxc.exe
    dxc_path = None
    for root, dirs, files in os.walk(extract_dir):
        for f in files:
            if f == "dxc.exe":
                dxc_path = os.path.join(root, f)
                break
        if dxc_path:
            break
    
    if dxc_path:
        print(f"Found dxc.exe at: {dxc_path}")
        
        # Install
        install_dir = r"H:\llamadx\dxc_agility"
        if os.path.exists(install_dir):
            shutil.rmtree(install_dir)
        os.makedirs(install_dir, exist_ok=True)
        
        # Copy build/native folder
        native_dir = os.path.dirname(os.path.dirname(dxc_path))
        for root, dirs, files in os.walk(native_dir):
            for f in files:
                src = os.path.join(root, f)
                rel = os.path.relpath(src, extract_dir)
                dst = os.path.join(install_dir, rel)
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                shutil.copy2(src, dst)
        
        # Test
        dxc_exe = os.path.join(install_dir, "bin", "x64", "dxc.exe")
        if not os.path.exists(dxc_exe):
            for root, dirs, files in os.walk(install_dir):
                if "dxc.exe" in files:
                    dxc_exe = os.path.join(root, "dxc.exe")
                    break
        
        if os.path.exists(dxc_exe):
            result = subprocess.run([dxc_exe, "--version"], capture_output=True, text=True)
            print(f"Version: {result.stdout.strip()}")
            
            result = subprocess.run([dxc_exe, "-help"], capture_output=True, text=True)
            if "enable-work-graph" in result.stdout:
                print("SUCCESS: -enable-work-graph flag found!")
            else:
                print("WARNING: -enable-work-graph flag NOT found")
                print("Help output sample:", result.stdout[:500])
        else:
            print("dxc.exe not found after install")
else:
    print("dxc.exe not found in package")