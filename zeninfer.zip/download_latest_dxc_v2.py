import urllib.request
import json
import zipfile
import shutil
import subprocess
import tempfile
import os

# Use the latest release v1.9.2609
url = "https://api.github.com/repos/microsoft/DirectXShaderCompiler/releases/tags/v1.9.2609"

with urllib.request.urlopen(urllib.request.Request(url, headers={'Accept': 'application/vnd.github.v3+json'})) as response:
    data = json.load(response)
    print(f"Release: {data.get('name')}")
    print(f"Assets: {len(data.get('assets', []))}")
    for asset in data.get('assets', []):
        print(f"  {asset['name']} - {asset['browser_download_url']}")

# Download the Windows zip
for asset in data.get('assets', []):
    if 'windows' in asset['name'].lower() or asset['name'].endswith('.zip'):
        if not 'linux' in asset['name'].lower() and not 'pdb' in asset['name'].lower():
            print(f"\nDownloading {asset['name']}...")
            try:
                with tempfile.TemporaryDirectory() as tmpdir:
                    zip_path = os.path.join(tmpdir, asset['name'])
                    urllib.request.urlretrieve(asset['browser_download_url'], zip_path)
                    print("Downloaded")
                    
                    extract_dir = os.path.join(tmpdir, "extract")
                    os.makedirs(extract_dir)
                    
                    with zipfile.ZipFile(zip_path, 'r') as zf:
                        zf.extractall(extract_dir)
                    
                    # Find dxc.exe
                    dxc_path = None
                    for root, dirs, files in os.walk(extract_dir):
                        for f in files:
                            if f == "dxc.exe":
                                dxc_path = os.path.join(root, f)
                                break
                        if dxc_path:
                            break
                    
                    if dxc_path:
                        print(f"Found dxc.exe at: {dxc_path}")
                        
                        # Install
                        install_dir = r"H:\llamadx\dxc_github"
                        if os.path.exists(install_dir):
                            shutil.rmtree(install_dir)
                        os.makedirs(install_dir, exist_ok=True)
                        
                        # Copy all files
                        for root, dirs, files in os.walk(extract_dir):
                            for f in files:
                                src = os.path.join(root, f)
                                rel = os.path.relpath(src, extract_dir)
                                dst = os.path.join(install_dir, rel)
                                os.makedirs(os.path.dirname(dst), exist_ok=True)
                                shutil.copy2(src, dst)
                        
                        # Test
                        dxc_exe = os.path.join(install_dir, "bin", "x64", "dxc.exe")
                        if not os.path.exists(dxc_exe):
                            for root, dirs, files in os.walk(install_dir):
                                if "dxc.exe" in files:
                                    dxc_exe = os.path.join(root, "dxc.exe")
                                    break
                    
                        if os.path.exists(dxc_exe):
                            result = subprocess.run([dxc_exe, "--version"], capture_output=True, text=True)
                            print(f"Version: {result.stdout.strip()}")
                            
                            result = subprocess.run([dxc_exe, "-help"], capture_output=True, text=True)
                            if "enable-work-graph" in result.stdout:
                                print("SUCCESS: -enable-work-graph flag found!")
                            else:
                                print("WARNING: -enable-work-graph flag NOT found")
                                print("Help output sample:", result.stdout[:500])
                            exit(0)
            except Exception as e:
                print(f"Failed: {e}")
                continue

print("All attempts failed")