with open('src/adapters/dense_transformer_runtime.cpp', 'r') as f:
    content = f.read()

# Find the for loop
search_start = content.find('for(std::size_t t=0;t<T;++t){', 75648)
print('for loop at:', search_start)

# Find all occurrences of }} after the for loop
pos = search_start
for i in range(20):
    pos = content.find('}}', pos + 1)
    if pos == -1:
        break
    context = content[max(0,pos-50):pos+50]
    print(f'Match {i}: pos={pos}')
    print(f'  Context: {context}')
    print()