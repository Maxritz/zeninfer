#!/usr/bin/env python3
"""
Surgical pipeline hybrid fix using brace-aware line editing.
Maintains perfect brace balance by tracking nesting level.
"""

with open('src/adapters/dense_transformer_runtime.cpp', 'r') as f:
    lines = f.readlines()

# First, let's map out the brace structure around the target region
brace_level = 0
target_region_start = -1
target_region_end = -1

for i, line in enumerate(lines):
    for ch in line:
        if ch == '{':
            brace_level += 1
        elif ch == '}':
            brace_level -= 1
    
    # Find the qualification loop start
    if 'pipeline_layers.reserve(config_.layers);' in line:
        target_region_start = i
    
    # Find the end of the outer if/else block (brace_level returns to 1)
    if target_region_start != -1 and brace_level == 1 and i > target_region_start + 500:
        # Check if this is the closing of the main forward_batch function section
        if '}' in line and target_region_end == -1:
            target_region_end = i
            break

print(f"Target region: lines {target_region_start+1} to {target_region_end+1}")

# Now let's make targeted changes WITHIN this region
# We'll build new lines for the modified section

# Read the replacement content
with open('pipeline_fix_segment.cpp', 'r') as f:
    replacement = f.read().rstrip('\n')
replacement_lines = replacement.split('\n')

# The strategy: replace from "pipeline_layers.reserve" to just before "if(all_layers_qualify)"
# But we need to be very precise about braces.

# Let's find exact line numbers for the boundaries
start_line = -1
end_line = -1
brace_level = 0

for i, line in enumerate(lines):
    for ch in line:
        if ch == '{':
            brace_level += 1
        elif ch == '}':
            brace_level -= 1
    
    if 'pipeline_layers.reserve(config_.layers);' in line:
        start_line = i
    
    # The end is the line BEFORE "if(all_layers_qualify) {" at brace_level 1
    if 'if(all_layers_qualify) {' in line and 'Pipeline succeeded' in lines[i+1] and brace_level == 1:
        end_line = i - 1
        break

print(f"Replace lines {start_line+1} to {end_line+1}")

# Verify the section we're replacing
print("=== ORIGINAL SECTION ===")
for i in range(start_line, min(end_line+1, start_line+50)):
    print(f"{i+1}: {lines[i].rstrip()}")

# Now create the new section
# We need to replace from start_line to end_line with our new logic
# The new logic should:
# 1. Add layer_qualifies declaration
# 2. Track qualification per layer
# 3. Run pipeline for qualifying segments
# 4. Skip qualifying layers in per-layer loop

new_section = [
    '    std::vector<LayerParams> pipeline_layers;',
    '    pipeline_layers.reserve(config_.layers);',
    '    std::vector<bool> layer_qualifies(config_.layers, false);',
    '',
    '    for(std::uint32_t l=0;l<config_.layers;++l){',
    '        const std::string p="blk."+std::to_string(l)+".";',
    '        const auto* lq=tensor(p+"attn_q.weight");const auto* lk=tensor(p+"attn_k.weight");',
    '        const auto* lv=tensor(p+"attn_v.weight");const auto* lo=tensor(p+"attn_output.weight");',
    '        const auto* lg=tensor(p+"ffn_gate.weight");const auto* lu=tensor(p+"ffn_up.weight");',
    '        const auto* ldw=tensor(p+"ffn_down.weight");',
    '        const auto* ln=tensor(p+"attn_norm.weight");const auto* lfn=tensor(p+"ffn_norm.weight");',
    '        if(!config_.use_alibi&&!config_.bitnet_variant&&lq&&lk&&lv&&lo&&lg&&lu&&ldw&&ln&&lfn',
    '           &&lq->raw&&lk->raw&&lv->raw&&lo->raw&&lg->raw&&lu->raw&&ldw->raw',
    '           &&!tensor(p+"attn_q.bias")&&!tensor(p+"attn_k.bias")&&!tensor(p+"attn_v.bias")',
    '           &&!tensor(p+"attn_q_norm.weight")',
    '           &&device_attention_available(config_.layers,kc[l].size()/KW,KH,D,config_.rms_epsilon)){',
    '            // Qualifies for pipeline',
    '            LayerParams lp;',
    '            lp.q_w = lq->raw; lp.k_w = lk->raw; lp.v_w = lv->raw; lp.o_w = lo->raw;',
    '            lp.gate_w = lg->raw; lp.up_w = lu->raw; lp.down_w = ldw->raw;',
    '            lp.attn_norm_w = ln->values.data(); lp.ffn_norm_w = lfn->values.data();',
    '            lp.layer = l; lp.pos = pos;',
    '            lp.first_pos = config_.sliding_window&&pos+1>config_.sliding_window?pos+1-config_.sliding_window:0;',
    '            rope_table(config_.rope_dim,pos,config_.rope_base,config_.rope_scaling_type,config_.rope_scaling_factor,config_.rope_original_context,config_.rope_low_freq_factor,config_.rope_high_freq_factor,config_.rope_yarn_beta_fast,config_.rope_yarn_beta_slow,lp.cos,lp.sin);',
    '            lp.pairs = lp.cos.size();',
    '            pipeline_layers.push_back(std::move(lp));',
    '            layer_qualifies[l] = true;',
    '        } else {',
    '            all_layers_qualify = false;',
    '            layer_qualifies[l] = false;',
    '        }',
    '    }',
    '',
    '    // Run pipeline for any qualifying layers (not requiring all)',
    '    if(!pipeline_layers.empty()) {',
    '        bool any_pipeline_ok = false;',
    '        std::size_t pipeline_start = 0;',
    '        while (pipeline_start < config_.layers) {',
    '            // Find next qualifying layer',
    '            while (pipeline_start < config_.layers && !layer_qualifies[pipeline_start]) {',
    '                ++pipeline_start;',
    '            }',
    '            if (pipeline_start >= config_.layers) break;',
    '            ',
    '            // Find end of contiguous qualifying segment',
    '            std::size_t pipeline_end = pipeline_start;',
    '            while (pipeline_end < config_.layers && layer_qualifies[pipeline_end]) {',
    '                ++pipeline_end;',
    '            }',
    '            ',
    '            // Run pipeline for layers [pipeline_start, pipeline_end)',
    '            std::size_t segment_size = pipeline_end - pipeline_start;',
    '            zen::d3d12::LayerDecodeParams d3d_layers[64];',
    '            for(std::size_t i=0;i<segment_size;++i){',
    '                auto& lp = pipeline_layers[pipeline_start + i];',
    '                d3d_layers[i].q_w = lp.q_w; d3d_layers[i].k_w = lp.k_w; d3d_layers[i].v_w = lp.v_w; d3d_layers[i].o_w = lp.o_w;',
    '                d3d_layers[i].gate_w = lp.gate_w; d3d_layers[i].up_w = lp.up_w; d3d_layers[i].down_w = lp.down_w;',
    '                d3d_layers[i].attn_norm_w = lp.attn_norm_w; d3d_layers[i].ffn_norm_w = lp.ffn_norm_w;',
    '                d3d_layers[i].cos = lp.cos.data(); d3d_layers[i].sin = lp.sin.data();',
    '                d3d_layers[i].pairs = lp.pairs; d3d_layers[i].layer = lp.layer; d3d_layers[i].pos = lp.pos; d3d_layers[i].first_pos = lp.first_pos;',
    '            }',
    '            bool segment_ok = zen::d3d12::layer_decode_pipeline(d3d_layers, segment_size, x.data(), x.data(), E, H, KH, D, F, config_.rms_epsilon);',
    '            if (segment_ok) {',
    '                any_pipeline_ok = true;',
    '                if (const char* trace = std::getenv("ZEN_D3D12_TRACE"); trace && trace[0] == \'1\') {',
    '                    std::printf("[d3d12] pipeline: SUCCESS segment layers [%zu, %zu) for token pos=%zu\\n", pipeline_start, pipeline_end, pos);',
    '                }',
    '            } else {',
    '                if (const char* trace = std::getenv("ZEN_D3D12_TRACE"); trace && trace[0] == \'1\') {',
    '                    std::printf("[d3d12] pipeline: FALLBACK segment layers [%zu, %zu) for token pos=%zu\\n", pipeline_start, pipeline_end, pos);',
    '                }',
    '                // If pipeline fails for a segment, mark those layers as non-qualifying',
    '                for (std::size_t l = pipeline_start; l < pipeline_end; ++l) {',
    '                    layer_qualifies[l] = false;',
    '                }',
    '            }',
    '            ',
    '            pipeline_start = pipeline_end;',
    '        }',
    '    }',
    '',
    '    // Per-layer path for non-qualifying layers',
    '    for(std::uint32_t l=0;l<config_.layers;++l){',
    '        if (layer_qualifies[l]) continue; // Skip layers already processed by pipeline',
]

# Replace the section
new_lines = lines[:start_line] + [line + '\n' for line in new_section] + lines[end_line+1:]

# Now we need to remove the old "if(all_layers_qualify) { ... } else { ... }" block
# Find it in the new lines
brace_level = 0
second_if_start = -1
second_if_end = -1

for i, line in enumerate(new_lines):
    for ch in line:
        if ch == '{':
            brace_level += 1
        elif ch == '}':
            brace_level -= 1
    
    if 'if(all_layers_qualify) {' in line and 'Pipeline succeeded' in new_lines[i+1] if i+1 < len(new_lines) else False:
        second_if_start = i
    
    if second_if_start != -1 and brace_level == 0 and i > second_if_start:
        second_if_end = i
        break

print(f"Second if block: lines {second_if_start+1} to {second_if_end+1}")

if second_if_start != -1 and second_if_end != -1:
    # Remove the entire if/else block
    final_lines = new_lines[:second_if_start] + new_lines[second_if_end+1:]
else:
    final_lines = new_lines

# Verify brace balance
open_braces = 0
for i, line in enumerate(final_lines):
    for ch in line:
        if ch == '{':
            open_braces += 1
        elif ch == '}':
            open_braces -= 1
            if open_braces < 0:
                print(f"ERROR: Extra }} at line {i+1}: {line.strip()[:80]}")
                break

print(f"Final open braces: {open_braces}")

with open('src/adapters/dense_transformer_runtime.cpp', 'w') as f:
    f.writelines(line + '\n' for line in final_lines)

print("Done!")