import urllib.request
import zipfile
import shutil
import subprocess
import tempfile
import os

# Try the mesh-nodes-preview which might have Work Graphs support
url = "https://github.com/microsoft/DirectXShaderCompiler/releases/download/v1.8.2405-mesh-nodes-preview/dxc_mesh_nodes_preview_2024_07_17.zip"

with tempfile.TemporaryDirectory() as tmpdir:
    zip_path = os.path.join(tmpdir, "dxc.zip")
    
    try:
        print(f"Downloading dxc mesh-nodes-preview from GitHub...")
        urllib.request.urlretrieve(url, zip_path)
        print("Downloaded successfully")
    except urllib.error.HTTPError as e:
        if e.code == 404:
            print(f"Version not found on GitHub releases")
            exit(1)
        else:
            raise
    except Exception as e:
        print(f"Download failed: {e}")
        exit(1)
    
    # Extract and test
    extract_dir = os.path.join(tmpdir, "extract")
    os.makedirs(extract_dir)
    
    with zipfile.ZipFile(zip_path, 'r') as zf:
        zf.extractall(extract_dir)
    
    # Find ALL dxc.exe files
    dxc_paths = []
    for root, dirs, files in os.walk(extract_dir):
        for f in files:
            if f == "dxc.exe":
                dxc_paths.append(os.path.join(root, f))
    
    print(f"Found {len(dxc_paths)} dxc.exe files:")
    for p in dxc_paths:
        print(f"  {p}")
    
    # Test each one
    for dxc_path in dxc_paths:
        print(f"\nTesting {dxc_path}:")
        result = subprocess.run([dxc_path, "--version"], capture_output=True, text=True)
        print(f"  Version: {result.stdout.strip()}")
        
        result = subprocess.run([dxc_path, "-help"], capture_output=True, text=True)
        if "enable-work-graph" in result.stdout:
            print("  SUCCESS: -enable-work-graph flag found!")
        else:
            print("  WARNING: -enable-work-graph flag NOT found")