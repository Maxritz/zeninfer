import urllib.request
import zipfile
import shutil
import subprocess
import tempfile
import os

# Check if dxc is in a different folder structure in the NuGet package
# Let's look at the package structure

for version in ["1.620.1", "1.620.0", "1.619.6", "1.619.5", "1.619.4", "1.619.3"]:
    url = f"https://www.nuget.org/api/v2/package/Microsoft.Direct3D.D3D12/{version}"
    
    with tempfile.TemporaryDirectory() as tmpdir:
        nupkg_path = os.path.join(tmpdir, f"agility_{version}.nupkg")
        
        try:
            print(f"Trying Agility SDK {version}...")
            urllib.request.urlretrieve(f"https://www.nuget.org/api/v2/package/Microsoft.Direct3D.D3D12/{version}", 
                                       os.path.join(tmpdir, f"agility_{version}.nupkg"))
            print(f"  Downloaded {version}")
        except urllib.error.HTTPError as e:
            if e.code == 404:
                print(f"  Version {version} not found on NuGet")
                continue
            else:
                raise
        except Exception as e:
            print(f"  Download failed: {e}")
            continue
        
        # Extract and look at structure
        extract_dir = os.path.join(tmpdir, "extract")
        os.makedirs(extract_dir)
        
        with zipfile.ZipFile(os.path.join(tmpdir, f"agility_{version}.nupkg"), 'r') as zf:
            zf.extractall(extract_dir)
        
        # List all files
        print(f"  Package contents:")
        for root, dirs, files in os.walk(extract_dir):
            for f in files:
                if f.endswith(('.exe', '.dll', '.h', '.lib')):
                    rel = os.path.relpath(os.path.join(root, f), extract_dir)
                    print(f"  {rel}")
        
        # Check for dxc
        dxc_found = False
        for root, dirs, files in os.walk(extract_dir):
            for f in files:
                if f == "dxc.exe":
                    print(f"  FOUND dxc.exe at: {os.path.join(root, f)}")
                    dxc_found = True
                    break
        if dxc_found:
            break