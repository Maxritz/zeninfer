with open('src/adapters/dense_transformer_runtime.cpp', 'rb') as f:
    content = f.read()

# Find the printf line
idx = content.find(b'std::printf("[d3d12] batched kv append')
if idx >= 0:
    print(f'Found at byte {idx}')
    print(repr(content[idx:idx+200]))