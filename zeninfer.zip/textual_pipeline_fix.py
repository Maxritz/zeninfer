with open('src/adapters/dense_transformer_runtime.cpp', 'r') as f:
    content = f.read()

# Make ONLY textual changes that don't affect brace structure

# 1. Add layer_qualifies declaration after pipeline_layers.reserve
old1 = '    std::vector<LayerParams> pipeline_layers;\n    pipeline_layers.reserve(config_.layers);'
new1 = '    std::vector<LayerParams> pipeline_layers;\n    pipeline_layers.reserve(config_.layers);\n    std::vector<bool> layer_qualifies(config_.layers, false);'
content = content.replace(old1, new1)
print("1. Added layer_qualifies declaration")

# 2. Add layer_qualifies[l] = true after pipeline_layers.push_back
old2 = '            pipeline_layers.push_back(std::move(lp));\n        } else {'
new2 = '            pipeline_layers.push_back(std::move(lp));\n            layer_qualifies[l] = true;\n        } else {'
content = content.replace(old2, new2)
print("2. Added layer_qualifies[l]=true")

# 3. Add layer_qualifies[l] = false in the else branch
old3 = '            all_layers_qualify = false;\n        }'
new3 = '            all_layers_qualify = false;\n            layer_qualifies[l] = false;\n        }'
# Only replace the one in the qualification loop (has 12 spaces indent)
content = content.replace('            all_layers_qualify = false;\n        }\n    }\n\n    // If all layers qualify', 
                          '            all_layers_qualify = false;\n            layer_qualifies[l] = false;\n        }\n    }\n\n    // If all layers qualify')
print("3. Added layer_qualifies[l]=false")

# 4. Change pipeline condition
old4 = 'if(all_layers_qualify && pipeline_layers.size() == config_.layers) {'
new4 = '// Run pipeline for any qualifying layers (not requiring all)\n    if(!pipeline_layers.empty()) {'
content = content.replace(old4, new4)
print("4. Changed pipeline condition")

# 5. Remove all_layers_qualify = false inside pipeline block
old5 = '            all_layers_qualify = false;\n            if (const char* trace = std::getenv("ZEN_D3D12_TRACE"); trace && trace[0] == \'1\') {'
new5 = '            // all_layers_qualify no longer used for pipeline gating\n            if (const char* trace = std::getenv("ZEN_D3D12_TRACE"); trace && trace[0] == \'1\') {'
content = content.replace(old5, new5)
print("5. Removed all_layers_qualify=false in pipeline block")

# 6. Remove the "Also log when not all layers qualify" block
old6 = '''        }
        
        // Also log when not all layers qualify
        if (!all_layers_qualify && pipeline_layers.size() < config_.layers) {
            if (const char* trace = std::getenv("ZEN_D3D12_TRACE"); trace && trace[0] == '1') {
                std::printf("[d3d12] pipeline: NOT ALL QUALIFY pipeline_layers=%zu vs config_.layers=%zu\\n", pipeline_layers.size(), config_.layers);
            }
        }
    }'''
new6 = '''        }
    }'''
content = content.replace(old6, new6)
print("6. Removed 'not all qualify' log block")

# 7. Change the second if to always run per-layer but skip qualifying
old7 = '''    if(all_layers_qualify) {
        // Pipeline succeeded, skip per-layer path
    } else {
        for(std::uint32_t l=0;l<config_.layers;++l){
        const std::string p="blk."+std::to_string(l)+".";'''
new7 = '''    // Per-layer path for non-qualifying layers
    for(std::uint32_t l=0;l<config_.layers;++l){
        if (layer_qualifies[l]) continue; // Skip layers already processed by pipeline
        const std::string p="blk."+std::to_string(l)+".";'''
content = content.replace(old7, new7)
print("7. Changed per-layer loop to skip qualifying layers")

# 8. Remove the "} else {" before the per-layer loop
# The old code has: } else { for(...) {
# We need to remove the "} else {" but keep the for loop
old8 = '''    }
    } else {
        for(std::uint32_t l=0;l<config_.layers;++l){
        const std::string p="blk."+std::to_string(l)+".";'''
# This won't match because we already changed it in step 7

# Actually, after step 7, the structure should be:
#     }
#     // Per-layer path for non-qualifying layers
#     for(std::uint32_t l=0;l<config_.layers;++l){
#         if (layer_qualifies[l]) continue; // Skip layers already processed by pipeline
#         const std::string p="blk."+std::to_string(l)+".";

# The original had two closing braces: one for the first if, one for the else
# Now we only need one closing brace for the first if
# The second closing brace (for the else) should be removed

# Find and remove one extra "}" that was for the else block
# The original ends with: } else { for... } }  -> two closing braces
# Now we need: } for... }  -> one closing brace for if, one for for

# Let's find the extra } that was closing the else block
# It should be after the for loop ends, before the next function
# We'll handle this by checking brace balance at the end

with open('src/adapters/dense_transformer_runtime.cpp', 'w') as f:
    f.write(content)

print("All textual changes applied!")

# Verify brace balance
open_braces = 0
for i, ch in enumerate(content):
    if ch == '{':
        open_braces += 1
    elif ch == '}':
        open_braces -= 1
        if open_braces < 0:
            # Find line number
            line_num = content[:i].count('\n') + 1
            print(f"ERROR: Extra }} at position {i} (line {line_num})")
            break
print(f"Final open braces: {open_braces}")