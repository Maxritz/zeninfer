with open('src/adapters/dense_transformer_runtime.cpp', 'r') as f:
    content = f.read()

# Find the start and end of the section to replace
old_start = '    // Try to run all layers through the GPU pipeline (single submit+wait for all layers)\n    // First check if all layers qualify for the pipeline path\n    bool all_layers_qualify = true;\n    struct LayerParams {'

old_end = '    if(all_layers_qualify) {\n        // Pipeline succeeded, skip per-layer path\n    } else {\n        for(std::uint32_t l=0;l<config_.layers;++l){\n        const std::string p="blk."+std::to_string(l)+".";'

start_idx = content.find(old_start)
if start_idx >= 0:
    end_idx = content.find(old_end, start_idx)
    if end_idx >= 0:
        end_idx += len(old_end)
        print(f'Found section at {start_idx} to {end_idx}')
        
        # Read the replacement
        with open('pipeline_fix_segment.cpp', 'r') as f:
            replacement = f.read()
        
        new_content = content[:start_idx] + replacement + content[end_idx:]
        with open('src/adapters/dense_transformer_runtime.cpp', 'w') as f:
            f.write(new_content)
        print('Replacement done!')
    else:
        print('End marker not found')
else:
    print('Start marker not found')