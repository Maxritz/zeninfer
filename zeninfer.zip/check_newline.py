with open('src/adapters/dense_transformer_runtime.cpp', 'rb') as f:
    content = f.read()

in_string = False
escape = False
for i, byte in enumerate(content):
    if byte == ord('"') and not escape:
        in_string = not in_string
    elif byte == ord('\n') and in_string:
        print(f'Found newline in string at byte {i}')
        start = max(0, i-50)
        end = min(len(content), i+50)
        print(repr(content[start:end]))
        break
    elif byte == ord('\\') and not escape:
        escape = True
    else:
        escape = False