with open('src/adapters/dense_transformer_runtime.cpp', 'r') as f:
    lines = f.readlines()

# Find the line numbers
for i, line in enumerate(lines):
    if 'zen::diag::Scope scope_rope("transformer.prefill.rope"' in line:
        scope_rope_line = i
        print(f'scope_rope at line {i+1}: {line.strip()}')
    if 'std::vector<std::size_t> kv_layers;' in line and 'reserve' not in lines[i+1] if i+1 < len(lines) else True:
        kv_layers_line = i
        print(f'kv_layers at line {i+1}: {line.strip()}')
    if 'kv_layers.push_back(l);' in line:
        push_back_line = i
        print(f'push_back at line {i+1}: {line.strip()}')
    if 'Batched KV cache append for this layer' in line:
        batched_comment_line = i
        print(f'batched comment at line {i+1}: {line.strip()}')
    if 'std::printf("[d3d12] batched kv append' in line:
        printf_line = i
        print(f'printf at line {i+1}: {line.strip()}')
    if 'zen::diag::Scope scope_attn("transformer.prefill.attention"' in line:
        scope_attn_line = i
        print(f'scope_attn at line {i+1}: {line.strip()}')

print(f'scope_rope_line: {scope_rope_line}')
print(f'kv_layers_line: {kv_layers_line}')
print(f'push_back_line: {push_back_line}')
print(f'batched_comment_line: {batched_comment_line}')
print(f'printf_line: {printf_line}')
print(f'scope_attn_line: {scope_attn_line}')