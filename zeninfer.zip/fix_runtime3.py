with open('src/adapters/dense_transformer_runtime.cpp', 'r') as f:
    content = f.read()

# Find the rope scope section
idx = content.find('zen::diag::Scope scope_rope("transformer.prefill.rope",zen::diag::Phase::compute);')
print('Found at:', idx)

# Find the end of the for loop and the empty #if block
# We need to replace from the start of the for loop to the closing }} of the for loop and the empty #if block

# Find the end of the for loop - look for the pattern "}} #endif }}"
search_start = content.find('for(std::size_t t=0;t<T;++t){', 75648)
print('for loop at:', search_start)

# Find the end of the for loop - look for "}} #endif }}"
end_idx = content.find('}}\n        #endif\n        }}', search_start)
if end_idx == -1:
    end_idx = content.find('}}\n        #endif\n        }}', search_start)
if end_idx == -1:
    end_idx = content.find('}}        #endif\n        }}', search_start)
if end_idx == -1:
    # Try to find the pattern more flexibly
    end_idx = content.find('}}', search_start + 100)
    while end_idx != -1:
        context = content[end_idx:end_idx+50]
        if '#endif' in context and '}}' in context:
            break
        end_idx = content.find('}}', end_idx + 1)

print('End of block at:', end_idx)
if end_idx != -1:
    print('Context:', content[end_idx:end_idx+100])

# Now let's extract the exact text to replace
old_text = content[search_start:end_idx+4]  # Include the }}
print('OLD TEXT LENGTH:', len(old_text))
print('OLD TEXT START:', old_text[:200])
print('OLD TEXT END:', old_text[-200:])