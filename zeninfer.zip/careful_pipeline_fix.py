with open('src/adapters/dense_transformer_runtime.cpp', 'r') as f:
    lines = f.readlines()

# Make minimal changes carefully:

# 1. Add layer_qualifies after pipeline_layers.reserve (line 1188)
for i, line in enumerate(lines):
    if 'pipeline_layers.reserve(config_.layers);' in line:
        lines.insert(i+1, '    std::vector<bool> layer_qualifies(config_.layers, false);\n')
        print(f"Added layer_qualifies at line {i+2}")
        break

# 2. Set layer_qualifies[l] = true in qualification success
for i, line in enumerate(lines):
    if 'pipeline_layers.push_back(std::move(lp));' in line and 'layer_qualifies' not in lines[i+1]:
        lines.insert(i+1, '            layer_qualifies[l] = true;\n')
        print(f"Added layer_qualifies[l]=true at line {i+2}")
        break

# 3. Set layer_qualifies[l] = false in qualification failure
for i, line in enumerate(lines):
    if 'all_layers_qualify = false;' in line and 'layer_qualifies' not in lines[i+1]:
        # Make sure this is in the qualification loop (inside the for l loop)
        # Check context - should be inside an else block at indent level 12+
        if i > 0 and lines[i-1].strip() == '} else {':
            lines[i] = '            all_layers_qualify = false;\n            layer_qualifies[l] = false;\n'
            print(f"Added layer_qualifies[l]=false at line {i+1}")
            break

# 4. Change pipeline condition
for i, line in enumerate(lines):
    if 'if(all_layers_qualify && pipeline_layers.size() == config_.layers)' in line:
        lines[i] = '    // Run pipeline for any qualifying layers (not requiring all)\n    if(!pipeline_layers.empty()) {\n'
        print(f"Changed pipeline condition at line {i+1}")
        break

# 5. Change the pipeline block's closing "} else {" to just "}"
# The pipeline block's else is the one that has "// Pipeline succeeded, skip per-layer path" after it
# Find the pipeline block's else - it should be after the pipeline execution and before the per-layer for loop
pipeline_else_line = -1
for i, line in enumerate(lines):
    if line.strip() == '} else {' and i > 1250:  # After pipeline block
        # Check if the next non-empty line has "Pipeline succeeded"
        for j in range(i+1, min(i+10, len(lines))):
            if 'Pipeline succeeded' in lines[j]:
                pipeline_else_line = i
                break
        if pipeline_else_line >= 0:
            break

if pipeline_else_line >= 0:
    lines[pipeline_else_line] = '}\n'
    print(f"Changed pipeline block's }} else {{ to }} at line {pipeline_else_line+1}")
else:
    print("WARNING: Could not find pipeline block's else!")

# 6. Modify the per-layer loop to skip qualifying layers
# Find "if(all_layers_qualify) {" that's after the pipeline block
for i, line in enumerate(lines):
    if line.strip() == 'if(all_layers_qualify) {' and 'Pipeline succeeded' in lines[i+1]:
        lines[i] = '    // Per-layer path for non-qualifying layers\n    for(std::uint32_t l=0;l<config_.layers;++l){\n        if (layer_qualifies[l]) continue; // Skip layers already processed by pipeline\n'
        # Remove the next line "// Pipeline succeeded, skip per-layer path"
        if 'Pipeline succeeded' in lines[i+1]:
            lines[i+1] = ''
        print(f"Modified per-layer loop at line {i+1}")
        break

# Also need to remove the extra closing brace that was for the else block
# The old structure had: if() { pipeline } else { for(...) { ... } }
# Now: if() { pipeline } for(...) { ... }
# The else block had its own closing brace which we changed to }
# But the for loop inside else also had a closing brace
# Actually the structure is:
# if() {
#   pipeline
# } else {
#   for(...) {
#     ...
#   }
# }
# Two closing braces at the end
# Now:
# if() {
#   pipeline
# }
# for(...) {
#   ...
# }
# Still two closing braces, so it should match!

with open('src/adapters/dense_transformer_runtime.cpp', 'w') as f:
    f.writelines(lines)

print("Changes applied!")

# Verify brace balance
open_braces = 0
for i, line in enumerate(lines):
    for ch in line:
        if ch == '{':
            open_braces += 1
        elif ch == '}':
            open_braces -= 1
            if open_braces < 0:
                print(f"ERROR: Extra }} at line {i+1}")
                break
print(f"Final open braces: {open_braces}")