with open(r'H:\llamadx\update\zeninfer\src\backends\d3d12\d3d12_backend.cpp', 'r') as f:
    lines = f.readlines()

# Find and replace ensure_upload function
new_lines = []
i = 0
while i < len(lines):
    line = lines[i]
    if 'bool ensure_upload(ComPtr<ID3D12Resource>& buf, void*& cpu, std::size_t& cap,' in line:
        # Replace function signature
        new_lines.append('bool ensure_upload(ComPtr<ID3D12Resource>& buf, void*& cpu, std::size_t& cap,\n')
        new_lines.append('                    State& s, std::size_t bytes) {\n')
        i += 2  # Skip the next line (ID3D12Device* device, std::size_t bytes) {
        # Now process the body
        while i < len(lines):
            line = lines[i]
            if 'buf = create_buffer(device, bytes, upload_heap_type(), upload_heap_state());' in line:
                new_lines.append('    buf = create_buffer(s, bytes, upload_heap_type(), upload_heap_state());\n')
            else:
                new_lines.append(line)
            if 'return true;' in line and 'cap = bytes;' in lines[i-1]:
                # This is the last line of the function
                i += 1
                break
            i += 1
    else:
        new_lines.append(line)
        i += 1

# Fix call sites
content = ''.join(new_lines)
content = content.replace('ensure_upload(s.wbuf, s.w_cpu, s.w_cap, s.device.Get(), hidden_bytes)',
                          'ensure_upload(s.wbuf, s.w_cpu, s.w_cap, s, hidden_bytes)')
content = content.replace('ensure_upload(s.nbuf, s.n_cpu, s.n_cap, s.device.Get(), hidden_bytes)',
                          'ensure_upload(s.nbuf, s.n_cpu, s.n_cap, s, hidden_bytes)')

with open(r'H:\llamadx\update\zeninfer\src\backends\d3d12\d3d12_backend.cpp', 'w') as f:
    f.write(content)

print("Done")