with open('src/adapters/dense_transformer_runtime.cpp', 'r') as f:
    content = f.read()

idx = content.find('zen::diag::Scope scope_rope("transformer.prefill.rope"')
print('Found at:', idx)
print(content[idx:idx+2000])