with open('src/adapters/dense_transformer_runtime.cpp', 'r') as f:
    content = f.read()

# Find the rope scope
idx = content.find('zen::diag::Scope scope_rope')
print('Found at:', idx)

# Print context
print(content[idx:idx+2000])