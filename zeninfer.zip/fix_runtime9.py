with open('src/adapters/dense_transformer_runtime.cpp', 'r') as f:
    content = f.read()

# Fix the duplicate/messy code around lines 1041-1092
# The issue is duplicate code blocks and a syntax error at line 1075

# Find the problematic section
idx = content.find('#endifnfig_.use_alibi&&device_attention_available(config_.layers,kc[l].size()/KW,KH,D,config_.rms_epsilon)){')
if idx == -1:
    idx = content.find('#endifnfig_.use_alibi')
    print("Found at:", idx)

# Print context around the error
print(content[1070:1100])