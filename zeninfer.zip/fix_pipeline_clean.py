#!/usr/bin/env python3
"""
Clean, precise fix for pipeline hybrid using exact line positions from backup.
"""

with open('src/adapters/dense_transformer_runtime.cpp', 'r') as f:
    lines = f.readlines()

# Line numbers from backup (0-indexed):
# 1188: pipeline_layers.reserve(config_.layers);
# 1211: pipeline_layers.push_back(std::move(lp));
# 1212:         } else {
# 1213:             all_layers_qualify = false;
# 1218: if(all_layers_qualify && pipeline_layers.size() == config_.layers) {
# 1236:             all_layers_qualify = false;
# 1242-1247: Also log block
# 1250: if(all_layers_qualify) {
# 1252:     } else {
# 1253:         for(...){

new_lines = []
i = 0
while i < len(lines):
    line = lines[i]
    
    # 1. After pipeline_layers.reserve(config_.layers); (line 1188, 0-indexed: 1187)
    if i == 1187 and 'pipeline_layers.reserve(config_.layers);' in line:
        new_lines.append(line)
        new_lines.append('    std::vector<bool> layer_qualifies(config_.layers, false);\n')
        i += 1
        continue
    
    # 2. After pipeline_layers.push_back(std::move(lp)); (line 1211, 0-indexed: 1210)
    if i == 1210 and 'pipeline_layers.push_back(std::move(lp));' in line:
        new_lines.append(line)
        new_lines.append('            layer_qualifies[l] = true;\n')
        i += 1
        continue
    
    # 3. In else branch, add layer_qualifies[l] = false (line 1213 -> 1212 0-indexed)
    if i == 1212 and 'all_layers_qualify = false;' in line and 'else' in lines[i-1]:
        new_lines.append('            all_layers_qualify = false;\n')
        new_lines.append('            layer_qualifies[l] = false;\n')
        i += 1
        continue
    
    # 4. Change pipeline condition (line 1218 -> 1217 0-indexed)
    if i == 1217 and 'if(all_layers_qualify && pipeline_layers.size() == config_.layers)' in line:
        new_lines.append('    // Run pipeline for any qualifying layers (not requiring all)\n')
        new_lines.append('    if(!pipeline_layers.empty()) {\n')
        i += 1
        continue
    
    # 5. Remove all_layers_qualify = false in pipeline fail block (line 1236 -> 1235)
    if i == 1235 and 'all_layers_qualify = false;' in line and 'Pipeline failed' in ''.join(lines[max(0,i-5):i+3]):
        new_lines.append('            // all_layers_qualify no longer used for pipeline gating\n')
        i += 1
        continue
    
    # 6. Remove "Also log when not all layers qualify" block (7 lines starting at line 1242 -> 1241)
    if i == 1241 and 'Also log when not all layers qualify' in line:
        # Skip 7 lines
        i += 7
        continue
    
    # 7. Replace second if/else with for loop + skip
    if i == 1249 and line.strip() == 'if(all_layers_qualify) {' and 'Pipeline succeeded' in lines[i+1]:
        # Skip the if/else block and replace with for loop + skip
        # The structure is:
        # 1249: if(all_layers_qualify) {
        # 1250:     // Pipeline succeeded, skip per-layer path
        # 1251: } else {
        # 1252:     for(std::uint32_t l=0;l<config_.layers;++l){
        # 1253:         const std::string p="blk."+std::to_string(l)+".";
        # ... body ...
        # 1414:     }  (closes for)
        # 1415: } (closes else)
        # 1416: } (closes if)
        
        # Find the end of the else block (matching brace)
        brace = 0
        else_end = -1
        for j in range(i, len(lines)):
            for ch in lines[j]:
                if ch == '{': brace += 1
                elif ch == '}': brace -= 1
            if brace == 0:
                else_end = j
                break
        
        if else_end >= 0:
            # Find the for loop within the else block
            for_loop = -1
            for j in range(i, else_end + 1):
                if 'for(std::uint32_t l=0;l<config_.layers;++l){' in lines[j]:
                    for_loop = j
                    break
            
            if for_loop >= 0:
                # Replace from second_if to else_end with new for loop
                body_lines = lines[for_loop+1:else_end]
                
                new_section = [
                    '    // Per-layer path for non-qualifying layers\n',
                    '    for(std::uint32_t l=0;l<config_.layers;++l){\n',
                    '        if (layer_qualifies[l]) continue; // Skip layers already processed by pipeline\n',
                ] + body_lines
                
                new_lines = lines[:i] + new_section + lines[else_end+1:]
                
                # Remove ONE extra closing brace (we removed if/else but kept for loop)
                final_content = ''.join(new_lines)
                
                # Find and remove one extra closing brace before generate function
                idx = final_content.find('\nbool DenseTransformerRuntime::generate(')
                if idx > 0:
                    brace = 0
                    for j in range(idx-1, max(0, idx-50), -1):
                        if final_content[j] == '}':
                            final_content = final_content[:j] + final_content[j+1:]
                            print(f'Removed extra }} at position {j}')
                            break
                
                with open('src/adapters/dense_transformer_runtime.cpp', 'w') as f:
                    f.write(final_content)
                
                # Verify
                open_braces = 0
                for idx, ch in enumerate(final_content):
                    if ch == '{': open_braces += 1
                    elif ch == '}':
                        open_braces -= 1
                        if open_braces < 0:
                            print(f'ERROR: Extra }} at position {idx}')
                            break
                print(f'Final open braces: {open_braces}')
                print('Done!')
                exit(0)
    
    new_lines.append(line)
    i += 1

# If we get here, something went wrong
with open('src/adapters/dense_transformer_runtime.cpp', 'w') as f:
    f.writelines(new_lines)
print('Fallback: wrote line-by-line version')

# Verify brace balance
content = ''.join(new_lines)
open_braces = 0
for i, ch in enumerate(''.join(new_lines)):
    if ch == '{': open_braces += 1
    elif ch == '}':
        open_braces -= 1
        if open_braces < 0:
            line_num = ''.join(new_lines)[:i].count('\n') + 1
            print(f'ERROR: Extra }} at position {i} (line {line_num})')
            break
print(f'Final open braces: {open_braces}')