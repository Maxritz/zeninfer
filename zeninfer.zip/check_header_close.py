with open('include/zen/dense_transformer_runtime.h', 'rb') as f:
    content = f.read()

idx = content.find(b'class DenseTransformerRuntime')
if idx >= 0:
    for i in range(idx, len(content)):
        if content[i:i+2] == b'};':
            print('Class closes with }; at index', i)
            print(repr(content[max(0,i-20):i+10]))
            break