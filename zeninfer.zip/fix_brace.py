with open('src/adapters/dense_transformer_runtime.cpp', 'r') as f:
    lines = f.readlines()

# Fix 1: Fix printf format string (literal newline should be \n)
for i, line in enumerate(lines):
    if 'std::printf("[d3d12] batched kv append' in line and 'num_tokens=%zu\n"' in line:
        lines[i] = lines[i].replace('num_tokens=%zu\n"', 'num_tokens=%zu\\n"')
        print(f'Fixed printf at line {i+1}')
        break

# Fix 2: Remove duplicate scope_attn declaration
for i, line in enumerate(lines):
    if line.strip().count('zen::diag::Scope scope_attn("transformer.prefill.attention"') == 2:
        lines[i] = '        {zen::diag::Scope scope_attn("transformer.prefill.attention",zen::diag::Phase::compute);\n'
        print(f'Fixed duplicate scope_attn at line {i+1}')
        break

with open('src/adapters/dense_transformer_runtime.cpp', 'w') as f:
    f.writelines(lines)

print('Fixes applied!')