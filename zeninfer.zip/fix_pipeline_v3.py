#!/usr/bin/env python3
"""
Minimal pipeline hybrid fix - only changes control flow, preserves ALL braces.
"""

with open('src/adapters/dense_transformer_runtime.cpp', 'r') as f:
    content = f.read()

# 1. Add layer_qualifies vector after pipeline_layers.reserve
content = content.replace(
    '    std::vector<LayerParams> pipeline_layers;\n    pipeline_layers.reserve(config_.layers);',
    '    std::vector<LayerParams> pipeline_layers;\n    pipeline_layers.reserve(config_.layers);\n    std::vector<bool> layer_qualifies(config_.layers, false);'
)

# 2. Add layer_qualifies[l] = true in qualification success
content = content.replace(
    '            pipeline_layers.push_back(std::move(lp));\n        } else {',
    '            pipeline_layers.push_back(std::move(lp));\n            layer_qualifies[l] = true;\n        } else {'
)

# 3. Add layer_qualifies[l] = false in qualification failure
content = content.replace(
    '            all_layers_qualify = false;\n        }\n    }\n\n    // If all layers qualify',
    '            all_layers_qualify = false;\n            layer_qualifies[l] = false;\n        }\n    }\n\n    // Run pipeline for any qualifying layers (not requiring all)\n    if(!pipeline_layers.empty()) {'
)

# 4. Change the pipeline condition
content = content.replace(
    'if(all_layers_qualify && pipeline_layers.size() == config_.layers) {',
    '// Run pipeline for any qualifying layers (not requiring all)\n    if(!pipeline_layers.empty()) {'
)

# 5. Remove all_layers_qualify = false inside pipeline block
content = content.replace(
    '            all_layers_qualify = false;\n            if (const char* trace = std::getenv("ZEN_D3D12_TRACE"); trace && trace[0] == \'1\') {',
    '            // all_layers_qualify no longer used for pipeline gating\n            if (const char* trace = std::getenv("ZEN_D3D12_TRACE"); trace && trace[0] == \'1\') {'
)

# 5b. Remove the "Also log when not all layers qualify" block
old_log = '''        }
        
        // Also log when not all layers qualify
        if (!all_layers_qualify && pipeline_layers.size() < config_.layers) {
            if (const char* trace = std::getenv("ZEN_D3D12_TRACE"); trace && trace[0] == '1') {
                std::printf("[d3d12] pipeline: NOT ALL QUALIFY pipeline_layers=%zu vs config_.layers=%zu\\n", pipeline_layers.size(), config_.layers);
            }
        }
    }'''

new_log = '''        }
    }'''

content = content.replace(old_log, new_log)

# 6. Replace the second if/else with for loop + skip
old_wrapper = '''    if(all_layers_qualify) {
        // Pipeline succeeded, skip per-layer path
    } else {
        for(std::uint32_t l=0;l<config_.layers;++l){
        const std::string p="blk."+std::to_string(l)+".";'''

new_wrapper = '''    // Per-layer path for non-qualifying layers
    for(std::uint32_t l=0;l<config_.layers;++l){
        if (layer_qualifies[l]) continue; // Skip layers already processed by pipeline
        const std::string p="blk."+std::to_string(l)+".";'''

content = content.replace(old_wrapper, new_wrapper)

# Remove the extra "} else {" that's now orphaned
content = content.replace(
    '    }\n    } else {\n        for(std::uint32_t l=0;l<config_.layers;++l){\n        if (layer_qualifies[l]) continue; // Skip layers already processed by pipeline\n        const std::string p="blk."+std::to_string(l)+".";',
    '    // Per-layer path for non-qualifying layers\n    for(std::uint32_t l=0;l<config_.layers;++l){\n        if (layer_qualifies[l]) continue; // Skip layers already processed by pipeline\n        const std::string p="blk."+std::to_string(l)+".";'
)

# Remove one extra closing brace before generate function
# Find the generate function and remove one extra } before it
idx = content.find('\nbool DenseTransformerRuntime::generate(')
if idx > 0:
    # Find the extra } before generate
    for i in range(idx-1, max(0, idx-50), -1):
        if content[i] == '}':
            # Check if this is an extra brace by looking at context
            content = content[:i] + content[i+1:]
            break

with open('src/adapters/dense_transformer_runtime.cpp', 'w') as f:
    f.write(content)

# Verify brace balance
open_braces = 0
for i, ch in enumerate(content):
    if ch == '{':
        open_braces += 1
    elif ch == '}':
        open_braces -= 1
        if open_braces < 0:
            line_num = content[:i].count('\n') + 1
            print(f"ERROR: Extra }} at position {i} (line {line_num})")
            break
print(f"Final open braces: {open_braces}")

# Also check the syntax around line 1221 (where the error was)
lines = content.split('\n')
for i in range(1215, 1230):
    if i < len(lines):
        print(f"{i+1}: {lines[i]}")