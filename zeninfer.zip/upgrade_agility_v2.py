#!/usr/bin/env python3
"""
Try to get dxc with Work Graphs support via Agility SDK NuGet package.
"""
import os
import sys
import urllib.request
import zipfile
import shutil
import subprocess
import tempfile
import json
import gzip
import io

def get_agility_versions():
    """Get available Agility SDK versions from NuGet."""
    try:
        req = urllib.request.Request("https://api.nuget.org/v3/registration5-gz-semver2/microsoft.direct3d.d3d12/index.json")
        req.add_header('Accept-Encoding', 'gzip')
        with urllib.request.urlopen(req) as response:
            content = response.read()
            # Decompress if gzipped
            if response.headers.get('Content-Encoding') == 'gzip':
                content = gzip.decompress(content)
            data = json.loads(content.decode('utf-8'))
            versions = []
            for page in data.get('items', []):
                for item in page.get('items', []):
                    version = item.get('catalogEntry', {}).get('version')
                    if version:
                        versions.append(version)
            return versions
    except Exception as e:
        print(f"Failed to fetch Agility SDK versions: {e}")
        return []

def download_agility_sdk(version):
    """Download and extract Agility SDK."""
    url = f"https://www.nuget.org/api/v2/package/Microsoft.Direct3D.D3D12/{version}"
    
    with tempfile.TemporaryDirectory() as tmpdir:
        nupkg_path = os.path.join(tmpdir, f"agility_{version}.nupkg")
        
        try:
            print(f"Downloading Agility SDK {version} from NuGet...")
            urllib.request.urlretrieve(f"https://www.nuget.org/api/v2/package/Microsoft.Direct3D.D3D12/{version}", 
                                       os.path.join(tmpdir, f"agility_{version}.nupkg"))
        except urllib.error.HTTPError as e:
            if e.code == 404:
                print(f"Version {version} not found")
                return False
            raise
        
        extract_dir = os.path.join(tmpdir, "extract")
        os.makedirs(extract_dir)
        
        with zipfile.ZipFile(os.path.join(tmpdir, f"agility_{version}.nupkg"), 'r') as zf:
            zf.extractall(extract_dir)
        
        # Find dxc.exe in build/native/bin/x64
        dxc_path = None
        for root, dirs, files in os.walk(extract_dir):
            for f in files:
                if f == "dxc.exe":
                    dxc_path = os.path.join(root, f)
                    break
            if dxc_path:
                break
        
        if not dxc_path:
            print("ERROR: dxc.exe not found in Agility SDK")
            return False
        
        # Install
        install_dir = r"H:\llamadx\dxc_agility"
        if os.path.exists(install_dir):
            shutil.rmtree(install_dir)
        os.makedirs(install_dir, exist_ok=True)
        
        # Copy build/native folder
        native_dir = os.path.dirname(os.path.dirname(dxc_path))
        for root, dirs, files in os.walk(native_dir):
            for f in files:
                src = os.path.join(root, f)
                rel = os.path.relpath(src, os.path.join(root, "..", ".."))
                dst = os.path.join(install_dir, rel)
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                shutil.copy2(src, dst)
        
        # Test
        dxc_exe = os.path.join(install_dir, "bin", "x64", "dxc.exe")
        if not os.path.exists(dxc_exe):
            for root, dirs, files in os.walk(install_dir):
                if "dxc.exe" in files:
                    dxc_exe = os.path.join(root, "dxc.exe")
                    break
        
        if not os.path.exists(dxc_exe):
            print("ERROR: dxc.exe not found")
            return False
        
        result = subprocess.run([dxc_exe, "--version"], capture_output=True, text=True)
        print(f"Version: {result.stdout.strip()}")
        
        result = subprocess.run([dxc_exe, "-help"], capture_output=True, text=True)
        if "enable-work-graph" in result.stdout:
            print("SUCCESS: -enable-work-graph flag found!")
            return True
        else:
            print("WARNING: -enable-work-graph flag NOT found")
            return False

def main():
    print("Fetching Agility SDK versions...")
    versions = []
    try:
        req = urllib.request.Request("https://api.nuget.org/v3/registration5-gz-semver2/microsoft.direct3d.d3d12/index.json")
        req.add_header('Accept-Encoding', 'gzip')
        with urllib.request.urlopen(req) as response:
            content = response.read()
            if response.headers.get('Content-Encoding') == 'gzip':
                content = gzip.decompress(content)
            data = json.loads(content.decode('utf-8'))
            for page in data.get('items', []):
                for item in page.get('items', []):
                    version = item.get('catalogEntry', {}).get('version')
                    if version and version.startswith(('1.8.', '1.9.')):
                        versions.append(version)
    except Exception as e:
        print(f"Failed to fetch versions: {e}")
        return
    
    versions = list(set(versions))  # deduplicate
    versions.sort(key=lambda x: tuple(map(int, x.split('.')[:3])), reverse=True)
    print(f"Candidate versions: {versions[:10]}")
    
    for version in versions:
        print(f"\nTrying Agility SDK {version}...")
        if download_agility_sdk(version):
            print(f"\nSUCCESS: Agility SDK {version} with dxc Work Graphs support installed!")
            print(f"Installed to: H:\\llamadx\\dxc_agility")
            return
    
    print("FAILED")

if __name__ == "__main__":
    main()