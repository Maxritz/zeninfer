with open('src/backends/d3d12/d3d12_backend.cpp', 'r') as f:
    content = f.read()

# Find the Enhanced Barriers section and replace with legacy implementation
old_start = "// ============================================================================\n// Enhanced Barriers API (D3D12_BARRIER, D3D12_BUFFER_BARRIER) - requires Agility SDK 1.8+, Windows 11"
old_end = "// Legacy wrapper for transition() function\nvoid transition(State& s, ID3D12Resource* resource, D3D12_RESOURCE_STATES before,\n                D3D12_RESOURCE_STATES after) {\n    enhanced_barrier(s, resource, before, after);\n}"

start_idx = content.find(old_start)
end_idx = content.find(old_end)
if end_idx >= 0:
    end_idx += len(old_end)

if start_idx >= 0 and end_idx >= 0:
    replacement = """// ============================================================================
// Enhanced Barriers Emulation using Legacy D3D12_RESOURCE_BARRIER
// True Enhanced Barriers API (D3D12_BARRIER, D3D12_BUFFER_BARRIER, ID3D12Device10::Barrier)
// requires Agility SDK 1.8+ and Windows 11, which is not available in SDK 1.722.
// This implementation uses legacy D3D12_RESOURCE_BARRIER with BEGIN_ONLY/END_ONLY flags
// to emulate split barriers for overlapping transitions.
// ============================================================================

// Split barrier: begin transition early, end late (legacy D3D12_RESOURCE_BARRIER with BEGIN_ONLY/END_ONLY flags)
void enhanced_barrier_begin(State& s, ID3D12Resource* resource,
                            D3D12_RESOURCE_STATES before, D3D12_RESOURCE_STATES after,
                            D3D12_RESOURCE_BARRIER* out_barrier) {
    out_barrier->Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
    out_barrier->Flags = D3D12_RESOURCE_BARRIER_FLAG_BEGIN_ONLY;
    out_barrier->Transition.pResource = resource;
    out_barrier->Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
    out_barrier->Transition.StateBefore = before;
    out_barrier->Transition.StateAfter = after;
}

void enhanced_barrier_end(State& s, D3D12_RESOURCE_BARRIER* barrier) {
    if (!barrier->Transition.pResource) return;
    
    barrier->Flags = D3D12_RESOURCE_BARRIER_FLAG_END_ONLY;
    s.list->ResourceBarrier(1, barrier);
    
    barrier->Transition.pResource = nullptr;  // Mark as consumed
}

// Legacy wrapper for transition() function
void transition(State& s, ID3D12Resource* resource, D3D12_RESOURCE_STATES before,
                D3D12_RESOURCE_STATES after) {
    D3D12_RESOURCE_BARRIER barrier{};
    barrier.Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
    barrier.Flags = D3D12_RESOURCE_BARRIER_FLAG_NONE;
    barrier.Transition.pResource = resource;
    barrier.Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
    barrier.Transition.StateBefore = before;
    barrier.Transition.StateAfter = after;
    s.list->ResourceBarrier(1, &barrier);
}"""

    new_content = content[:start_idx] + replacement + content[end_idx:]
    
    with open('src/backends/d3d12/d3d12_backend.cpp', 'w') as f:
        f.write(new_content)
    
    print("Replaced Enhanced Barriers section with legacy implementation")
else:
    print("Could not find section boundaries")
    print(f"start_idx: {start_idx}, end_idx: {end_idx}")