with open('src/adapters/dense_transformer_runtime.cpp.bak', 'r') as f:
    content = f.read()

idx = content.find('zen::diag::Scope scope_rope')
print('Found at:', idx)
print(content[idx:idx+2000])