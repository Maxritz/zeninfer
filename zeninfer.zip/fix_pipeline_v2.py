#!/usr/bin/env python3
"""
Surgical fix using exact line numbers.
"""

with open('src/adapters/dense_transformer_runtime.cpp', 'r') as f:
    lines = f.readlines()

# Line numbers are 1-indexed, Python list is 0-indexed
# Line 1188: reserve
# Line 1211: push_back
# Line 1213: all_layers_qualify = false in else
# Line 1218: if condition
# Line 1242: also log
# Line 1250: second if

new_lines = []
i = 0
while i < len(lines):
    line = lines[i]
    line_num = i + 1
    
    # Line 1188: after reserve, add layer_qualifies
    if line_num == 1188 and 'pipeline_layers.reserve(config_.layers);' in line:
        new_lines.append(line)
        new_lines.append('    std::vector<bool> layer_qualifies(config_.layers, false);\n')
        i += 1
        continue
    
    # Line 1211: after push_back, add layer_qualifies[l] = true
    if line_num == 1211 and 'pipeline_layers.push_back(std::move(lp));' in line:
        new_lines.append(line)
        new_lines.append('            layer_qualifies[l] = true;\n')
        i += 1
        continue
    
    # Line 1213: in else branch, add layer_qualifies[l] = false
    if line_num == 1213 and 'all_layers_qualify = false;' in line:
        new_lines.append('            all_layers_qualify = false;\n')
        new_lines.append('            layer_qualifies[l] = false;\n')
        i += 1
        continue
    
    # Line 1218: change if condition
    if line_num == 1218 and 'if(all_layers_qualify && pipeline_layers.size() == config_.layers)' in line:
        new_lines.append('    // Run pipeline for any qualifying layers (not requiring all)\n')
        new_lines.append('    if(!pipeline_layers.empty()) {\n')
        i += 1
        continue
    
    # Line 1236 (approx): remove all_layers_qualify = false in pipeline fail block
    # This is inside the pipeline block, after "Pipeline failed"
    if 'all_layers_qualify = false;' in line and 'Pipeline failed' in ''.join(lines[max(0,i-5):i+3]):
        new_lines.append('            // all_layers_qualify no longer used for pipeline gating\n')
        i += 1
        continue
    
    # Lines 1242-1247: Remove "Also log when not all layers qualify" block (7 lines)
    if line_num == 1242 and 'Also log when not all layers qualify' in line:
        # Skip 7 lines
        i += 7
        continue
    
    # Line 1250: Replace second if/else with for loop
    if line_num == 1250 and 'if(all_layers_qualify) {' in line and 'Pipeline succeeded' in lines[i+1]:
        new_lines.append('    // Per-layer path for non-qualifying layers\n')
        new_lines.append('    for(std::uint32_t l=0;l<config_.layers;++l){\n')
        new_lines.append('        if (layer_qualifies[l]) continue; // Skip layers already processed by pipeline\n')
        new_lines.append('        const std::string p="blk."+std::to_string(l)+".";\n')
        i += 4  # Skip the old if/else lines
        continue
    
    # Remove the "} else {" before the for loop (now orphaned)
    if line.strip() == '} else {' and i+1 < len(lines) and 'for(std::uint32_t l=0;l<config_.layers;++l){' in lines[i+1]:
        i += 1  # Skip this line
        continue
    
    new_lines.append(line)
    i += 1

# Now we need to remove one extra closing brace before the generate function
# The old code had: } else { for... } }  -> two closing braces
# Now we have: for... }  -> one closing brace
# So we need to remove one extra }

final_lines = []
extra_brace_removed = False
for line in new_lines:
    if not extra_brace_removed and line.strip() == '}' and len(final_lines) > 0:
        # Check if next non-empty line is the generate function
        # This is a heuristic - we want to remove one extra } before generate
        # For now, let's just keep track and remove the last extra } before generate
        final_lines.append(line)
    else:
        final_lines.append(line)

# Better: remove the extra } by finding the generate function and removing one } before it
final_content = ''.join(new_lines)
idx = final_content.find('\nbool DenseTransformerRuntime::generate(')
if idx > 0:
    # Find the last } before generate
    for i in range(idx-1, max(0, idx-50), -1):
        if final_content[i] == '}':
            final_content = final_content[:i] + final_content[i+1:]
            break

with open('src/adapters/dense_transformer_runtime.cpp', 'w') as f:
    f.write(final_content)

# Verify brace balance
open_braces = 0
for i, ch in enumerate(final_content):
    if ch == '{':
        open_braces += 1
    elif ch == '}':
        open_braces -= 1
        if open_braces < 0:
            line_num = final_content[:i].count('\n') + 1
            print(f"ERROR: Extra }} at position {i} (line {line_num})")
            break
print(f"Final open braces: {open_braces}")