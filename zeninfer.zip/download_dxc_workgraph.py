import urllib.request
import zipfile
import shutil
import subprocess
import tempfile
import os

# Try the mesh-nodes-preview versions which might have Work Graphs support
versions_to_try = [
    "1.8.2405.17",
    "1.8.2404.55-mesh-nodes-preview",
    "1.8.2404.54-mesh-nodes-preview",
]

for version in versions_to_try:
    url = f"https://www.nuget.org/api/v2/package/Microsoft.Direct3D.DXC/{version}"
    
    with tempfile.TemporaryDirectory() as tmpdir:
        nupkg_path = os.path.join(tmpdir, f"dxc_{version}.nupkg")
        
        try:
            print(f"Trying Microsoft.Direct3D.DXC {version}...")
            urllib.request.urlretrieve(f"https://www.nuget.org/api/v2/package/Microsoft.Direct3D.DXC/{version}", 
                                       os.path.join(tmpdir, f"dxc_{version}.nupkg"))
            print(f"  Downloaded {version}")
        except urllib.error.HTTPError as e:
            if e.code == 404:
                print(f"  Version {version} not found on NuGet")
                continue
            else:
                raise
        except Exception as e:
            print(f"  Download failed: {e}")
            continue
        
        # Extract and test
        extract_dir = os.path.join(tmpdir, "extract")
        os.makedirs(extract_dir)
        
        try:
            with zipfile.ZipFile(os.path.join(tmpdir, f"dxc_{version}.nupkg"), 'r') as zf:
                zf.extractall(extract_dir)
        except Exception as e:
            print(f"  Extract failed: {e}")
            continue
        
        # Find dxc.exe
        dxc_path = None
        for root, dirs, files in os.walk(extract_dir):
            for f in files:
                if f == "dxc.exe":
                    dxc_path = os.path.join(root, f)
                    break
            if dxc_path:
                break
        
        if not dxc_path:
            print(f"  dxc.exe not found in package")
            continue
        
        print(f"  Found dxc.exe at: {dxc_path}")
        
        # Install to H:\llamadx\update\dxc_nuget
        install_dir = r"H:\llamadx\update\dxc_nuget"
        if os.path.exists(install_dir):
            shutil.rmtree(install_dir)
        os.makedirs(install_dir, exist_ok=True)
        
        # Copy all files
        for root, dirs, files in os.walk(extract_dir):
            for f in files:
                src = os.path.join(root, f)
                rel = os.path.relpath(src, extract_dir)
                dst = os.path.join(install_dir, rel)
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                shutil.copy2(src, dst)
        
        # Test
        dxc_exe = os.path.join(install_dir, "bin", "x64", "dxc.exe")
        if not os.path.exists(dxc_exe):
            for root, dirs, files in os.walk(install_dir):
                if "dxc.exe" in files and "x64" in root:
                    dxc_exe = os.path.join(root, "dxc.exe")
                    break
        
        if os.path.exists(dxc_exe):
            result = subprocess.run([dxc_exe, "--version"], capture_output=True, text=True)
            print(f"  Version: {result.stdout.strip()}")
            
            result = subprocess.run([dxc_exe, "-help"], capture_output=True, text=True)
            if "enable-work-graph" in result.stdout:
                print(f"  SUCCESS: -enable-work-graph flag found!")
                print(f"  SUCCESS: Installed dxc with Work Graphs support from version {version}")
                exit(0)
            else:
                print(f"  WARNING: -enable-work-graph flag NOT found")
                print(f"  Help output sample:", result.stdout[:500])
        else:
            print(f"  dxc.exe not found after install")
        break