@echo off
set ZEN_D3D12=1
set ZEN_D3D12_TRACE=1
H:\llamadx\update\zeninfer\build-dx12\zen_runtime_tests.exe H:\llamadx\models\Llama-3.2-1B-Instruct-Q8_0.gguf 2>&1 | findstr "flash"