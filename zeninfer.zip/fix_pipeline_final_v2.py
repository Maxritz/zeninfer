#!/usr/bin/env python3
"""
Surgical fix using verified line numbers.
"""

with open('src/adapters/dense_transformer_runtime.cpp', 'r') as f:
    lines = f.readlines()

# Verified line numbers (0-indexed from check_lines.py):
# 1187: reserve
# 1210: push_back
# 1212: else branch with all_layers_qualify = false
# 1217: if condition
# 1241: Also log
# 1249: second if (if(all_layers_qualify) {)
# 1252: } else {
# 1253: for loop

# We need to:
# 1. Add layer_qualifies after reserve (line 1187 -> insert at 1188)
# 2. Add layer_qualifies[l] = true after push_back (line 1210 -> insert at 1211)
# 3. Add layer_qualifies[l] = false in else branch (line 1212 -> modify)
# 4. Change if condition (line 1217 -> replace)
# 5. Remove all_layers_qualify=false in pipeline fail (find it)
# 6. Remove "Also log" block (lines 1241-1247)
# 7. Replace second if/else with for loop + skip (lines 1249-1253)
# 8. Remove one extra closing brace at end

# 1. Insert layer_qualifies after reserve
lines.insert(1188, '    std::vector<bool> layer_qualifies(config_.layers, false);\n')

# 2. Add layer_qualifies[l] = true after push_back (line 1210 -> insert at 1211)
lines.insert(1211, '            layer_qualifies[l] = true;\n')

# 3. Add layer_qualifies[l] = false in else branch (line 1212 -> modify)
lines[1212] = '            all_layers_qualify = false;\n            layer_qualifies[l] = false;\n'

# 4. Change if condition (line 1217 -> now 1218 due to inserts)
lines[1217] = '    // Run pipeline for any qualifying layers (not requiring all)\n    if(!pipeline_layers.empty()) {\n'

# 5. Remove all_layers_qualify = false in pipeline fail block
for i in range(1218, len(lines)):
    if 'all_layers_qualify = false;' in lines[i] and 'Pipeline failed' in ''.join(lines[max(0,i-5):i+3]):
        lines[i] = '            // all_layers_qualify no longer used for pipeline gating\n'
        print(f'Removed all_layers_qualify=false at line {i+1}')
        break

# 6. Remove "Also log" block (7 lines starting at line 1241)
also_log_start = None
for i, line in enumerate(lines):
    if 'Also log when not all layers qualify' in line:
        also_log_start = i
        break

if also_log_start is not None:
    for _ in range(7):
        lines.pop(also_log_start)
    print(f'Removed "Also log" block at line {also_log_start+1}')

# 7. Replace second if/else with for loop + skip
# Find the second if
second_if = None
for i, line in enumerate(lines):
    if line.strip() == 'if(all_layers_qualify) {' and i > 1200:
        second_if = i
        break

if second_if is not None:
    # Find the else before for
    else_pos = None
    for i in range(second_if, len(lines)):
        if lines[i].strip() == '} else {' and 'Whole layer in one device submission' in ''.join(lines[i+1:i+3]):
            else_pos = i
            break

    if else_pos is not None:
        # Find the for loop
        for_loop = None
        for i in range(else_pos, len(lines)):
            if 'for(std::uint32_t l=0;l<config_.layers;++l){' in lines[i] and 'const std::string p="blk."' in ''.join(lines[i+1:i+3]):
                for_loop = i
                break

        if for_loop is not None:
            # Find the end of the else block (matching brace)
            brace = 0
            else_end = -1
            for i in range(else_pos, len(lines)):
                for ch in lines[i]:
                    if ch == '{': brace += 1
                    elif ch == '}': brace -= 1
                if brace == 0:
                    else_end = i
                    break

            print(f'Second if at {second_if+1}, else at {else_pos+1}, for at {for_loop+1}, else_end at {else_end+1}')

            # Replace from second_if to else_end with new for loop
            body_lines = lines[for_loop+1:else_end]

            new_section = [
                '    // Per-layer path for non-qualifying layers\n',
                '    for(std::uint32_t l=0;l<config_.layers;++l){\n',
                '        if (layer_qualifies[l]) continue; // Skip layers already processed by pipeline\n',
            ] + body_lines

            # Replace
            new_lines = lines[:second_if] + new_section + lines[else_end+1:]

            # Remove ONE extra closing brace
            final_content = ''.join(new_lines)

            idx = final_content.find('\nbool DenseTransformerRuntime::generate(')
            if idx > 0:
                brace = 0
                for i in range(idx-1, max(0, idx-50), -1):
                    if final_content[i] == '}':
                        final_content = final_content[:i] + final_content[i+1:]
                        print(f'Removed extra }} at position {i}')
                        break

            with open('src/adapters/dense_transformer_runtime.cpp', 'w') as f:
                f.write(final_content)

            # Verify
            open_braces = 0
            for i, ch in enumerate(final_content):
                if ch == '{': open_braces += 1
                elif ch == '}':
                    open_braces -= 1
                    if open_braces < 0:
                        print(f'ERROR: Extra }} at position {i}')
                        break
            print(f'Final open braces: {open_braces}')
            print('Done!')
            exit(0)

print('Could not find all required markers')