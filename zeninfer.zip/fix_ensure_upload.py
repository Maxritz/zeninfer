with open(r'H:\llamadx\update\zeninfer\src\backends\d3d12\d3d12_backend.cpp', 'r') as f:
    content = f.read()

# Fix ensure_upload function signature and body
old = '''bool ensure_upload(ComPtr<ID3D12Resource>& buf, void*& cpu, std::size_t& cap,
                    ID3D12Device* device, std::size_t bytes) {
    if (buf && bytes <= cap) {
        return true;
    }
    buf.Reset();
    buf = create_buffer(device, bytes, upload_heap_type(), upload_heap_state());
    if (!buf || FAILED(buf->Map(0, nullptr, &cpu))) {
        cap = 0;
        return false;
    }
    cap = bytes;
    return true;
}'''

new = '''bool ensure_upload(ComPtr<ID3D12Resource>& buf, void*& cpu, std::size_t& cap,
                    State& s, std::size_t bytes) {
    if (buf && bytes <= cap) {
        return true;
    }
    buf.Reset();
    buf = create_buffer(s, bytes, upload_heap_type(), upload_heap_state());
    if (!buf || FAILED(buf->Map(0, nullptr, &cpu))) {
        cap = 0;
        return false;
    }
    cap = bytes;
    return true;
}'''

if old in content:
    content = content.replace(old, new)
    print("Replaced ensure_upload function")
else:
    print("Old text not found!")
    # Try to find it
    import re
    matches = list(re.finditer(r'bool ensure_upload\(ComPtr<ID3D12Resource>&', content))
    for m in matches:
        print(f"Found at line {content[:m.start()].count(chr(10)) + 1}")

# Fix call sites
content = content.replace('ensure_upload(s.wbuf, s.w_cpu, s.w_cap, s.device.Get(), hidden_bytes)',
                          'ensure_upload(s.wbuf, s.w_cpu, s.w_cap, s, hidden_bytes)')
content = content.replace('ensure_upload(s.nbuf, s.n_cpu, s.n_cap, s.device.Get(), hidden_bytes)',
                          'ensure_upload(s.nbuf, s.n_cpu, s.n_cap, s, hidden_bytes)')

with open(r'H:\llamadx\update\zeninfer\src\backends\d3d12\d3d12_backend.cpp', 'w') as f:
    f.write(content)

print("Done")