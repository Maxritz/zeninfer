with open('src/adapters/dense_transformer_runtime.cpp', 'r') as f:
    content = f.read()

# The exact byte positions we found earlier
old_start = 75739  # for loop start
old_end = 77044    # end of the }} after #endif

old_text = content[75739:77044]
print('OLD TEXT LENGTH:', len(old_text))
print('OLD TEXT:')
print(repr(old_text))

# The new text to replace with (using the exact same old text as key)
new_text = '''        // Collect all K/V pointers for batched KV cache append
        std::vector<std::size_t> kv_layers;
        std::vector<std::size_t> kv_positions;
        std::vector<const float*> kv_ks;
        std::vector<const float*> kv_vs;
        kv_layers.reserve(T);
        kv_positions.reserve(T);
        kv_ks.reserve(T);
        kv_vs.reserve(T);

        for(std::size_t t=0;t<T;++t){const std::uint32_t pos=start_pos+static_cast<std::uint32_t>(t);if(qnorm){qk_rms_norm(q.data()+t*QW,H,D,qnorm->values.data(),config_.rms_epsilon);qk_rms_norm(k.data()+t*KW,KH,D,knorm->values.data(),config_.rms_epsilon);}if(!config_.use_alibi){rope(q.data()+t*QW,H,D,config_.rope_dim,pos,config_.rope_base,config_.rope_scaling_type,config_.rope_scaling_factor,config_.rope_original_context,config_.rope_low_freq_factor,config_.rope_high_freq_factor,config_.rope_yarn_beta_fast,config_.rope_yarn_beta_slow);rope(k.data()+t*KW,KH,D,config_.rope_dim,pos,config_.rope_base,config_.rope_scaling_type,config_.rope_scaling_factor,config_.rope_original_context,config_.rope_low_freq_factor,config_.rope_high_freq_factor,config_.rope_yarn_beta_fast,config_.rope_yarn_beta_slow);}
            std::copy_n(k.data()+t*KW,KW,kc[l].data()+std::size_t(pos)*KW);std::copy_n(v.data()+t*KW,KW,vc[l].data()+std::size_t(pos)*KW);
            // Keep the device cache in step with the host one: decode reads the device
            // cache, so without this the prompt positions are missing from it and decode
            // attends over the wrong window. Not fatal if it fails - decode then falls
            // back to the host path, which uses kc/vc.
#if defined(ZEN_HAS_D3D12)
            if(!config_.use_alibi&&device_attention_available(config_.layers,kc[l].size()/KW,KH,D,config_.rms_epsilon)){
                kv_layers.push_back(l);
                kv_positions.push_back(pos);
                kv_ks.push_back(k.data()+t*KW);
                kv_vs.push_back(v.data()+t*KW);
            }
#endif
        }}
        // Batched KV cache append for this layer
#if defined(ZEN_HAS_D3D12)
        if(!kv_layers.empty() && !config_.use_alibi && device_attention_available(config_.layers,kc[l].size()/KW,KH,D,config_.rms_epsilon)){
            if (const char* trace = std::getenv("ZEN_D3D12_TRACE"); trace && trace[0] == '1') {
                std::printf("[d3d12] batched kv append (runtime): layer=%zu num_tokens=%zu\\n", l, kv_layers.size());
            }
            zen::d3d12::kv_cache_append_batched(kv_layers.data(), kv_layers.size(), kv_positions.data(), kv_ks.data(), kv_vs.data(), KH, D);
        }
#endif'''

# Verify the exact old text matches
old_text = content[75739:77044]
print('OLD TEXT LENGTH:', len(old_text))
print('OLD TEXT:')
print(old_text)

if old_text in content:
    new_content = content[:75739] + new_text + content[77044:]
    with open('src/adapters/dense_transformer_runtime.cpp', 'w') as f:
        f.write(new_content)
    print('Replacement done!')
else:
    print('Old text NOT found in content!')
    print('Expected length:', len(old_text))
    print('Content length:', len(content))
    print('First 200 chars of old_text:', repr(old_text[:200]))
    print('Content at 75739:', repr(content[75739:75900]))