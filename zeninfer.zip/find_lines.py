#!/usr/bin/env python3
"""
Even more careful surgical fix - explicit line-by-line with known line numbers from the backup.
"""

with open('src/adapters/dense_transformer_runtime.cpp.bak', 'r') as f:
    lines = f.readlines()

# From the backup, we know the exact structure:
# Line 1188: pipeline_layers.reserve(config_.layers);
# Line 1190-1215: for loop with qualification
# Line 1218: if(all_layers_qualify && pipeline_layers.size() == config_.layers) {
# Line 1228-1247: pipeline execution
# Line 1248: }
# Line 1250: if(all_layers_qualify) {
# Line 1252: } else {
# Line 1253: for(...)
# Line 1490: } (closes for)
# Line 1491: } (closes else)
# Line 1492: } (closes if)

# Convert to 0-indexed
# Insert layer_qualifies after line 1188 (0-indexed: 1187)
# Add layer_qualifies[l]=true after push_back (around line 1212)
# Add layer_qualifies[l]=false in else (around line 1214)
# Replace line 1218 (if condition)
# Remove all_layers_qualify=false in pipeline block (around line 1236)
# Remove "Also log when not all layers qualify" block (lines 1243-1247)
# Replace lines 1250-1252 (if/else) with for loop
# Remove one extra closing brace at the end

# Let's find exact positions
for i, line in enumerate(lines):
    if 'pipeline_layers.reserve(config_.layers);' in line:
        print(f"reserve at line {i+1} (0-indexed: {i})")
    if 'pipeline_layers.push_back(std::move(lp));' in line:
        print(f"push_back at line {i+1} (0-indexed: {i})")
    if 'all_layers_qualify = false;' in line and 'else' in lines[i-1]:
        print(f"all_layers_qualify=false in else at line {i+1} (0-indexed: {i})")
    if 'if(all_layers_qualify && pipeline_layers.size() == config_.layers)' in line:
        print(f"if condition at line {i+1} (0-indexed: {i})")
    if 'all_layers_qualify = false;' in line and 'Pipeline failed' in lines[i+2]:
        print(f"all_layers_qualify=false in pipeline at line {i+1} (0-indexed: {i})")
    if 'Also log when not all layers qualify' in line:
        print(f"'Also log' at line {i+1} (0-indexed: {i})")
    if 'if(all_layers_qualify) {' in line and 'Pipeline succeeded' in lines[i+1]:
        print(f"second if at line {i+1} (0-indexed: {i})")
    if line.strip() == '} else {' and 'Whole layer in one device submission' in lines[i+1]:
        print(f"else before for at line {i+1} (0-indexed: {i})")