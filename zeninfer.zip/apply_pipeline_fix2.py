with open('src/adapters/dense_transformer_runtime.cpp', 'r') as f:
    lines = f.readlines()

# Find the exact lines to replace
# Start: "    // Try to run all layers through the GPU pipeline (single submit+wait for all layers)"
# End: "        for(std::uint32_t l=0;l<config_.layers;++l){\n        const std::string p=\"blk.\"+std::to_string(l)+\".\";"

start_idx = -1
end_idx = -1

for i, line in enumerate(lines):
    if '// Try to run all layers through the GPU pipeline (single submit+wait for all layers)' in line:
        start_idx = i
        break

if start_idx == -1:
    print("Start not found!")
    exit(1)

for i in range(start_idx, len(lines)):
    if 'for(std::uint32_t l=0;l<config_.layers;++l){' in lines[i] and 'const std::string p="blk."+std::to_string(l)+".";' in lines[i+1]:
        end_idx = i
        break

if end_idx == -1:
    print("End not found!")
    exit(1)

print(f"Replacing lines {start_idx+1} to {end_idx+1}")

# Read replacement
with open('pipeline_fix_segment.cpp', 'r') as f:
    replacement_lines = f.readlines()

# Replace
new_lines = lines[:start_idx] + replacement_lines + lines[end_idx:]

with open('src/adapters/dense_transformer_runtime.cpp', 'w') as f:
    f.writelines(new_lines)

print("Replacement done!")

# Verify brace balance
open_braces = 0
for i, line in enumerate(new_lines):
    for ch in line:
        if ch == '{':
            open_braces += 1
        elif ch == '}':
            open_braces -= 1
            if open_braces < 0:
                print(f"ERROR: Extra }} at line {i+1}")
                exit(1)
print(f"Final open braces: {open_braces}")