import re

with open(r'H:\llamadx\update\zeninfer\src\backends\d3d12\d3d12_backend.cpp', 'r') as f:
    content = f.read()

# Replace s.pso_gemv.Get() with s.pso_gemv_fp32.Get() in the layer_decode and layer_decode_pipeline functions
# But NOT in the benchmark/diagnostic code or main gemv paths

# Find the two lambda functions in layer_decode_pipeline and layer_decode
# They have the pattern: list->SetPipelineState(s.pso_gemv.Get());
# or s.list->SetPipelineState(s.pso_gemv.Get());

# For layer_decode_pipeline (uses 'list' variable)
content = content.replace(
    'list->SetPipelineState(s.pso_gemv.Get());',
    'list->SetPipelineState(s.pso_gemv_fp32.Get());'
)

# For layer_decode (uses 's.list' variable)
content = content.replace(
    's.list->SetPipelineState(s.pso_gemv.Get());',
    's.list->SetPipelineState(s.pso_gemv_fp32.Get());'
)

with open(r'H:\llamadx\update\zeninfer\src\backends\d3d12\d3d12_backend.cpp', 'w') as f:
    f.write(content)

print("Done")