import urllib.request
import json
import gzip

# Search for dxc-related packages on NuGet
# Use the NuGet search API
search_url = "https://azuresearch-usnc.nuget.org/query?q=dxc&prerelease=true&semVerLevel=2.0.0"
req = urllib.request.Request(search_url)
req.add_header('Accept', 'application/json')
try:
    with urllib.request.urlopen(req) as response:
        content = response.read()
        if response.headers.get('Content-Encoding') == 'gzip':
            import gzip
            content = gzip.decompress(content)
        data = json.loads(content.decode('utf-8'))
        print(f"Total hits: {data.get('totalHits', 0)}")
        for package in data.get('data', [])[:20]:
            print(f"  {package['id']} - {package['version']} - {package.get('description', '')[:80]}")
except Exception as e:
    print(f"Search failed: {e}")

# Also try search for "DirectXShaderCompiler"
search_url2 = "https://azuresearch-usnc.nuget.org/query?q=DirectXShaderCompiler&prerelease=true&semVerLevel=2.0.0"
try:
    with urllib.request.urlopen(urllib.request.Request(search_url2, headers={'Accept': 'application/json'})) as response:
        content = response.read()
        if response.headers.get('Content-Encoding') == 'gzip':
            import gzip
            content = gzip.decompress(content)
        data = json.loads(content.decode('utf-8'))
        print(f"\nDirectXShaderCompiler hits: {data.get('totalHits', 0)}")
        for package in data.get('data', [])[:20]:
            print(f"  {package['id']} - {package['version']} - {package.get('description', '')[:80]}")
except Exception as e:
    print(f"Search failed: {e}")