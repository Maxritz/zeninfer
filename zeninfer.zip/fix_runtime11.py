with open('src/adapters/dense_transformer_runtime.cpp', 'r') as f:
    content = f.read()

start_idx = content.find('zen::diag::Scope scope_rope("transformer.prefill.rope",zen::diag::Phase::compute);', 75648)
print('Start:', start_idx)

end_idx = content.find('{zen::diag::Scope scope_attn("transformer.prefill.attention",zen::diag::Phase::compute);', start_idx)
print('End:', end_idx)

problematic = content[start_idx:end_idx]
print('Length:', len(problematic))
print('First 500:')
print(problematic[:500])
print('---')
print('Last 500:')
print(problematic[-500:])