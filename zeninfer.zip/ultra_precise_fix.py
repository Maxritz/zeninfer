#!/usr/bin/env python3
"""
Ultra-precise surgical fix using exact line numbers from backup.
"""

with open('src/adapters/dense_transformer_runtime.cpp.bak', 'r') as f:
    lines = f.readlines()

# 0-indexed line numbers:
reserve_line = 1187
push_back_line = 1210
else_qualify_line = 1212
if_condition_line = 1217
pipeline_fail_line = 1235
also_log_start = 1241
second_if_line = 1249
else_before_for_line = 1251  # (need to find)
for_loop_line = 1252
# Find else block end
else_start = -1
for i, line in enumerate(lines):
    if line.strip() == '} else {' and 'Whole layer in one device submission' in lines[i+1]:
        else_start = i
        break

if else_start >= 0:
    brace = 0
    for i in range(else_start, len(lines)):
        for ch in lines[i]:
            if ch == '{': brace += 1
            elif ch == '}': brace -= 1
        if brace == 0:
            else_end = i
            print(f"else block: {else_start+1} to {else_end+1}")
            break

print(f"Reserve: {reserve_line+1}")
print(f"Push_back: {push_back_line+1}")
print(f"Else qualify: {else_qualify_line+1}")
print(f"If condition: {if_condition_line+1}")
print(f"Pipeline fail: {pipeline_fail_line+1}")
print(f"Also log start: {also_log_start+1}")
print(f"Second if: {second_if_line+1}")
print(f"Else before for: {else_before_for_line+1}")
print(f"For loop: {for_loop_line+1}")
print(f"Else block: {else_start+1} to {else_end+1}")

# Now make the edits
new_lines = lines.copy()

# 1. Insert layer_qualifies after reserve (line 1187)
new_lines.insert(reserve_line + 1, '    std::vector<bool> layer_qualifies(config_.layers, false);\n')
print("1. Inserted layer_qualifies")

# 2. Add layer_qualifies[l] = true after push_back (line 1210 -> now 1211 due to insert)
new_lines.insert(push_back_line + 2, '            layer_qualifies[l] = true;\n')
print("2. Added layer_qualifies[l]=true")

# 3. Add layer_qualifies[l] = false in else branch (line 1212 -> now 1213)
# The else branch is at line 1212, we need to add after "all_layers_qualify = false;"
# Find the exact line with "all_layers_qualify = false;" in the else branch
# It's at else_qualify_line (1212), we replace that line
new_lines[else_qualify_line] = '            all_layers_qualify = false;\n            layer_qualifies[l] = false;\n'
print("3. Added layer_qualifies[l]=false in else")

# 4. Replace if condition (line 1217 -> now 1218)
new_lines[if_condition_line + 1] = '    // Run pipeline for any qualifying layers (not requiring all)\n    if(!pipeline_layers.empty()) {\n'
print("4. Changed if condition")

# 5. Replace pipeline fail all_layers_qualify=false (line 1235 -> now 1236)
new_lines[pipeline_fail_line + 1] = '            // all_layers_qualify no longer used for pipeline gating\n'
print("5. Removed all_layers_qualify=false in pipeline fail")

# 6. Remove "Also log" block (lines 1241-1247 -> now shifted)
# The block is 7 lines: 1241-1247
# After our inserts, lines shifted by +2 (2 inserts before)
also_log_start_adj = also_log_start + 2
# Delete 7 lines
for _ in range(7):
    new_lines.pop(also_log_start_adj)
print("6. Removed 'Also log' block")

# 7. Replace the second if/else block with for loop
# second_if_line was 1249, shifted by +2 - 7 = -5 -> 1244
second_if_adj = second_if_line + 2 - 7
# Find the "if(all_layers_qualify) {" line
for i in range(second_if_adj, min(second_if_adj+20, len(new_lines))):
    if 'if(all_layers_qualify) {' in new_lines[i] and 'Pipeline succeeded' in new_lines[i+1]:
        second_if_adj = i
        break

# The else block starts at else_before_for_line (1251), shifted
else_before_for_adj = else_before_for_line + 2 - 7
for i in range(second_if_adj, min(second_if_adj+30, len(new_lines))):
    if new_lines[i].strip() == '} else {' and 'Whole layer in one device submission' in new_lines[i+1]:
        else_before_for_adj = i
        break

print(f"Second if at new line {second_if_adj+1}")
print(f"Else before for at new line {else_before_for_adj+1}")

# Replace from second_if_adj to else_before_for_adj (inclusive) with new for loop
replacement = [
    '    // Per-layer path for non-qualifying layers\n',
    '    for(std::uint32_t l=0;l<config_.layers;++l){\n',
    '        if (layer_qualifies[l]) continue; // Skip layers already processed by pipeline\n',
    '        const std::string p="blk."+std::to_string(l)+".\";\n'
]

# We need to delete from second_if_adj to the line BEFORE the for loop
# The original has: if(...) { } else { for(...) { ... } }
# We want: for(...) { if(...) continue; ... }
# The closing braces: original had } (if) + } (else) = 2 closing braces
# New has: } (for) = 1 closing brace
# But the for loop body is the same, so we need to remove one extra closing brace at the end

# Find the end of the else block (matching brace for the else)
# The else block ends at the line where brace returns to 0 from the else_start
# We already found else_start and else_end in the original
# After our deletions/insertions, the positions shifted

# Let's just replace the whole second_if_adj to else_end_adj with our new for loop
# and remove ONE extra closing brace later

# First, find the end of the else block in new_lines
brace = 0
else_end_adj = -1
for i in range(else_before_for_adj, len(new_lines)):
    for ch in new_lines[i]:
        if ch == '{': brace += 1
        elif ch == '}': brace -= 1
    if brace == 0:
        else_end_adj = i
        break

print(f"Else block in new_lines: {else_before_for_adj+1} to {else_end_adj+1}")

# Replace from second_if_adj to else_end_adj with new for loop + its body
# But we need to KEEP the for loop body (the existing code from for_loop_line onwards)
# The for loop body starts at for_loop_line (1252 -> adjusted)

# Actually, the simplest: replace second_if_adj to else_end_adj with:
# for(...) { if(layer_qualifies[l]) continue; [existing body] }
# The existing body is from for_loop_line to else_end_adj

# Get the existing for loop body (from for_loop_line_adj to else_end_adj)
for_loop_adj = for_loop_line + 2 - 7  # rough adjustment
for i in range(else_before_for_adj, min(else_before_for_adj+20, len(new_lines))):
    if 'for(std::uint32_t l=0;l<config_.layers;++l){' in new_lines[i]:
        for_loop_adj = i
        break

print(f"For loop at new line {for_loop_adj+1}")

# The body is from for_loop_adj to else_end_adj
# We want to replace second_if_adj to else_end_adj with:
# for(std::uint32_t l=0;l<config_.layers;++l){
#     if (layer_qualifies[l]) continue;
#     [body from for_loop_adj+1 to else_end_adj-1]
# }

# But we need to be careful with braces. The body already has its own closing brace.
# Original structure:
# if(...) { } else { for(...) { body } }
# Braces: if-open, if-close, else-open, for-open, for-close, else-close
# New structure:
# for(...) { if(...) continue; body }
# Braces: for-open, for-close

# So we remove: if-open, if-close, else-open, else-close (4 braces)
# Add: for-open, for-close (2 braces)
# Net: -2 closing braces

# Let's build the new section
body_lines = new_lines[for_loop_adj+1:else_end_adj]  # exclude the for(...) { line and the final }

new_section = [
    '    // Per-layer path for non-qualifying layers\n',
    '    for(std::uint32_t l=0;l<config_.layers;++l){\n',
    '        if (layer_qualifies[l]) continue; // Skip layers already processed by pipeline\n',
] + body_lines

# Replace
final_lines = new_lines[:second_if_adj] + new_section + new_lines[else_end_adj+1:]

# Now we need to remove ONE extra closing brace (since we removed if/else but kept for)
# The final_lines should have one extra } at the end of this section
# Find and remove one extra } after the for loop body
brace = 0
extra_brace = -1
for i in range(len(final_lines)-1, -1, -1):
    for ch in final_lines[i]:
        if ch == '}': brace += 1
        elif ch == '{': brace -= 1
    if brace == 0:
        extra_brace = i
        break

if extra_brace >= 0:
    final_lines.pop(extra_brace)
    print(f"Removed extra }} at line {extra_brace+1}")

# Verify brace balance
open_braces = 0
for i, line in enumerate(final_lines):
    for ch in line:
        if ch == '{': open_braces += 1
        elif ch == '}': 
            open_braces -= 1
            if open_braces < 0:
                print(f"ERROR: Extra }} at line {i+1}: {final_lines[i].strip()[:80]}")
                break
print(f"Final open braces: {open_braces}")

with open('src/adapters/dense_transformer_runtime.cpp', 'w') as f:
    f.writelines(final_lines)

print("Done!")