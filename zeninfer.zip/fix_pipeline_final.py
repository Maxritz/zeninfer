#!/usr/bin/env python3
"""
Surgical fix using verified line numbers.
"""

with open('src/adapters/dense_transformer_runtime.cpp', 'r') as f:
    lines = f.readlines()

# Line numbers from current file (0-indexed):
# 1187: reserve
# 1210: push_back
# 1212: else branch with all_layers_qualify = false
# 1217: if condition
# 1241: Also log
# 1249: second if (if(all_layers_qualify) {)
# 1251: } else {
# 1252: for loop
# 1414: } (closes for)
# 1415: } (closes else)
# 1416: } (closes if)

# 1. Insert layer_qualifies after reserve
lines.insert(1188, '    std::vector<bool> layer_qualifies(config_.layers, false);\n')

# 2. Add layer_qualifies[l] = true after push_back
lines.insert(1211, '            layer_qualifies[l] = true;\n')

# 3. Add layer_qualifies[l] = false in else branch
lines[1212] = '            all_layers_qualify = false;\n            layer_qualifies[l] = false;\n'

# 4. Change if condition
lines[1217] = '    // Run pipeline for any qualifying layers (not requiring all)\n    if(!pipeline_layers.empty()) {\n'

# 5. Remove all_layers_qualify = false in pipeline fail block
for i in range(1218, len(lines)):
    if 'all_layers_qualify = false;' in lines[i] and 'Pipeline failed' in ''.join(lines[max(0,i-5):i+3]):
        lines[i] = '            // all_layers_qualify no longer used for pipeline gating\n'
        print('Removed all_layers_qualify=false at line', i+1)
        break

# 6. Remove "Also log" block (7 lines starting at line 1241)
also_log_start = None
for i, line in enumerate(lines):
    if 'Also log when not all layers qualify' in line:
        also_log_start = i
        break

if also_log_start is not None:
    for _ in range(7):
        lines.pop(also_log_start)
    print('Removed "Also log" block at line', also_log_start+1)

# 7. Replace second if/else with for loop + skip
second_if = None
for i, line in enumerate(lines):
    if line.strip() == 'if(all_layers_qualify) {' and i > 1200:
        second_if = i
        break

if second_if is not None:
    else_pos = None
    for i in range(second_if, len(lines)):
        if lines[i].strip() == '} else {' and 'Whole layer in one device submission' in ''.join(lines[i+1:i+3]):
            else_pos = i
            break

    if else_pos is not None:
        for_loop = None
        for i in range(else_pos, len(lines)):
            if 'for(std::uint32_t l=0;l<config_.layers;++l){' in lines[i] and 'const std::string p="blk."' in ''.join(lines[i+1:i+3]):
                for_loop = i
                break

        if for_loop is not None:
            brace = 0
            else_end = -1
            for i in range(else_pos, len(lines)):
                for ch in lines[i]:
                    if ch == '{': brace += 1
                    elif ch == '}': brace -= 1
                if brace == 0:
                    else_end = i
                    break

            print('Second if at', second_if+1, 'else at', else_pos+1, 'for at', for_loop+1, 'else_end at', else_end+1)

            body_lines = lines[for_loop+1:else_end]

            new_section = [
                '    // Per-layer path for non-qualifying layers\n',
                '    for(std::uint32_t l=0;l<config_.layers;++l){\n',
                '        if (layer_qualifies[l]) continue; // Skip layers already processed by pipeline\n',
            ] + body_lines

            new_lines = lines[:second_if] + new_section + lines[else_end+1:]

            final_content = ''.join(new_lines)

            idx = final_content.find('\nbool DenseTransformerRuntime::generate(')
            if idx > 0:
                brace = 0
                for i in range(idx-1, max(0, idx-50), -1):
                    if final_content[i] == '}':
                        final_content = final_content[:i] + final_content[i+1:]
                        print('Removed extra } at position', i)
                        break

            with open('src/adapters/dense_transformer_runtime.cpp', 'w') as f:
                f.write(final_content)

            open_braces = 0
            for i, ch in enumerate(final_content):
                if ch == '{': open_braces += 1
                elif ch == '}':
                    open_braces -= 1
                    if open_braces < 0:
                        print('ERROR: Extra } at position', i)
                        break
            print('Final open braces:', open_braces)
            print('Done!')
            exit(0)

print('Could not find all required markers')