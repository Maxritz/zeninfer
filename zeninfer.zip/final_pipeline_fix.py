with open('src/adapters/dense_transformer_runtime.cpp', 'r') as f:
    content = f.read()

# Make ONLY textual changes that don't affect brace structure

# 1. Add layer_qualifies declaration after pipeline_layers.reserve
old1 = '    std::vector<LayerParams> pipeline_layers;\n    pipeline_layers.reserve(config_.layers);'
new1 = '    std::vector<LayerParams> pipeline_layers;\n    pipeline_layers.reserve(config_.layers);\n    std::vector<bool> layer_qualifies(config_.layers, false);'
content = content.replace(old1, new1)
print("1. Added layer_qualifies declaration")

# 2. Add layer_qualifies[l] = true after pipeline_layers.push_back
old2 = '            pipeline_layers.push_back(std::move(lp));\n        } else {'
new2 = '            pipeline_layers.push_back(std::move(lp));\n            layer_qualifies[l] = true;\n        } else {'
content = content.replace(old2, new2)
print("2. Added layer_qualifies[l]=true")

# 3. Add layer_qualifies[l] = false in the else branch
# Find the specific occurrence in the qualification loop
old3 = '''            all_layers_qualify = false;
        }
    }

    // If all layers qualify'''
new3 = '''            all_layers_qualify = false;
            layer_qualifies[l] = false;
        }
    }

    // If all layers qualify'''
content = content.replace(old3, new3)
print("3. Added layer_qualifies[l]=false")

# 4. Change pipeline condition
old4 = 'if(all_layers_qualify && pipeline_layers.size() == config_.layers) {'
new4 = '// Run pipeline for any qualifying layers (not requiring all)\n    if(!pipeline_layers.empty()) {'
content = content.replace(old4, new4)
print("4. Changed pipeline condition")

# 5. Remove all_layers_qualify = false inside pipeline block
old5 = '            all_layers_qualify = false;\n            if (const char* trace = std::getenv("ZEN_D3D12_TRACE"); trace && trace[0] == \'1\') {'
new5 = '            // all_layers_qualify no longer used for pipeline gating\n            if (const char* trace = std::getenv("ZEN_D3D12_TRACE"); trace && trace[0] == \'1\') {'
content = content.replace(old5, new5)
print("5. Removed all_layers_qualify=false in pipeline block")

# 6. Remove the "Also log when not all layers qualify" block
old6 = '''        }
        
        // Also log when not all layers qualify
        if (!all_layers_qualify && pipeline_layers.size() < config_.layers) {
            if (const char* trace = std::getenv("ZEN_D3D12_TRACE"); trace && trace[0] == '1') {
                std::printf("[d3d12] pipeline: NOT ALL QUALIFY pipeline_layers=%zu vs config_.layers=%zu\\n", pipeline_layers.size(), config_.layers);
            }
        }
    }'''
new6 = '''        }
    }'''
content = content.replace(old6, new6)
print("6. Removed 'not all qualify' log block")

# 7. Change the second if to always run per-layer but skip qualifying
old7 = '''    if(all_layers_qualify) {
        // Pipeline succeeded, skip per-layer path
    } else {
        for(std::uint32_t l=0;l<config_.layers;++l){
        const std::string p="blk."+std::to_string(l)+".";'''
new7 = '''    // Per-layer path for non-qualifying layers
    for(std::uint32_t l=0;l<config_.layers;++l){
        if (layer_qualifies[l]) continue; // Skip layers already processed by pipeline
        const std::string p="blk."+std::to_string(l)+".";'''
content = content.replace(old7, new7)
print("7. Changed per-layer loop to skip qualifying layers")

# 8. Remove the "} else {" line before the per-layer loop
# The original has: } else { for(...)
# After step 7, we have the for loop directly, but there's still a "} else {" before it
old8 = '''    }
    } else {
        for(std::uint32_t l=0;l<config_.layers;++l){
        const std::string p="blk."+std::to_string(l)+".";'''
# This won't match because step 7 already changed it

# Instead, find and remove the standalone "} else {" that's now orphaned
# It should be right before our new for loop
old8b = '    }\n    } else {\n'
new8b = '    }\n'
# But this might match multiple places. Let's be more specific.

# The pattern is: the old code had:
#     }  // closes first if
#     } else {  // this is what we want to remove
#         for(...) {
# 
# After step 7, we have:
#     }  // closes first if
#     // Per-layer path...
#     for(...) {
# 
# But there's still a "} else {" between them from the original code
# Let's find the specific occurrence

# Actually, let's just do a more careful replacement for the second if-else block
# The original second if-else was:
#     if(all_layers_qualify) {
#         // Pipeline succeeded, skip per-layer path
#     } else {
#         for(...) { ... }
#     }
# We want to replace the ENTIRE block with just the for loop

old9 = '''    if(all_layers_qualify) {
        // Pipeline succeeded, skip per-layer path
    } else {
        for(std::uint32_t l=0;l<config_.layers;++l){
        const std::string p="blk."+std::to_string(l)+".";'''
new9 = '''    // Per-layer path for non-qualifying layers
    for(std::uint32_t l=0;l<config_.layers;++l){
        if (layer_qualifies[l]) continue; // Skip layers already processed by pipeline
        const std::string p="blk."+std::to_string(l)+".";'''
content = content.replace(old9, new9)
print("9. Replaced entire second if-else with for loop")

# Now we need to remove TWO extra closing braces that were for the if and else
# The original had: } (if) + } (else) = 2 closing braces at the end of the per-layer section
# Now we only need: } (for loop) = 1 closing brace
# So we need to remove ONE extra closing brace

# Find the end of the per-layer section - it's before the next function
# The per-layer section ends before "bool DenseTransformerRuntime::generate"
# We need to remove one extra "}" from that area

# Let's write the content and then fix brace balance by removing one extra }
with open('src/adapters/dense_transformer_runtime.cpp', 'w') as f:
    f.write(content)

print("All textual changes applied!")

# Now fix brace balance by removing one extra } 
with open('src/adapters/dense_transformer_runtime.cpp', 'r') as f:
    lines = f.readlines()

# Find the generate function and remove one extra } before it
for i in range(len(lines)-1, 0, -1):
    if 'bool DenseTransformerRuntime::generate(' in lines[i]:
        # Found generate function, look backwards for extra }
        for j in range(i-1, max(0, i-20), -1):
            if lines[j].strip() == '}':
                # Check if this is an extra brace (not matching a {)
                # Look at context - if the previous non-empty line is also a }, it might be extra
                lines.pop(j)
                print(f"Removed extra }} at line {j+1}")
                break
        break

with open('src/adapters/dense_transformer_runtime.cpp', 'w') as f:
    f.writelines(lines)

# Verify brace balance
with open('src/adapters/dense_transformer_runtime.cpp', 'r') as f:
    content = f.read()

open_braces = 0
for i, ch in enumerate(content):
    if ch == '{':
        open_braces += 1
    elif ch == '}':
        open_braces -= 1
        if open_braces < 0:
            line_num = content[:i].count('\n') + 1
            print(f"ERROR: Extra }} at position {i} (line {line_num})")
            break
print(f"Final open braces: {open_braces}")