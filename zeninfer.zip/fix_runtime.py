import re

with open('src/adapters/dense_transformer_runtime.cpp', 'r') as f:
    content = f.read()

old = '''{zen::diag::Scope scope_rope("transformer.prefill.rope",zen::diag::Phase::compute);
        for(std::size_t t=0;t<T;++t){const std::uint32_t pos=start_pos+static_cast<std::uint32_t>(t);if(qnorm){qk_rms_norm(q.data()+t*QW,H,D,qnorm->values.data(),config_.rms_epsilon);qk_rms_norm(k.data()+t*KW,KH,D,knorm->values.data(),config_.rms_epsilon);}if(!config_.use_alibi){rope(q.data()+t*QW,H,D,config_.rope_dim,pos,config_.rope_base,config_.rope_scaling_type,config_.rope_scaling_factor,config_.rope_original_context,config_.rope_low_freq_factor,config_.rope_high_freq_factor,config_.rope_yarn_beta_fast,config_.rope_yarn_beta_slow);rope(k.data()+t*KW,KH,D,config_.rope_dim,pos,config_.rope_base,config_.rope_scaling_type,config_.rope_scaling_factor,config_.rope_original_context,config_.rope_low_freq_factor,config_.rope_high_freq_factor,config_.rope_yarn_beta_fast,config_.rope_yarn_beta_slow);}
            std::copy_n(k.data()+t*KW,KW,kc[l].data()+std::size_t(pos)*KW);std::copy_n(v.data()+t*KW,KW,vc[l].data()+std::size_t(pos)*KW);
            // Keep the device cache in step with the host one: decode reads the device
            // cache, so without this the prompt positions are missing from it and decode
            // attends over the wrong window. Not fatal if it fails - decode then falls
            // back to the host path, which uses kc/vc.
#if defined(ZEN_HAS_D3D12)
            if(!config_.use_alibi&&device_attention_available(config_.layers,kc[l].size()/KW,KH,D,config_.rms_epsilon))zen::d3d12::kv_cache_append(l,pos,k.data()+t*KW,v.data()+t*KW,KH,D);
#endif
        }}
        {zen::diag::Scope scope_attn("transformer.prefill.attention",zen::diag::Phase::compute);'''

new = '''{zen::diag::Scope scope_rope("transformer.prefill.rope",zen::diag::Phase::compute);
        // Collect all K/V pointers for batched KV cache append
        std::vector<std::size_t> kv_layers;
        std::vector<std::size_t> kv_positions;
        std::vector<const float*> kv_ks;
        std::vector<const float*> kv_vs;
        kv_layers.reserve(T);
        kv_positions.reserve(T);
        kv_ks.reserve(T);
        kv_vs.reserve(T);

        for(std::size_t t=0;t<T;++t){const std::uint32_t pos=start_pos+static_cast<std::uint32_t>(t);if(qnorm){qk_rms_norm(q.data()+t*QW,H,D,qnorm->values.data(),config_.rms_epsilon);qk_rms_norm(k.data()+t*KW,KH,D,knorm->values.data(),config_.rms_epsilon);}if(!config_.use_alibi){rope(q.data()+t*QW,H,D,config_.rope_dim,pos,config_.rope_base,config_.rope_scaling_type,config_.rope_scaling_factor,config_.rope_original_context,config_.rope_low_freq_factor,config_.rope_high_freq_factor,config_.rope_yarn_beta_fast,config_.rope_yarn_beta_slow);rope(k.data()+t*KW,KH,D,config_.rope_dim,pos,config_.rope_base,config_.rope_scaling_type,config_.rope_scaling_factor,config_.rope_original_context,config_.rope_low_freq_factor,config_.rope_high_freq_factor,config_.rope_yarn_beta_fast,config_.rope_yarn_beta_slow);}
            std::copy_n(k.data()+t*KW,KW,kc[l].data()+std::size_t(pos)*KW);std::copy_n(v.data()+t*KW,KW,vc[l].data()+std::size_t(pos)*KW);
            // Keep the device cache in step with the host one: decode reads the device
            // cache, so without this the prompt positions are missing from it and decode
            // attends over the wrong window. Not fatal if it fails - decode then falls
            // back to the host path, which uses kc/vc.
#if defined(ZEN_HAS_D3D12)
            if(!config_.use_alibi&&device_attention_available(config_.layers,kc[l].size()/KW,KH,D,config_.rms_epsilon)){
                kv_layers.push_back(l);
                kv_positions.push_back(pos);
                kv_ks.push_back(k.data()+t*KW);
                kv_vs.push_back(v.data()+t*KW);
            }
#endif
        }}
        // Batched KV cache append for this layer
#if defined(ZEN_HAS_D3D12)
        if(!kv_layers.empty() && !config_.use_alibi && device_attention_available(config_.layers,kc[l].size()/KW,KH,D,config_.rms_epsilon)){
            if (const char* trace = std::getenv("ZEN_D3D12_TRACE"); trace && trace[0] == '1') {
                std::printf("[d3d12] batched kv append (runtime): layer=%zu num_tokens=%zu\n", l, kv_layers.size());
            }
            zen::d3d12::kv_cache_append_batched(kv_layers.data(), kv_layers.size(), kv_positions.data(), kv_ks.data(), kv_vs.data(), KH, D);
        }
#endif
        {zen::diag::Scope scope_attn("transformer.prefill.attention",zen::diag::Phase::compute);'''

with open('src/adapters/dense_transformer_runtime.cpp', 'r') as f:
    content = f.read()

if old in content:
    content = content.replace(old, new)
    with open('src/adapters/dense_transformer_runtime.cpp', 'w') as f:
        f.write(content)
    print('Replacement done!')
else:
    print('Old text not found!')
    # Try to find what's there
    idx = content.find('for(std::size_t t=0;t<T;++t)')
    if idx >= 0:
        print('Found at index:', idx)
        print(content[idx:idx+500])
    else:
        print('Not found at all')