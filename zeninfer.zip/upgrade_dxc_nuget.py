#!/usr/bin/env python3
"""
Try to get dxc with Work Graphs support via NuGet package.
"""
import os
import sys
import urllib.request
import zipfile
import shutil
import subprocess
import tempfile
import json

NUGET_API = "https://api.nuget.org/v3/registration5-gz-semver2/microsoft.directx.dxc/index.json"

def get_nuget_versions():
    """Get available versions from NuGet."""
    try:
        with urllib.request.urlopen(NUGET_API) as response:
            data = json.load(response)
            versions = []
            for page in data.get('items', []):
                for item in page.get('items', []):
                    version = item.get('catalogEntry', {}).get('version')
                    if version:
                        versions.append(version)
            return versions
    except Exception as e:
        print(f"Failed to fetch NuGet versions: {e}")
        return []

def download_nuget_package(version):
    """Download and extract NuGet package."""
    url = f"https://www.nuget.org/api/v2/package/Microsoft.DirectX.DXC/{version}"
    
    with tempfile.TemporaryDirectory() as tmpdir:
        nupkg_path = os.path.join(tmpdir, f"dxc_{version}.nupkg")
        
        try:
            print(f"Downloading Microsoft.DirectX.DXC {version} from NuGet...")
            urllib.request.urlretrieve(url, nupkg_path)
        except urllib.error.HTTPError as e:
            if e.code == 404:
                print(f"Version {version} not found on NuGet")
                return False
            raise
        
        # nupkg is a zip file
        extract_dir = os.path.join(tempfile.gettempdir(), f"dxc_nuget_{version}")
        if os.path.exists(extract_dir):
            shutil.rmtree(extract_dir)
        os.makedirs(extract_dir)
        
        with zipfile.ZipFile(nupkg_path, 'r') as zf:
            zf.extractall(extract_dir)
        
        # Find dxc.exe in tools/x64 or similar
        dxc_path = None
        for root, dirs, files in os.walk(extract_dir):
            for f in files:
                if f == "dxc.exe":
                    dxc_path = os.path.join(root, f)
                    break
            if dxc_path:
                break
        
        if not dxc_path:
            print("ERROR: dxc.exe not found in NuGet package")
            return False
        
        # Install to H:\llamadx\dxc_nuget
        install_dir = r"H:\llamadx\dxc_nuget"
        if os.path.exists(install_dir):
            shutil.rmtree(install_dir)
        os.makedirs(install_dir, exist_ok=True)
        
        # Copy the tools folder structure
        tools_dir = os.path.dirname(os.path.dirname(dxc_path))
        for root, dirs, files in os.walk(tools_dir):
            for f in files:
                src = os.path.join(root, f)
                rel = os.path.relpath(src, extract_dir)
                dst = os.path.join(install_dir, rel)
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                shutil.copy2(src, dst)
        
        # Test
        dxc_exe = os.path.join(install_dir, "x64", "dxc.exe")
        if not os.path.exists(dxc_exe):
            # Find dxc.exe
            for root, dirs, files in os.walk(install_dir):
                if "dxc.exe" in files:
                    dxc_exe = os.path.join(root, "dxc.exe")
                    break
        
        if not os.path.exists(dxc_exe):
            print("ERROR: dxc.exe not found after install")
            return False
        
        result = subprocess.run([dxc_exe, "--version"], capture_output=True, text=True)
        print(f"Version: {result.stdout.strip()}")
        
        # Test Work Graphs support
        result = subprocess.run([dxc_exe, "-help"], capture_output=True, text=True)
        if "enable-work-graph" in result.stdout:
            print("SUCCESS: -enable-work-graph flag found!")
            return True
        else:
            print("WARNING: -enable-work-graph flag NOT found")
            return False

def main():
    print("Fetching NuGet versions for Microsoft.DirectX.DXC...")
    versions = get_nuget_versions()
    print(f"Found {len(versions)} versions")
    
    # Filter for 1.8.x and later
    candidates = [v for v in versions if v.startswith(('1.8.', '1.9.'))]
    candidates.sort(key=lambda x: tuple(map(int, x.split('.')[:3])), reverse=True)
    
    print(f"Candidate versions: {candidates[:10]}")
    
    for version in candidates:
        if download_nuget_package(version):
            print(f"\nSUCCESS: dxc {version} with Work Graphs support installed!")
            print(f"Installed to: H:\\llamadx\\dxc_nuget")
            return
    
    print("FAILED: Could not find working dxc with Work Graphs support")
    sys.exit(1)

if __name__ == "__main__":
    main()