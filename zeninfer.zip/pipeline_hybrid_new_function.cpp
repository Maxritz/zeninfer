/**
 * Hybrid Pipeline Execution - New Function Approach
 * 
 * This implements the hybrid pipeline logic as a separate function
 * to avoid brace matching issues in the main forward function.
 */

// Add this function to dense_transformer_runtime.cpp (or a new file)
// Returns true if any pipeline segments executed successfully
bool execute_hybrid_pipeline(
    const std::vector<std::uint32_t>& tokens,
    std::vector<std::vector<float>>& kc,
    std::vector<std::vector<float>>& vc,
    std::vector<float>& logits,
    std::uint32_t pos,
    const RuntimeConfig& config,
    const std::vector<LayerParams>& pipeline_layers,
    const std::vector<float>& x_data,
    std::size_t E, std::size_t H, std::size_t KH, std::size_t D, std::size_t F,
    float rms_epsilon
) {
    if (pipeline_layers.empty()) {
        return false;
    }
    
    std::vector<bool> layer_qualifies(config.layers, false);
    for (const auto& lp : pipeline_layers) {
        if (lp.layer < config.layers) {
            layer_qualifies[lp.layer] = true;
        }
    }
    
    bool any_pipeline_ok = false;
    std::size_t pipeline_start = 0;
    
    while (pipeline_start < config.layers) {
        // Find next qualifying layer
        while (pipeline_start < config.layers && !layer_qualifies[pipeline_start]) {
            ++pipeline_start;
        }
        if (pipeline_start >= config.layers) break;
        
        // Find end of contiguous qualifying segment
        std::size_t pipeline_end = pipeline_start;
        while (pipeline_end < config.layers && layer_qualifies[pipeline_end]) {
            ++pipeline_end;
        }
        
        // Run pipeline for layers [pipeline_start, pipeline_end)
        std::size_t segment_size = pipeline_end - pipeline_start;
        zen::d3d12::LayerDecodeParams d3d_layers[64];
        for (std::size_t i = 0; i < segment_size; ++i) {
            auto& lp = pipeline_layers[pipeline_start + i];
            d3d_layers[i].q_w = lp.q_w; 
            d3d_layers[i].k_w = lp.k_w; 
            d3d_layers[i].v_w = lp.v_w; 
            d3d_layers[i].o_w = lp.o_w;
            d3d_layers[i].gate_w = lp.gate_w; 
            d3d_layers[i].up_w = lp.up_w; 
            d3d_layers[i].down_w = lp.down_w;
            d3d_layers[i].attn_norm_w = lp.attn_norm_w; 
            d3d_layers[i].ffn_norm_w = lp.ffn_norm_w;
            d3d_layers[i].cos = lp.cos.data(); 
            d3d_layers[i].sin = lp.sin.data();
            d3d_layers[i].pairs = lp.pairs; 
            d3d_layers[i].layer = lp.layer; 
            d3d_layers[i].pos = lp.pos; 
            d3d_layers[i].first_pos = lp.first_pos;
        }
        
        bool segment_ok = zen::d3d12::layer_decode_pipeline(
            d3d_layers, segment_size, 
            const_cast<float*>(x_data.data()), 
            const_cast<float*>(x_data.data()), 
            E, H, KH, D, F, rms_epsilon
        );
        
        if (segment_ok) {
            // Note: layer_qualifies tracking would need to be done by caller
            // or we need a different approach for failure tracking
            return true; // Success - at least one segment worked
        }
        
        pipeline_start = pipeline_end;
    }
    
    return false;
}

/**
 * Simpler approach: Modify the existing forward function with MINIMAL changes
 * 
 * The key insight: we only need to change the PIPELINE CONDITION and add 
 * a SKIP CHECK in the per-layer loop. Everything else stays the same.
 * 
 * Changes needed in forward function (around line 1218):
 * 
 * OLD:
 *     if(all_layers_qualify && pipeline_layers.size() == config_.layers) {
 * 
 * NEW:
 *     if(!pipeline_layers.empty()) {
 * 
 * And in the per-layer loop (around line 1253):
 * 
 * OLD:
 *     if(all_layers_qualify) { ... } else {
 *         for(...) { ... }
 *     }
 * 
 * NEW:
 *     for(std::uint32_t l=0; l<config_.layers; ++l){
 *         if (/* layer was processed by pipeline */) continue;
 *         // rest of per-layer code unchanged
 * 
 * To track which layers were processed, we need a layer_qualifies vector.
 * 
 * MINIMAL CHANGES:
 * 1. Add: std::vector<bool> layer_qualifies(config_.layers, false); after pipeline_layers.reserve
 * 2. Add: layer_qualifies[l] = true; after pipeline_layers.push_back
 * 3. Add: layer_qualifies[l] = false; in the else branch
 * 4. Change: if(all_layers_qualify && pipeline_layers.size() == config_.layers) 
 *            to: if(!pipeline_layers.empty())
 * 5. Inside pipeline block: replace segment execution logic (keep existing for now)
 * 6. Remove the "if(all_layers_qualify) { } else { }" wrapper
 * 7. In per-layer loop: add "if (layer_qualifies[l]) continue;" at start
 * 
 * This preserves ALL existing braces and only changes the control flow.
 */

// Helper function to check if layer was processed by pipeline
inline bool was_layer_processed_by_pipeline(const std::vector<bool>& layer_qualifies, std::uint32_t l) {
    return l < layer_qualifies.size() && layer_qualifies[l];
}