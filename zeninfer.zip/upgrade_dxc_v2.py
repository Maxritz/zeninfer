#!/usr/bin/env python3
"""
Download and install dxc with Work Graphs support.
Tries multiple known versions.
"""
import os
import sys
import urllib.request
import zipfile
import shutil
import subprocess
import tempfile
import json

# Known versions with Work Graphs support
DXC_VERSIONS = [
    "1.8.2411.5",
    "1.8.2411.7", 
    "1.8.2411.9",
    "1.8.2411.11",
    "1.8.2411.13",
    "1.8.2411.15",
]

GITHUB_API = "https://api.github.com/repos/microsoft/DirectXShaderCompiler/releases"

def get_latest_release():
    """Get latest release info from GitHub API."""
    try:
        with urllib.request.urlopen(GITHUB_API) as response:
            return json.load(response)
    except Exception as e:
        print(f"Failed to fetch releases: {e}")
        return []

def download_dxc(version):
    """Download and extract dxc for a specific version."""
    print(f"Trying dxc {version}...")
    
    # Try to download
    url = f"https://github.com/microsoft/DirectXShaderCompiler/releases/download/v{version}/dxc_{version}.zip"
    
    with tempfile.TemporaryDirectory() as tmpdir:
        zip_path = os.path.join(tmpdir, "dxc.zip")
        
        try:
            print(f"Downloading from {url}")
            urllib.request.urlretrieve(url, zip_path)
        except urllib.error.HTTPError as e:
            if e.code == 404:
                print(f"Version {version} not found (404)")
                return False
            raise
        
        # Extract
        extract_dir = os.path.join(tmpdir, "dxc")
        with zipfile.ZipFile(zip_path, 'r') as zf:
            zf.extractall(os.path.join(tmpdir, "dxc"))
        
        # Find dxc.exe
        dxc_path = None
        for root, dirs, files in os.walk(extract_dir):
            for f in files:
                if f == "dxc.exe":
                    dxc_path = os.path.join(root, f)
                    break
            if dxc_path:
                break
        
        if not dxc_path:
            print("ERROR: dxc.exe not found in archive")
            return False
        
        # Install to H:\llamadx\dxc_new
        install_dir = r"H:\llamadx\dxc_new"
        if os.path.exists(install_dir):
            shutil.rmtree(install_dir)
        os.makedirs(install_dir, exist_ok=True)
        
        # Copy all files
        for root, dirs, files in os.walk(extract_dir):
            for f in files:
                src = os.path.join(root, f)
                rel = os.path.relpath(src, extract_dir)
                dst = os.path.join(install_dir, rel)
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                shutil.copy2(src, dst)
        
        print(f"Installed dxc to {install_dir}")
        
        # Test
        dxc_exe = os.path.join(install_dir, "bin", "x64", "dxc.exe")
        if not os.path.exists(dxc_exe):
            # Try to find dxc.exe anywhere
            for root, dirs, files in os.walk(install_dir):
                if "dxc.exe" in files:
                    dxc_exe = os.path.join(root, "dxc.exe")
                    break
        
        if not os.path.exists(dxc_exe):
            print("ERROR: dxc.exe not found after install")
            return False
        
        result = subprocess.run([dxc_exe, "--version"], capture_output=True, text=True)
        print(f"Version: {result.stdout.strip()}")
        
        # Test Work Graphs support
        result = subprocess.run([dxc_exe, "-help"], capture_output=True, text=True)
        if "enable-work-graph" in result.stdout:
            print("SUCCESS: -enable-work-graph flag found!")
            return True
        else:
            print("WARNING: -enable-work-graph flag NOT found")
            return False

def main():
    print("Checking available releases...")
    releases = get_latest_release()
    
    # Filter for 1.8.x releases
    candidates = []
    for rel in releases:
        tag = rel.get('tag_name', '')
        if tag.startswith('v1.8.'):
            version = tag[1:]  # Remove 'v'
            candidates.append(version)
    
    # Add hardcoded candidates
    for v in DXC_VERSIONS:
        if v not in candidates:
            candidates.append(v)
    
    print(f"Candidate versions: {candidates}")
    
    for version in candidates:
        if download_dxc(version):
            print(f"\nSUCCESS: dxc {version} with Work Graphs support installed!")
            print(f"Installed to: H:\\llamadx\\dxc_new")
            print(f"Add H:\\llamadx\\dxc_new\\bin\\x64 to PATH or set ZEN_DXC_DIR")
            return
    
    print("FAILED: Could not find working dxc with Work Graphs support")
    sys.exit(1)

if __name__ == "__main__":
    main()