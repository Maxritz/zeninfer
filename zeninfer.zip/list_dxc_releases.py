import urllib.request
import json

url = "https://api.github.com/repos/microsoft/DirectXShaderCompiler/releases"
req = urllib.request.Request(url, headers={'Accept': 'application/vnd.github.v3+json'})
with urllib.request.urlopen(req) as response:
    data = json.load(response)
    print(f"Total releases: {len(data)}")
    for release in data:
        tag = release['tag_name']
        if '1.8.' in tag:
            print(f"  {tag} - Assets: {len(release.get('assets', []))}")
            for asset in release.get('assets', []):
                print(f"    {asset['name']} - {asset['browser_download_url']}")