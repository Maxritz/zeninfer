import re

with open(r'H:\llamadx\update\zeninfer\src\backends\d3d12\d3d12_backend.cpp', 'r') as f:
    content = f.read()

# Replace create_buffer(s.device.Get(), ...) with create_buffer(s, ...) for upload_heap_type() calls
# Pattern: create_buffer(s.device.Get(), <bytes>, upload_heap_type(), ...)

# First, let's find all occurrences
import re
pattern = r'create_buffer\(s\.device\.Get\(\), (\d+|[a-zA-Z_][a-zA-Z0-9_]*), upload_heap_type\(\),'
matches = list(re.finditer(pattern, content))
print(f"Found {len(matches)} matches:")
for m in matches:
    print(f"  Line {content[:m.start()].count(chr(10)) + 1}: {m.group()}")

# Replace all
new_content = re.sub(
    r'create_buffer\(s\.device\.Get\(\), (\d+|[a-zA-Z_][a-zA-Z0-9_]*), upload_heap_type\(\),',
    r'create_buffer(s, \1, upload_heap_type(),',
    content
)

# Count replacements
replacements = len(matches)
print(f"Replacements: {replacements}")

with open(r'H:\llamadx\update\zeninfer\src\backends\d3d12\d3d12_backend.cpp', 'w') as f:
    f.write(new_content)

print("Done")